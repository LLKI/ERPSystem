var webpack = require('webpack');
module.exports = {
	configureWebpack: {
		plugins: [
			new webpack.ProvidePlugin({
				'window.Quill': 'quill/dist/quill.js',
				'Quill': 'quill/dist/quill.js'
			}),
		]
	},
	devServer: {
	    proxy: {
	      '/api': {
	        target: 'url',
	        changeOrigin: true,
	        pathRewrite: {
	          '^/api': ''
	        }
	      }
	    },
	    https: true
	  }
}
