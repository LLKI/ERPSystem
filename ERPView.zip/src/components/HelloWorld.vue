<template>
  <div class="hello">
    <el-submenu index="1-1">
    		<template slot="title">
    			<i class="el-icon-chat-round"></i><span>通知管理</span>
    		</template>
    		<el-menu-item index="home">
    			<i class="el-icon-chat-line-round"></i><span>查看通知</span>
    		</el-menu-item>
    		<el-menu-item index="mynotify">
    			<i class="el-icon-chat-line-round"></i><span>我的发布</span>
    		</el-menu-item>
    		<el-menu-item index="sendnotify">
    			<i class="el-icon-edit"></i><span>发布通知</span>
    		</el-menu-item>
    		<el-menu-item index="notifyType" v-if="id==1">
    			<i class="el-icon-chat-square"></i><span>通知类别</span>
    		</el-menu-item>
    	</el-submenu>
    	<el-submenu index="1-2">
    		<template slot="title">
    			<i class="el-icon-shopping-bag-1"></i><span>商品管理</span>
    		</template>
    		<el-menu-item index="productInfo">
    			<i class="el-icon-document-copy"></i><span>商品详情</span>
    		</el-menu-item>
    		<el-menu-item index="brand">
    			<i class="el-icon-office-building"></i><span>商品品牌</span>
    		</el-menu-item>
    		<el-menu-item index="proType">
    			<i class="el-icon-suitcase-1"></i><span>商品类型</span>
    		</el-menu-item>
    		<el-menu-item index="supplier">
    			<i class="el-icon-school"></i><span>供应商</span>
    		</el-menu-item>
    	</el-submenu>
    	<el-submenu index="1-3">
    		<template slot="title">
    			<i class="el-icon-box"></i><span>仓库管理</span>
    		</template>
    		<el-menu-item index="warehouse">
    			<i class="el-icon-news"></i><span>库房管理</span>
    		</el-menu-item>
    		<el-menu-item index="reservoir">
    			<i class="el-icon-guide"></i><span>库区管理</span>
    		</el-menu-item>
    	</el-submenu>
    	<el-submenu index="1-4">
    		<template slot="title">
    			<i class="el-icon-sell"></i><span>订单管理</span>
    		</template>
    		<el-menu-item index="buyOrder">
    			<i class="el-icon-s-order"></i><span>采购订单</span>
    		</el-menu-item>
    		<el-menu-item index="payOrder">
    			<i class="el-icon-money"></i><span>付款订单</span>
    		</el-menu-item>
    		<el-menu-item index="backOrder">
    			<i class="el-icon-warning-outline"></i><span>退货订单</span>
    		</el-menu-item>
    	</el-submenu>
    	<el-submenu index="1-5">
    		<template slot="title">
    			<i class="el-icon-s-cooperation"></i><span>库存管理</span>
    		</template>
    		<el-menu-item index="warehouseInfo">
    			<i class="el-icon-tickets"></i><span>库存情况</span>
    		</el-menu-item>
    		<!-- <el-menu-item index="ppp">
    			<i class="el-icon-truck"></i><span>库存调拨</span>
    		</el-menu-item> -->
    		<el-menu-item index="proProfile">
    			<i class="el-icon-notebook-1"></i><span>商品分布</span>
    		</el-menu-item>
    	</el-submenu>
    	<el-submenu index="1-6">
    		<template slot="title">
    			<i class="el-icon-truck"></i><span>权限管理</span>
    		</template>
    		<el-menu-item index="userInfo">
    			<i class="el-icon-user"></i><span>用户管理</span>
    		</el-menu-item>
    		<el-menu-item index="role">
    			<i class="el-icon-user-solid"></i><span>角色管理</span>
    		</el-menu-item>
    		<el-menu-item index="ppp">
    			<i class="el-icon-document"></i><span>系统日志</span>
    		</el-menu-item>
    		<el-menu-item index="ppp">
    			<i class="el-icon-menu"></i><span>菜单管理</span>
    		</el-menu-item>
    	</el-submenu>
    </el-menu>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
