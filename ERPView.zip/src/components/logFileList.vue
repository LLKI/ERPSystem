<template>
	<div>
		<div style="display: flex;flex-wrap: wrap">
			<template v-for="item in myList">
				<div style="margin-right: 20px;margin-top: 20px;cursor: pointer;" @click="lookLog(item)">
					<dl style="text-align: center;">
						<dd>
							<i class="el-icon-document" style="font-size: 100px;"></i>
						</dd>
						<dt>
							{{item}}
						</dt>
					</dl>
				</div>
			</template>
		</div>
	</div>
</template>

<script>
	export default{
		//props:['myList'],
		data(){
			return{
				myList:this.$route.params.myList,
				sign:this.$route.params.sign
			}
		},
		methods:{
			Init(){
				console.log(this.$route.params.myList);
				console.log(this.$route.params.sign)
			},
			//查看内容
			lookLog(item){
				this.request.get("/LogFile/"+item+"/"+this.sign).then(res=>{
					if(res.code==200){
						window.open(res.data, "_blank", "resizable,scrollbars,status");
					}
				})
			}
		},
		created() {
			this.Init();
		}
	}
</script>

<style>
</style>