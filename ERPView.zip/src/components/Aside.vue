<template>
	<div>
		<div class="header-logo" :style="fontsize"><span>ERP仓库管理</span></div>
		<el-menu :default-openeds="['0-1']" background-color="rgb(48,65,86)" text-color="#fff"
			active-text-color="orange" :collapse-transition='false' :collapse="iscollapse" router @select="headerSelect"
			default-active="home" style="height: 100%;" :unique-opened="true">
			
			<template v-for="(item,index) in myList">
				<el-submenu :index="index+'1' ">
					<template slot="title">
						<i :class="item.icon"></i><span>{{item.menuName}}</span>
					</template>
					<template v-for="menu in item.sonMenu">
						<el-menu-item :index="menu.url">
							<i :class="menu.icon"></i><span>{{menu.menuName}}</span>
						</el-menu-item>
					</template>
				</el-submenu>
			</template>
		</el-menu>
	</div>
</template>
<!-- default-openeds:展开菜单 -->
<!-- default-active="user"：默认选中的菜单 -->
<script>
	export default {
		name: "Aside",
		props: {
			iscollapse: Boolean,
			fontsize: String
		},
		methods: {
			headerSelect(index) {
				//console.log(this.$router.options.routes);
			},
			Init() {
				this.myList=[]
				this.request.get("/menu/" + this.id).then(res => {
					if (res.code == 200) {
						this.myList = res.data;
					}
				});
			}
		},
		data() {
			return {
				id: JSON.parse(localStorage.getItem("userInfo")).id,
				myList: [],
				
			}
		},
		created() {
			this.Init();
			
		},
		watch:{
			'$root.role': function() {
				this.Init();
			},
			'$root.menuName': function() {
				this.Init();
			},
			'$root.icon': function() {
				this.Init();
			},
			'$root.sonMenuIcon': function() {
				this.Init();
			},
			'$root.sonMenuName': function() {
				this.Init();
			},
			'$root.sonMenuParentId':function(){
				this.Init();
			},
			'$root.addSonMenu':function(){
				this.Init();
			}
		}
	}
</script>

<style>
	.header-logo {
		text-align: center;
		width: 100%;
		height: 50px;
		line-height: 50px;
		color: antiquewhite;
	}
</style>
