<template>
	<div>
		<div style="display: flex;">
			<div style="width: 200px;">
				<el-input clearable v-model="search_order.OrderNo" placeholder="请输入订单号"></el-input>
			</div>
			<div style="margin-left: 15px;">
				<el-button type="primary" icon="el-icon-search" @click="search">搜索</el-button>
			</div>
			<div style="margin-left: 15px;">
				<el-dropdown split-button type="success" style="margin-right: 10px;" trigger="click">
					批量操作
					<el-dropdown-menu slot="dropdown">
						<el-dropdown-item style="width:100px;color: #67C23A;" v-if="audit==0&&userSign=='ADMIN'">
							<span @click="option_batch('通过')" class="el-icon-check"
								style="display: inline-block;width: 100%;">通过</span>
						</el-dropdown-item>
						<el-dropdown-item style="width:100px;color: #F56C6C;" v-if="audit==0&&userSign=='ADMIN'">
							<span @click="option_batch('驳回')" class="el-icon-close"
								style="display: inline-block;width: 100%;">驳回</span>
						</el-dropdown-item>
						<el-dropdown-item style="width:100px;color: red;" v-if="audit==2||audit==3">
							<span @click="option_batch('删除')" class="el-icon-close"
								style="display: inline-block;width: 100%;">删除</span>
						</el-dropdown-item>
						<el-dropdown-item style="width:100px;color: red;" v-if="audit==0">
							<span @click="option_batch('撤销')" class="el-icon-remove-outline"
								style="display: inline-block;width: 100%;">撤销</span>
						</el-dropdown-item>
					</el-dropdown-menu>
				</el-dropdown>
			</div>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}"
				@selection-change="handleSelectionChange" tooltip-effect="dark" ref="multipleTable">
				<el-table-column type="selection" width="55">
				</el-table-column>
				<el-table-column prop="id" label="编号" align="center" width="50">
				</el-table-column>
				<el-table-column prop="proNo" label="订单编号" align="center" width="320">
					<template slot-scope="scope">
						<el-link type="warning" @click="lookDetail(scope.row.catId,scope.row.remark)" v-if="audit==0">{{scope.row.proNo}}
						</el-link>
						<el-link type="success" @click="lookDetail(scope.row.catId,scope.row.remark)" v-if="audit==1">{{scope.row.proNo}}
						</el-link>
						<el-link type="danger" @click="lookDetail(scope.row.catId,scope.row.remark)" v-if="audit==2">{{scope.row.proNo}}
						</el-link>
						<el-link type="info" @click="lookDetail(scope.row.catId,scope.row.remark)" v-if="audit==3">{{scope.row.proNo}}
						</el-link>
					</template>
				</el-table-column>
				<el-table-column label="订单状态" align="center">
					<template slot-scope="scope">
						<el-tag type="warning" v-if="scope.row.auditState==0">未审核</el-tag>
						<el-tag type="success" v-if="scope.row.auditState==1">已通过</el-tag>
						<el-tag type="danger" v-if="scope.row.auditState==2">已驳回</el-tag>
						<el-tag type="info" v-if="scope.row.auditState==3">已撤销</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="总金额" align="center">
					<template slot-scope="scope">
						<span style="color: red;">{{scope.row.totalPrice}}元</span>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="生成时间" align="center" width="180px">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="catId" label="购物车id" align="center" width="180px" style="display: none;"
					v-if="false">
				</el-table-column>
				
				<el-table-column prop="auditTime" label="审核时间" align="center" width="180px" v-if="audit!=0&&audit!=3">
					<template slot-scope="scope">
						<span v-if="scope.row.auditPersion!=null ">{{scope.row.auditTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
						<span v-else style="color: red;">未审核</span>
					</template>
				</el-table-column>
				<el-table-column prop="auditTime" label="撤销时间" align="center" width="180px" v-if="audit==3">
					<template slot-scope="scope">
						<span>{{scope.row.auditTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
						<!-- <span v-else style="color: red;">未审核</span> -->
					</template>
				</el-table-column>
				<el-table-column prop="addPerson" label="采购人" align="center" >
				</el-table-column>
				<el-table-column label="审核人" align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.auditPersion!=null ">{{scope.row.auditPersion}}</span>
						<span v-else style="color: red;">未审核</span>
					</template>
				</el-table-column>
				<el-table-column align="center" label="操作" width="200">
					<template slot-scope="scope">
						<el-button type="primary" icon="el-icon-money" size="small" v-if="audit==1&&scope.row.isPay==0&&scope.row.remark==null"
							@click="goToPay">去付款</el-button>
						<el-button type="success" icon="el-icon-money" size="small" v-if="audit==1&&scope.row.isPay==1"
							:disabled="true">已完成支付</el-button>
							<el-button type="danger" icon="el-icon-money" size="small" v-if="audit==1&&scope.row.isPay==0&&scope.row.remark!=null"
								:disabled="true">已取消支付</el-button>
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除此订单吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="small"
								v-if="audit==2||audit==3">
								删除
							</el-button>
						</el-popconfirm>

						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认撤销此订单吗？" @confirm="backOrder(scope.row.id)">
							
							<el-button type="warning" icon="el-icon-remove-outline" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="small" v-if="audit==0">
								撤销
							</el-button>
						</el-popconfirm>
						<el-dropdown size="small" split-button type="primary" style="margin-right: 10px;"
							trigger="click" v-if="audit==0&&userSign=='ADMIN'">
							更多
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item style="width:100px;color: #67C23A;">
									<span @click="option(scope.row.id,'通过')" class="el-icon-check"
										style="display: inline-block;width: 100%;">通过</span>
								</el-dropdown-item>
								<el-dropdown-item style="width:100px;color: #F56C6C;">
									<span @click="option(scope.row.id,'驳回')" class="el-icon-close"
										style="display: inline-block;width: 100%;">驳回</span>
								</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
						<!-- <el-button type="primary" icon="el-icon-s-grid" @click="editData(scope.row.id)"
					style="padding:10px;font-size: 10px;" size="small">更多</el-button> -->
						<!-- <el-button type="warning" size="small" icon="el-icon-view" >
						详情
					</el-button> -->
					</template>
				</el-table-column>
			</el-table>

			<!-- 分页 -->
			<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
				<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page.sync="search_order.pageIndex" :page-sizes="[7,10,15,20]"
					:page-size="search_order.pageSize" layout="sizes, prev, pager, next,total"
					:total="search_order.total">
				</el-pagination>
			</div>


			<!-- 弹窗 显示订单详情 -->
			<div>
				<el-drawer title="订单详情" :visible.sync="drawer" direction="btt" style="width: 50%;margin: 0px auto;"
					size="90%">
					<div style="padding: 20px;">
						<template v-for="item in detail">
							<div style="margin-bottom: 20px;">
								<el-descriptions class="margin-top" :column="3" border>
									<!-- <template slot="extra">
							     <el-button type="primary" size="small">操作</el-button>
							   </template> -->
									<el-descriptions-item :labelStyle="{'width':'100px'}">
										<template slot="label">
											<i class="el-icon-document"></i>
											商品名称
										</template>
										{{item.proName}}
									</el-descriptions-item>
									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-wallet"></i>
											成本
										</template>
										<span style="color: red;">{{item.costPrice}}元</span>
									</el-descriptions-item>
									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-money"></i>
											售价
										</template>
										<span style="color: red;">{{item.price}}元</span>
									</el-descriptions-item>
									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-box"></i>
											库存
										</template>
										{{item.stock}}
									</el-descriptions-item>
									<el-descriptions-item :labelStyle="{'width':'100px'}">
										<template slot="label">
											<i class="el-icon-copy-document"></i>
											商品种类
										</template>
										{{item.proType}}
									</el-descriptions-item>
									<el-descriptions-item :labelStyle="{'width':'100px'}">
										<template slot="label">
											<i class="el-icon-location-information"></i>
											存放位置
										</template>
										{{item.address}}
									</el-descriptions-item>
									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-film"></i>
											状态
										</template>
										<span v-if="item.isAudio==0" style="color: #E6A23C;">未审核</span>
										<span v-if="item.isAudio==1" style="color: #67C23A;">已审核</span>
										<span v-if="item.isAudio==2" style="color: #F56C6C;">已驳回</span>
										<span v-if="item.isAudio==3" style="color: #909399;">已撤销</span>
										<span v-if="item.isAudio==4" style="color: #E6A23C;">待付款</span>
										<span v-if="item.isAudio==5" style="color: #67C23A;">已付款</span>
										<span v-if="item.isAudio==6" style="color: #F56C6C;">取消支付</span>
									</el-descriptions-item>

									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-time"></i>
											采购时间
										</template>
										{{item.addTime}}
									</el-descriptions-item>

									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-user"></i>
											采购人
										</template>
										{{item.addPerson}}
									</el-descriptions-item>
									<el-descriptions-item>
										<template slot="label">
											<i class="el-icon-bank-card"></i>
											总价
										</template>
										<span style="color: red;">{{(item.stock.split('-')[0])*item.costPrice}}元</span>
									</el-descriptions-item>
									<el-descriptions-item v-if="item.isAudio==6">
										<template slot="label">
											<i class="el-icon-chat-line-square"></i>
											取消理由
										</template>
										<span style="color: red;">{{reason}}</span>
									</el-descriptions-item>
									<el-descriptions-item v-if="item.isAudio==2">
										<template slot="label">
											<i class="el-icon-chat-line-square"></i>
											驳回理由
										</template>
										<span style="color: red;">{{reason}}</span>
									</el-descriptions-item>
									<el-descriptions-item v-if="item.isAudio==3">
										<template slot="label">
											<i class="el-icon-chat-line-square"></i>
											撤销理由
										</template>
										<span style="color: red;">{{reason}}</span>
									</el-descriptions-item>
								</el-descriptions>
							</div>
						</template>


					</div>
				</el-drawer>
			</div>
			<!-- 弹窗 驳回的理由 -->
			<div>
				<el-dialog :title="title" :visible.sync="dialogVisible" width="30%">
					<div>
						<el-input type="textarea" v-model="remark" clearable />
					</div>
					<span slot="footer" class="dialog-footer">
						<el-button @click="dialogVisible = false">取 消</el-button>
						<el-button type="primary" @click="NoOrder">确 定</el-button>
					</span>
				</el-dialog>
			</div>
		</div>

	</div>
</template>

<script>
	export default {
		name: 'buyOrderList',
		props: ['state'],
		data() {
			return {
				myList: [], //订单状态
				search_order: {
					total: 0,
					pageIndex: 1,
					pageSize: 7,
					OrderNo: '',
					audio: this.state,
					userId: JSON.parse(localStorage.getItem("userInfo")).id
				},
				drawer: false,
				audit: this.state,
				detail: {},
				ids: [],
				multipleSelection: [],
				dialogVisible: false,
				remark: '',
				id: '',
				title: '',
				order: {},
				sign: '',
				userSign: '',
				reason:''//理由
			}
		},
		created() {
			this.Init();
			if (localStorage.getItem("userInfo") == undefined || localStorage.getItem("userInfo") == null) {
				this.$message.error("请重新登录");
				this.$router.push("/home");
			}
			this.request.get("/roles/" + JSON.parse(localStorage.getItem("userInfo")).id).then(res => {
				if (res.code == 200) {
					this.userSign = res.data.sign;
				}
			})
		},
		methods: {

			//初始化
			Init() {
				this.request.post("/buyOrder", this.search_order).then(res => {
					if (res.code == 200) {
						this.myList = res.data.myList;
						this.search_order.total=res.data.total;
						console.log(res.data)
					}
				})
			},
			//去付款
			goToPay() {
				this.$router.push("/payOrder");
			},
			//通过或驳回 批处理
			option_batch(sign) {

				if (this.ids.length <= 0) {
					this.$message.warning("请选择需要处理的数据");
					return;
				}
				this.order.userId = this.search_order.userId;
				if (sign == "通过") {
					this.order.ids = this.ids;
					this.request.post("/buyOrder/allow", this.order).then(res => {
						if (res.code == 200) {
							this.Init();
							this.$message.success(res.msg)
						} else {
							this.$message.success(res.msg)
						}
					})
				} else if (sign == "驳回") {
					//驳回
					this.dialogVisible = true;
					this.title = "驳回理由"
					this.sign = "批量驳回"
				} else if (sign == "撤销") {

					this.title = "撤销理由"
					this.dialogVisible = true;
					this.sign = "批量撤销"


				} else {
					//删除
					this.$confirm('删除后不可恢复, 是否继续?', '提示', {
						confirmButtonText: '确定',
						cancelButtonText: '取消',
						type: 'warning'
					}).then(() => {
						this.order.ids = this.ids;
						this.request.post("/buyOrder/del", this.order).then(res => {
							if (res.code == 200) {
								this.Init();
								this.$message.success(res.msg);
							} else {
								this.$message.error(res.msg);
							}
						})

					});
				}
			},
			//撤销
			backOrder(id) {
				//this.remark="";
				this.title = "撤销理由";
				this.dialogVisible = true;
				this.order.id = id;
				this.order.userId = this.search_order.userId;
				//this.order.remark = this.remark;
				// this.request.put("/BuyOrder", this.order).then(res => {
				// 	if (res.code == 200) {
				// 		this.Init();
				// 		this.$message.success(res.msg);
				// 	} else {
				// 		this.$message.error(res.msg);
				// 	}
				// })
			},
			//通过 或驳回
			option(id, sign) {
				this.order.id = id;
				this.order.userId = this.search_order.userId;
				if (sign == "通过") {
					this.request.post("/BuyOrder/allow", this.order).then(res => {
						if (res.code == 200) {
							this.Init();
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				} else {
					this.title = "驳回理由"
					this.dialogVisible = true;
					this.remark = "";
				}

			},
			//驳回 撤销
			NoOrder() {
				if (this.remark == "") {
					this.$message.warning("请输入理由");
					return;
				}

				this.order.remark = this.remark;

				if (this.sign == "批量驳回" || this.sign == "批量撤销") {
					this.order.ids = this.ids;
				}

				if (this.title == "驳回理由") {
					//驳回
					this.request.post("/BuyOrder/back", this.order).then(res => {
						if (res.code == 200) {
							this.Init();
							this.dialogVisible = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				} else {
					//撤销
					this.request.post("/buyOrder/undo", this.order).then(res => {
						if (res.code == 200) {
							this.Init();
							this.dialogVisible = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})

				}

			},
			//删除 单删
			delData(id) {
				this.order.id = id;
				this.order.userId = this.search_order.userId;
				this.request.post("/buyOrder/del", this.order).then(res => {
					if (res.code == 200) {
						this.Init();
						this.$message.success(res.msg);
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//搜索
			search() {
				this.Init();
			},

			//查看详情
			lookDetail(catId,remark) {
				this.request.get("/BuyOrder/" + catId).then(res => {
					if (res.code == 200) {
						this.detail = res.data;
						this.drawer = true;
						console.log(this.detail)
					}
				});
				this.reason=remark;
			},
			handleSelectionChange(val) {
				this.ids = [];
				for (var i = 0; i < val.length; i++) {
					this.ids.push(val[i].id);
				}
			},
			//切换页码
			handleCurrentChange(index) {
				this.search_order.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_order.pageSize = pageSize;
				this.Init();
			},
		}
	}
</script>

<style>
</style>
