<template>
	<div>
		<div style="text-align: right; font-size: 12px;justify-content: space-between;display: flex;align-items: center;">
			<div sty1e="flex: 1;">
				<span :class="collapseBtnClass" style="cursor: pointer;font-size: 28px" v-on:click="collapse1"></span>
				<el-breadcrumb separator="/" styLe="display:inline-block; margin-Left: 10px;">
					<el-breadcrumb-item :to="{ path: '/home' }"><span style="cursor: pointer;font-size: 20px;">系统首页</span>
					</el-breadcrumb-item>
					<el-breadcrumb-item><span style="cursor: pointer;font-size: 20px;">{{ this.$route.name }}</span>
					</el-breadcrumb-item>
				</eL-breadcrumb>
			</div>
			<div style="flex: 1;">
				<!-- 图像 -->
				<div style="display: flex;justify-content:end;">
					<el-avatar :src="url" style="margin-top: 8px;margin-right: 10px;border-right: 1px solid black;">
					</el-avatar>
					<span style="font-size: 16px;display: block;">
						<span style="font-size:10px;">欢迎：</span>&nbsp;{{nickname}}</span>
					<span style="margin-left: 20px;height: 60px;">|</span>
					<el-dropdown trigger="click">
						<i class="el-icon-setting" style="margin-left: 10px;font-size:18px;margin-left: 30px;"></i>
						<el-tooltip class="item" effect="dark" content="注销账号" placement="bottom-end">
							<li class="el-icon-switch-button" style="color: orangered;margin-left: 10px;font-size: 18px;">
							</li>
						</el-tooltip>
						<el-tooltip class="item" effect="dark" content="如果系统出现问题请联系我们" placement="bottom-end">
							<li class="el-icon-headset" style="color:forestgreen;margin-left: 10px;font-size: 18px;"
								@click="sendEmail">
							</li>
						</el-tooltip>
						<el-dropdown-menu slot="dropdown">
							<!-- <el-dropdown-item><span @click="goToSelf">个人中心</span></el-dropdown-item> -->
							<el-dropdown-item><span @click="close">退出</span></el-dropdown-item>
						</el-dropdown-menu>
					</el-dropdown>
				</div>
			</div>
		</div>
		<el-drawer
		  :title="title"
		  :visible.sync="drawer"
		  direction="ttb"
		  :before-close="handleClose" style="width: 50%;margin: 0px auto;" size="70%">
		  <div style="padding: 15px;margin-top: -30px;">
			  <div>请描述系统出现的问题:</div>
			  <div>
				  <el-input type="textarea" rows="6" v-model="email.content"></el-input>
			  </div>
			  <div>
				  <span>您的联系方式(手机号或邮箱)：</span>
				  <el-input v-model="email.phone"></el-input>
			  </div>
			  <div style="position: relative;margin-top: 10px;">
				  <el-button type="primary" style="position: absolute;right: 0;" icon="el-icon-check" @click="send">发送</el-button>
			  </div>
		  </div>
		</el-drawer>
	</div>
	
</template>

<script>
	export default {
		data() {
			return {
				user: "",
				nickname: "",
				url: "",
				drawer: false,
				title:"发送邮箱",
				email:{
				}
			}
		},
		props: {
			collapse1: Function,
			collapseBtnClass: String
		},
		methods: {
			close() {
				localStorage.removeItem("userInfo");
				this.$router.push("/");
			},
			Init() {
				var user = JSON.parse(localStorage.getItem("userInfo"));
				this.nickname = user.nickName;
				this.url = user.img;
			},
			//个人中心
			goToSelf() {
				this.$router.push("/self");
			},
			//发送邮件
			sendEmail() {
				this.email={}
				this.drawer=true;
			},
			//发送
			send(){
				if(this.email.content==""||this.email.phone==""||this.email==undefined||this.email.phone==undefined){
					this.$message.error("请输入内容以及联系方式")
					return ;
				}
				this.email.userId=JSON.parse(localStorage.getItem("userInfo")).id;
				this.request.post("/sendEmail",this.email).then(res=>{
					if(res.code==200){
						this.drawer=false;
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {});
			}
			// back() {
			// 	this.$router.push("/verify");
			// 	localStorage.removeItem("user");
			// },
			// userHome() {
			// 	this.$router.push("/userhome");
			// },
		},
		watch: { //监听全局变量
			'$root.accountImg': function() {
				this.user = JSON.parse(localStorage.getItem("userInfo"));
				//this.$root.accountImg =this.user.accountImg;
				this.url = this.$root.accountImg;
			},
			'$root.nickName': function() {
				this.user = JSON.parse(localStorage.getItem("userInfo"));
				//this.$root.nickName=this.user.nickName;
				this.nickname = this.$root.nickName;
			}
		},
		created() {
			this.Init();
			// if (this.user == null) {
			// 	this.nickname = "暂未登录";
			// } else {
			// 	this.nickname = this.user.nickname;
			// 	this.url=this.user.img;
			// }
		}
	}
</script>

<style>
</style>
