<template>
  <div id="app">
	  <router-view></router-view>
  </div>
</template>

<script>
//import login from './views/Login.vue'

export default {
  name: 'app'
}
</script>

<style scoped>
	*{
		padding: 0px;
		margin: 0px;
	}
	#app {
		position: absolute;
		padding: 0px;
		margin: 0px;
		width: 100%;
		height: 100%;;
	}
</style>
