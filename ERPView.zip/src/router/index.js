import Vue from 'vue'
import VueRouter from 'vue-router'
import login from '../views/Login.vue'
Vue.use(VueRouter)

var router = new VueRouter({
	routes:[
		{
			path:"/",
			name:"login",
			component:login,
		},
		{
			path:'/home',
			name:'系统首页',
			component:()=>import("../views/Manager.vue"),
			children:[
				{
					path:'/home',
					name:"首页",
					meta:{
						active:'home'
					},
					component:()=>import("../views/index/Home.vue")
				},
				{
					path:'/sendnotify',
					name:"发送公告",
					component:()=>import("../views/notify/SendNotify.vue")
				},
				{
					path:'/notifyType',
					name:"公告类型",
					component:()=>import("../views/notify/notifyType.vue")
				},
				{
					path:'/mynotify',
					name:"我的发布",
					component:()=>import("../views/notify/MyNotify.vue")
				},
				{
					path:'/warehouse',
					name:'库房管理',
					component:()=>import("../views/warehouse/warehouse.vue")
				},
				// {
				// 	path:'/self',
				// 	name:'个人中心',
				// 	component:()=>import("../views/self.vue")
				// },
				{
					path:'/reservoir',
					name:'库区管理',
					component:()=>import("../views/warehouse/reservoir.vue")
				},
				{
					path:'/brand',
					name:'商品品牌',
					component:()=>import("../views/product/brand.vue")
				},
				{
					path:'/proType',
					name:'商品类型',
					component:()=>import("../views/product/proType.vue")
				},
				{
					path:'/supplier',
					name:'供应商管理',
					component:()=>import("../views/product/supplier.vue")
				},
				{
					path:'/productInfo',
					name:'商品管理',
					component:()=>import("../views/product/productInfo.vue")
				},
				{
					path:'/buyOrder',
					name:'订单管理',
					component:()=>import("../views/buyOrder/buyOrder.vue")
				},
				{
					path:'/payOrder',
					name:"付款订单",
					component:()=>import("../views/payOrder/PayOrder.vue")
				},
				{
					path:'/userInfo',
					name:"用户管理",
					component:()=>import("../views/user/userInfo.vue")
				},
				{
					path:'/role',
					name:'角色管理',
					component:()=>import("../views/roles/role.vue")
				},
				{
					path:'/menu',
					name:'菜单管理',
					component:()=>import("../views/menu/menu.vue")
				},
				{
					path:"/log",
					name:"系统日志",
					component:()=>import("../views/log/log.vue")
				},
				{
					path:'/logFileList/:myList/:sign',
					name:'日志详情',
					component:()=>import("../components/logFileList.vue")
				},
				{
					path:'/warehouseInfo',
					name:'库存情况',
					component:()=>import("../views/warehouse/warehouseInfo.vue")
				},
				{
					path:'/backOrder',
					name:'退货订单',
					component:()=>import("../views/backOrder/backOrder.vue")
				},
				{
					path:'/feedback',
					name:"用户反馈",
					component:()=>import("../views/feedback/feedback.vue")
				},
				{
					path:"/proProfile",
					name:"商品分布",
					component:()=>import("../views/warehouse/proProfile.vue")
				},
				{
					path:"/outOrder",
					name:"出库订单",
					component:()=>import("../views/outOrder/outOrder.vue")
				},
				{
					path:"/transfersOrder",
					name:"调拨订单",
					component:()=>import("../views/transfersOrder/transfersOrder.vue")
				}
			]
		},
		{
			path:'/payPage',
			name:'page',
			component:()=>import("../views/payOrder/page.vue")
		}
		
	]
})

export default router

// {
// 	path:'/about'
// 	name:'About'
// 	component: () => import('. ./views/About.vue)
// },
// {
// 	path:'/Login',
// 	name :'Login'
// 	component: () => import('. ./views/Login.vue ')
// }
// 3. 创建路由实例并传递 `routes` 配置
// 你可以在这里输入更多的配置，但我们在这里
// 暂时保持简单
// const router = VueRouter.createRouter({
//   // 4. 内部提供了 history 模式的实现。为了简单起见，我们在这里使用 hash 模式。
//   mode:"history",
//   // routes
//   routes
// })
// export default router
