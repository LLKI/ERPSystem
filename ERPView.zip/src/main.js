import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router';
import router from './router';
import request from './util/request';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
// main.js
import VueQuillEditor from 'vue-quill-editor'
// fade/zoom 等
import 'element-ui/lib/theme-chalk/base.css';
// collapse 展开折叠
import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';

// require styles
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'

import Echarts from 'echarts'



//富文本
Vue.use(VueQuillEditor)
Vue.component(CollapseTransition.name, CollapseTransition)
/* 安装vue-router插件 */
Vue.use(VueRouter); // 注册路由
Vue.use(ElementUI);
Vue.config.productionTip = false

Vue.prototype.request=request
new Vue({
  render: h => h(App),
  router,
  data(){
	  return{
		  accountImg:'',
		  nickName:'',
		  role:'',
		  menuName:'',
		  icon:'',
		  sonMenuIcon:'',
		  sonMenuName:'',
		  sonMenuParentId:'',
		  addSonMenu:false
	  }
  }
}).$mount('#app')
