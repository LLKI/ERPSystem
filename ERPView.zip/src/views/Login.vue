<template>
	<div id="box">
		<!-- 登录框 -->
		<div class="container">
			<div class="form">
				<h2>登录</h2>
				<div class="ppp">
					<div class="inputBox">
						<el-input type="text" placeholder="账号" prefix-icon="el-icon-user" v-model="account"
							id="account"></el-input>
						<!-- <input type="text" placeholder="姓名"> -->
					</div>
					<div class="inputBox">
						<el-input type="password" placeholder="密码" prefix-icon="el-icon-lock" v-model="pwd" id="pwd">
						</el-input>
						<!-- <input type="password" placeholder="密码" icon="el-icon-user"> -->
					</div>
					<div class="inputBox">
						<input type="submit" value="登录" id="btnLogin" @click="login">
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import {
		Loading
	} from 'element-ui'
	export default {
		name: 'login',
		data() {
			return {
				loadingInstance: null,
				account: '',
				pwd: '',
				centerDialogVisible: false,
				drawer: false,
				direction: 'ttb',
				mediaStreamTrack: null,
				isDisable: false,
				isDisable_close: true,
				isDisable_submit: true,
				isPhoneShow: false,
				phone: '',
				code: '',
				codeText:'发送验证码',
				num:120,
				isDisable_SendCode:false,
			}
		},
		methods: {
			//发送验证码
			sendCode(){
				const regex = /^1[3456789]\d{9}$/;//使用此正则即可
				if (!regex.test(this.phone)){
					this.$message.error("手机号格式不正确");
					//光标定位
					document.getElementById("phone").focus();
					return;
				}
				this.isDisable_SendCode=true;
				this.codeText=this.num--;
				//发送请求
				this.request.get("/login/phone/"+this.phone).then(res=>{
					if(res.code==200){
						this.$message.success("验证码发送成功，请注意查收");
						
					}else{
						this.$message.error(res.msg);
					}
				});
				//记时间
				let time=setInterval(()=>{
					this.codeText=this.num--;
					if(this.num<0){
						this.num=120;
						this.isDisable_SendCode=false;
						this.codeText="发送验证码"
						clearInterval(time);
					}
				},1000)
				
			},
			//发送验证码 end
			//手机号登录 
			loginByPhone(){
				if(this.code==''){
					this.$message.error("验证码不能为空");
				}else if(this.phone==''){
					this.$message.error("手机号不能为空");
				}else{
					this.request.get("/login/phone/"+this.phone+"/"+this.code).then(res=>{
						if(res.code==200){
							localStorage.setItem("userInfo",JSON.stringify(res.data));
							this.$router.push("/home");
							this.$message.success("登录成功");
						}else{
							this.$message.error(res.msg);
						}
					})
				}
			},
			//手机号登录 end
			//账号密码登录
			login() {
				//非空判断
				var account = document.getElementById("account");
				var pwd = document.getElementById("pwd");
				if (account.value == "" || pwd.value == "") {
					document.getElementById("account").style = "border:1px solid red";
					document.getElementById("pwd").style = "border:1px solid red";
					this.$message.error("用户名或者密码不能为空");
				} else {
					//请求
					this.request.get('/login/' + this.account + '/' + this.pwd).then(res => {
						if (res.code == 200) {
							this.loadingInstance = Loading.service({
								text: "登录中请稍后...",
								spinner: 'el-icon-loading',
								background: 'rgba(0,0,0,0.7)'
							});
							//console.log(res);
							localStorage.setItem("userInfo", JSON.stringify(res.data));
							var _this = this;
							//登录成功
							setTimeout(function() {
								_this.$router.push("/home");
							}, 200);
							setTimeout(function() {
								_this.loadingInstance.close();
								_this.$message.success("登录成功");
							}, 1000);
							

						} else {
							this.$notify({
								title: "登录失败",
								message: res.msg,
								type: 'error',
								duration: 1000
							});
							document.getElementById("account").style = "border:1px solid red";
							document.getElementById("pwd").style = "border:1px solid red";
						}
					}).catch(err => {
						this.$notify({
							title: "错误",
							message: "服务器未响应....",
							duration: 1500,
							type: 'error'
						})
					})
				}
			},
			//关闭手机登录的时候给出提示
			IsphoneClose(done){
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {
					});
			},
			//展示弹窗
			showDialog() {
				this.centerDialogVisible = true;
			},
			face() {
				if (this.account == '') {
					this.$message.error("请先输入账号！");
					this.centerDialogVisible = false;
					document.getElementById("account").focus();
					return;
				}
				this.drawer = true;
			},
			backPwd() {
				this.drawer = true;
			},
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {
					});
			},
			//开启摄像头
			openMedia() {
				var btnOpen = document.getElementById("btnOpen");
				if (this.isDisable) {
					return;
				} else {
					this.isDisable = true
					this.isDisable_close = false
					this.isDisable_submit = false
				}
				let video;
				let mediaStreamTrack = null;

				let constraints = {
					video: {
						width: 500,
						height: 500
					},
					audio: false
				};
				//获得video摄像头
				video = document.getElementById('video');
				let promise = navigator.mediaDevices.getUserMedia(constraints);

				promise.then((mediaStream) => {
					// mediaStreamTrack = typeof mediaStream.stop === 'function' ? mediaStream : mediaStream.getTracks()[1];
					mediaStreamTrack = mediaStream.getVideoTracks()
					video.srcObject = mediaStream;
					video.play();
				});
			},
			takePhoto() {
				//获得Canvas对象
				let video = document.getElementById('video');
				let canvas = document.getElementById('canvas');
				let ctx = canvas.getContext('2d');
				ctx.drawImage(video, 0, 0, 500, 500);
				// toDataURL  ---  可传入'image/png'---默认, 'image/jpeg'
				let img = document.getElementById('canvas').toDataURL();
				//console.log(img)
				video.pause();
				//console.log(img);
				//获取文件流
				var blob = this.base64toFile(img, 'file');

				// //上传
				var result = this.uploadFile(blob);

				//console.log(result);

				// if(result.code==200){
				// 	this.$message.success("识别成功");
				// }
				//var imgTag= document.getElementById('imgTag').src=img;

				// var face={
				// 	account:'1001',
				// 	file:imgTag.value
				// };
				// this.request.post("/login/face",face).then(res=>{
				// 	console.log(res);
				// }).catch(err=>{
				// 	console.log(err);
				// })
				// 这里的img就是得到的图片
				//console.log('img-----', img);


				//上传
				/*$.ajax({
				    url: "/xxxx.do",
				    type: "POST",
				    data: {"imgData": img},
				    success: function (data) {
				        console.log(data);
				        document.gauges.forEach(function (gauge) {
				            gauge.value = data.data
				        });
				    },
				    error: function () {
				        console.log("服务端异常！");
				    }
				});*/
			},
			// 关闭摄像头
			closeMedia() {
				var btnClose = document.getElementById("btnClose");
				if (this.isDisable_close) {
					return;
				} else {
					this.isDisable = false;
					this.isDisable_close = true;
					this.isDisable_submit = true;
				}
				let stream = document.getElementById('video').srcObject;
				let tracks = stream.getTracks();

				tracks.forEach(function(track) {
					track.stop();
				});

				document.getElementById('video').srcObject = null;
			},
			// 将base64转成图片文件流
			base64toFile(data, fileName) {
				const dataArr = data.split(",");
				const byteString = atob(dataArr[1]);
				const options = {
					type: "image/jpeg",
					endings: "native"
				};
				const u8Arr = new Uint8Array(byteString.length);
				for (let i = 0; i < byteString.length; i++) {
					u8Arr[i] = byteString.charCodeAt(i);
				}
				return new File([u8Arr], fileName + ".jpg", options); //返回文件流
			},
			uploadFile(blob) {
				
				//等待
				this.loadingInstance = Loading.service({
					text: "认证中...",
					spinner: 'el-icon-loading',
					background: 'rgba(0,0,0,0.7)'
				});

				const formData = new FormData();
				formData.append("file", blob);
				formData.append("account", this.account.trim());
				this.request.post("/login/face", formData, {
					headers: {
						"Content-Type": "multipart/form-data"
					}
				}).then(res => {
					//console.log(res);
					this.loadingInstance.close();
					if (res.code == 200) {
						localStorage.setItem("userInfo",JSON.stringify(res.data.userInfo));
						this.$message.success("认证成功");
						this.closeMedia();
						this.$router.push("/home");
					} else {
						//关闭摄像头
						this.closeMedia();
						this.drawer = false;
						this.centerDialogVisible = false;
						document.getElementById("account").focus();
						this.$message.error(res.msg);
					}
				}).catch(err => {
					this.loadingInstance.close();
					this.$message.error(err);
				})
				// const res =  axios({
				// 	method: "post",
				// 	url: "/uploadurl",
				// 	data: formData,
				// 	headers: {
				//  	"Content-Type": "multipart/form-data"
				// 	}
				// });
				//return res.data;
			},
			//手机号登录
			phoneLogin() {
				this.isPhoneShow = true;
			}
		}
	}
</script>

<style scoped>
	/* 清除浏览器默认边距，
	/* :nth-child(n) 选择器匹配父元素中的第 n 个子元素 */
	/* 登录框样式 */
	body {}
	::v-deep .el-icon-user:before{
		line-height: 40px;
	}
	::v-deep .el-icon-lock:before{
		line-height: 40px;
	}
	.box {
		box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;
		;
	}

	#box {
		height: 100vh;
		display: flex;
		align-items: center;
		justify-content: center;
		background-image: url('../assets/img/bg3.jpg');
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.footer {
		display: flex;
		justify-content: space-between;
	}

	::v-deep .el-icon-user:before {
		margin-left: 20px;
	}

	::v-deep .el-icon-lock:before {
		margin-left: 20px;
	}

	.container {
		width: 400px;
		min-height: 400px;
		background: rgba(0, 0, 0, 0.2);
		display: flex;
		justify-content: center;
		align-items: center;
		backdrop-filter: blur(5px);
		box-shadow: 0 25px 45px rgba(0, 0, 0, 0.1);
		border: 1px solid rgba(255, 255, 255, 0.5);
		border-right: 1px solid rgba(255, 255, 255, 0.2);
		border-bottom: 1px solid rgba(255, 255, 255, 0.2);
	}

	.form {
		/* position: relative; */
		width: 100%;
		height: 100%;
		padding: 50px;
		/* margin: auto; */
	}

	/* 登录标题样式 */

	.form h2 {
		position: relative;
		color: #fff;
		font-size: 24px;
		font-weight: 600;
		letter-spacing: 5px;
		margin-bottom: 30px;
		cursor: pointer;
	}

	/* 登录标题的下划线样式 */

	.form h2::before {
		content: "";
		position: absolute;
		left: 0;
		bottom: -10px;
		width: 0px;
		height: 3px;
		background: #fff;
		transition: 0.5s;
	}

	/* 	.form h2:hover:before {
		width: 53px;
	} */

	.form .inputBox {
		width: 100%;
		margin-top: 20px;
		text-align: center;
	}

	/* 输入框样式 */

	.form .inputBox ::v-deep input {
		width: 87%;
		padding: 10px 20px;
		background: rgba(255, 255, 255, 0.2);
		/* background-color: aqua; */
		outline: none;
		border: none;
		border-radius: 30px;
		border: 1px solid rgba(255, 255, 255, 0.5);
		border-right: 1px solid rgba(255, 255, 255, 0.2);
		border-bottom: 1px solid rgba(255, 255, 255, 0.2);
		font-size: 16px;
		letter-spacing: 1px;
		color: #fff;
		box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
	}

	.form .inputBox input::placeholder {
		color: #fff;
	}

	/* 登录按钮样式 */

	.form .inputBox input[type="submit"] {
		background: #fff;
		color: #666;
		max-width: 100px;
		margin-bottom: 20px;
		font-weight: 600;
		cursor: pointer;
		margin: 0px auto;
	}

	.forget {
		margin-top: 6px;
		color: #fff;
		letter-spacing: 1px;
		cursor: pointer;
	}

	.forget a {
		color: #fff;
		font-weight: 600;
		text-decoration: none;
	}

	#btnLogin:hover {
		background-color: ##F0FFF0;
		box-shadow: 0px 0px 10px 4px rgba(255, 255, 255, 0.4);
	}

	.forget:hover {
		color: #87CEFA;
	}


	.el-row {
		margin-bottom: 20px;

		&:last-child {
			margin-bottom: 0;
		}
	}

	.el-col {
		border-radius: 4px;
	}

	.bg-purple-dark {
		background: #99a9bf;
	}

	.bg-purple {
		background: #d3dce6;
	}

	.bg-purple-light {
		background: #e5e9f2;
	}

	.grid-content {
		border-radius: 4px;
		min-height: 36px;
	}

	.row-bg {
		padding: 10px 0;
		background-color: #f9fafc;
	}
</style>
