<template>
	<div>
		<div style="display: flex;">
			<!-- //头像 -->
			<div class="block" style="flex: 1;" v-if="user">
				<el-card class="box-card">
					<div style="border-bottom: 1px solid black;margin-bottom: 10px;height: 30px;">个人信息</div>
					<div style="text-align: center;">

						<!-- <el-avatar shape="square" :size="100" :src="user.accountImg" id="img"></el-avatar> -->
						<el-upload class="avatar-uploader" action="http://localhost:5000/api/user/upload"
							:show-file-list="false" :on-success="handleAvatarSuccess"
							:before-upload="beforeAvatarUpload" :data="uploadData" name="file">
							<img v-if="user.accountImg" id="img" :src="user.accountImg" class="avatar">
							<i v-else id="img" class="el-icon-plus avatar-uploader-icon"></i>
						</el-upload>
						<div style="text-align: center;">
							<el-link type="success" icon='el-icon-success' v-if="user.userImg!=null&&user.userImg!=''">
								已完成人脸认证</el-link>
							<el-link type="danger" icon='el-icon-error' v-else @click="show3 = !show3">未完成人脸认证</el-link>
						</div>
					</div>
					<div
						style="display: flex;justify-content:space-between;margin-top: 10px;border-bottom: 1px solid #DCDFE6;height: 30px;">
						<div class="el-icon-user">账号：</div>
						<div>{{user.account}}</div>
					</div>
					<div
						style="display: flex;justify-content:space-between;margin-top: 20px;border-bottom: 1px solid #DCDFE6;height: 30px;">
						<div class="el-icon-office-building">部门：</div>
						<div v-if="user.department.depaName!='总经理'">{{user.department.depaName}}</div>
						<div v-else>无部门</div>
					</div>
					<div
						style="display: flex;justify-content:space-between;margin-top: 20px;border-bottom: 1px solid #DCDFE6;height: 30px;">
						<div class="el-icon-s-custom">角色：</div>
						<div>{{user.role.roleName}}</div>
					</div>
					<div
						style="display: flex;justify-content:space-between;margin-top: 10px;border-bottom: 1px solid #DCDFE6;height: 30px;">
						<div class="el-icon-phone-outline">手机号：</div>
						<div>{{user.phone}}</div>
					</div>
					<div
						style="display: flex;justify-content:space-between;margin-top: 20px;border-bottom: 1px solid #DCDFE6;height: 30px;">
						<div class="el-icon-date">注册日期：</div>
						<div>{{user.addTime}}</div>
					</div>
					<div
						style="display: flex;justify-content:space-between;margin-top: 20px;border-bottom: 1px solid #DCDFE6;height: 30px;">
						<div class="el-icon-lock">账号状态：</div>
						<div v-if="user.isDelete==0"><span style="color: limegreen;">正常</span></div>
						<div v-else><span style="color: red;">已被注销</span></div>
					</div>
				</el-card>
			</div>
			<!-- 内容 -->
			<el-tabs v-model="activeName" style="margin-left:50px;flex: 1;" v-if="user!=null">
				<el-tab-pane label="更多信息" name="first">
					<div>
						<div>
							<el-card class="box-card">
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">昵称：</span>
										<el-input type="text" v-model="user.nickName" clearable></el-input>
									</el-col>
								</el-row>
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">性别：</span>
										<el-input type="text" v-model="user.sex" clearable></el-input>
									</el-col>
								</el-row>
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">年纪：</span>
										<el-input v-model="user.age" clearable
											oninput="value=value.replace(/[^0-9]/g,'')"></el-input>
									</el-col>
								</el-row>
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="display: block; width: 100px;">生日：</span>
										<el-date-picker v-model="user.birthday" type="datetime" placeholder="选择日期时间"
											style="width: 100%;" format="yyyy-MM-dd HH:mm">
										</el-date-picker>
									</el-col>
								</el-row>
								<!-- <el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">手机号：</span>
										<el-input type="text" v-model="user.phone" clearable></el-input>
									</el-col>
								</el-row> -->
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">QQ：</span>
										<el-input type="text" v-model="user.qq" clearable></el-input>
									</el-col>
								</el-row>
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">邮箱：</span>
										<el-input type="text" v-model="user.email" clearable></el-input>
									</el-col>
								</el-row>
								<el-row :gutter="20" style="margin: 0px 0px 10px 0px;">
									<el-col :span="20" style="display: flex;align-items: center;">
										<span style="width: 100px;">地址：</span>
										<el-input type="textarea" v-model="user.address" clearable></el-input>
									</el-col>
								</el-row>
								<el-row :gutter="20">
									<el-col :span="20"
										style="display: flex;align-items: center;justify-content: center;s">
										<el-button type="primary" icon="el-icon-edit" @click="editUserInfo">修改
										</el-button>
									</el-col>
								</el-row>
							</el-card>
						</div>
					</div>

				</el-tab-pane>
				<el-tab-pane label="修改密码" name="second">
					<el-card class="box-card">
						<div style="display: flex;align-items: center;margin-bottom:10px;">
							<div style="width: 100px;">旧密码：</div>
							<div>
								<el-input type="password" clearable v-model="oldPwd" show-password placeholder="请输入旧密码">
								</el-input>
							</div>
						</div>
						<div style="display: flex;align-items: center;margin-bottom:10px;">
							<div style="width: 100px;">新密码：</div>
							<div>
								<el-input type="password" clearable v-model="newPwd" show-password placeholder="请输入新密码">
								</el-input>
							</div>
						</div>
						<div style="display: flex;align-items: center;margin-bottom:10px;">
							<div style="width: 100px;">确认密码：</div>
							<div>
								<el-input type="password" clearable v-model="truePwd" show-password placeholder="请确认密码">
								</el-input>
							</div>
						</div>
						<div style="text-align: center;margin-top:20px">
							<el-button type="primary" icon="el-icon-edit" @click="updatePwd">修改</el-button>
						</div>
					</el-card>
				</el-tab-pane>
				<el-tab-pane label="换绑手机" name="three">
					<el-card class="box-card">
						<el-steps :active="active" finish-status="success">
							<el-step title="原手机">
							</el-step>
							<el-step title="新手机">
							</el-step>
							<el-step title="已完成">
							</el-step>
						</el-steps>
						<div id="oldPhone" style="margin-top:15px;">
							<div style="display: flex;align-items:center;margin-bottom:15px;">
								<div style="width: 100px;">原手机号：</div>
								<div style="width:60%;">
									<el-input type="text" clearable v-model="oldPhone" placeholder="请输入手机号"
										@change="isNull"></el-input>
								</div>
							</div>
							<div style="display: flex;align-items:center;">
								<div style="width: 100px;">验证码：</div>
								<div style="display: flex;width:60%;justify-content:space-between;">
									<el-input type="text" clearable v-model="oldCode" placeholder="请输入验证码"
										style="margin-right:20px;" @change="isNull"></el-input>
									<el-button type="success" size="small" style="width: 90px;padding: 12px 7px;"
										@click="sendCode" :disabled="oldCodeDisable">{{codeText}}</el-button>
								</div>
							</div>
							<div style="margin-top: 25px;text-align:right;display:flex;">
								<div style="width: 100px;"></div>
								<div style="width: 60%;">
									<el-button type="primary" size="small" @click="next" :disabled="nextIsAble">下一步<li
											class="el-icon-arrow-right" style="margin-left: 10px;"></li>
									</el-button>
								</div>
							</div>
						</div>
						<div id="newPhone" style="display: none;margin-top:15px;">
							<div style="display: flex;align-items:center;margin-bottom:15px;">
								<div style="width: 100px;">新手机号：</div>
								<div style="width:60%;">
									<el-input type="text" clearable v-model="newPhone" placeholder="请输入手机号"
										id="newPhone" @change="isNull_new"></el-input>
								</div>
							</div>
							<div style="display: flex;align-items:center;">
								<div style="width: 100px;">验证码：</div>
								<div style="display: flex;width:60%;justify-content:space-between;">
									<el-input type="text" clearable v-model="newCode" placeholder="请输入验证码"
										style="margin-right:20px;" @change="isNull_new"></el-input>
									<el-button type="success" size="small" style="width: 90px;padding: 12px 7px;"
										@click="sendNewCode" :disabled="newCodeDisable">{{newCodeText}}</el-button>
								</div>
							</div>
							<div style="margin-top: 25px;text-align:right;display:flex;">
								<div style="width: 100px;">
									<el-button type="primary" plain size="small" @click="back"
										icon="el-icon-arrow-left">上一步</el-button>
								</div>
								<div style="width: 60%;">
									<el-button type="primary" size="small" @click="finish" :disabled="isFinishShow">下一步
										<li class="el-icon-arrow-right" style="margin-left: 10px;"></li>
									</el-button>
								</div>
							</div>
						</div>
						<div id="result" style="display: none;">
							<el-result icon="success" title="修改完成" subTitle="手机号换绑完成">
								<template slot="extra">
									<el-button type="primary" size="medium" @click="backHome">返回</el-button>
								</template>
							</el-result>
						</div>
					</el-card>
				</el-tab-pane>
			</el-tabs>

			<div style="margin-left: 30px;margin-right: 50px;">
				<div style="margin-top: 20px; height: 200px;width:260px;">
					<div style="background-color: #c5f6fa;padding:10px;display:flex;border-radius:10%;" id="box">
						<div>
							
						</div>
						<div style="margin-top: auto;margin-left:15px;">
							<div style="color: #343a40;"></div>
							<div style="margin-top: 50px;color:#343a40;">
								<span></span>&emsp14;
								<span></span>
							</div>
							
						</div>
					</div>
					
				</div>
				
				<div>

					<el-collapse-transition>
						<div v-show="show3">
							<div
								style="width:250px;height:300px; box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);">
								<div v-loading="loading" element-loading-text="上传中..." style="height: 100%;">
									<video id="video" height="100%" autoplay="autoplay"
										style="width: 100%;object-fit: fill;"></video>
								</div>
							</div>
							<canvas id="canvas" width="500px" height="500px" style="display: none;"></canvas>
							<div style="text-align: center;margin-top:15px;margin-left:-8px;">
								<el-button type="primary" size="mini" :disabled="isOpen" @click="openMedia">开启摄像头
								</el-button>
								<el-button type="success" size="mini" :disabled="isUpload" @click="takePhoto">上传
								</el-button>
								<el-button type="danger" size="mini" :disabled="isClose" @click="closeMedia">关闭摄像头
								</el-button>
							</div>
						</div>
					</el-collapse-transition>

				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import {
		Loading
	} from 'element-ui'
	export default {
		data() {
			return {
				user: {
					department: {
						depaName: ''
					}
				},
				size: '300',
				userInfo: {

				},
				weather: {},
				activeName: 'first',
				oldPwd: '',
				newPwd: '',
				truePwd: '',
				imageUrl: '',
				uploadData: {},
				active: 1,
				oldPhone: '',
				newPhone: '',
				oldCode: '',
				newCode: '',
				nextIsAble: true,
				code: '', //后台传来的验证码
				codeText: '发送验证码',
				num: 120,
				oldCodeDisable: false,
				newCodeDisable: false,
				newCodeText: '发送验证码',
				newNum: 120,
				isFinishShow: false,
				oldTime: null,
				newTime: null,
				show3: false,
				//摄像头
				isOpen: false,
				isClose: true,
				isUpload: true,
				loading: false
			}
		},
		mounted() {
			this.Init();

		},
		methods: {
			//上传人脸 
			//开启摄像头
			openMedia() {
				var btnOpen = document.getElementById("btnOpen");
				if (this.isOpen) {
					return;
				} else {
					this.isOpen = true
					this.isClose = false
					this.isUpload = false
				}
				let video;
				let mediaStreamTrack = null;

				let constraints = {
					video: {
						width: 500,
						height: 500
					},
					audio: false
				};
				//获得video摄像头
				video = document.getElementById('video');
				let promise = navigator.mediaDevices.getUserMedia(constraints);

				promise.then((mediaStream) => {
					// mediaStreamTrack = typeof mediaStream.stop === 'function' ? mediaStream : mediaStream.getTracks()[1];
					mediaStreamTrack = mediaStream.getVideoTracks()
					video.srcObject = mediaStream;
					video.play();
				});
			},
			takePhoto() {
				//获得Canvas对象
				let video = document.getElementById('video');
				let canvas = document.getElementById('canvas');
				let ctx = canvas.getContext('2d');
				ctx.drawImage(video, 0, 0, 500, 500);
				// toDataURL  ---  可传入'image/png'---默认, 'image/jpeg'
				let img = document.getElementById('canvas').toDataURL();
				//console.log(img)
				video.pause();
				//获取文件流
				var blob = this.base64toFile(img, 'file');

				// //上传
				var result = this.uploadFile(blob);

				//console.log(result);
			},
			// 关闭摄像头
			closeMedia() {
				var btnClose = document.getElementById("btnClose");
				if (this.isClose) {
					return;
				} else {
					this.isOpen = false;
					this.isClose = true;
					this.isUpload = true;
				}
				let stream = document.getElementById('video').srcObject;
				let tracks = stream.getTracks();

				tracks.forEach(function(track) {
					track.stop();
				});

				document.getElementById('video').srcObject = null;
			},
			// 将base64转成图片文件流
			base64toFile(data, fileName) {
				const dataArr = data.split(",");
				const byteString = atob(dataArr[1]);
				const options = {
					type: "image/jpeg",
					endings: "native"
				};
				const u8Arr = new Uint8Array(byteString.length);
				for (let i = 0; i < byteString.length; i++) {
					u8Arr[i] = byteString.charCodeAt(i);
				}
				return new File([u8Arr], fileName + ".jpg", options); //返回文件流
			},
			uploadFile(blob) {
				var user = JSON.parse(localStorage.getItem("userInfo"));
				//等待
				this.loading = true;
				// this.loadingInstance = Loading.service({
				// 	text: "上传中...",
				// 	spinner: 'el-icon-loading',
				// 	background: 'rgba(0,0,0,0.7)'
				// });

				const formData = new FormData();
				formData.append("file", blob);
				formData.append("id", user.id);
				this.request.post("/user/upload/userImg", formData, {
					headers: {
						"Content-Type": "multipart/form-data"
					}
				}).then(res => {
					//console.log(res);

					if (res.code == 200) {
						this.loading = false;
						this.Init();
						//localStorage.setItem("userInfo",JSON.stringify(res.data.userInfo));
						this.$message.success("认证成功");
						this.closeMedia();
						this.show3 = false;
						//this.$router.push("/home");
					} else {
						//关闭摄像头
						this.closeMedia();
						this.drawer = false;
						this.centerDialogVisible = false;
						//document.getElementById("account").focus();
						this.$message.error(res.msg);
					}
				}).catch(err => {
					this.loading = false;
					this.$message.error(err);
				})
			},



			//发送验证码(新手机)
			sendNewCode() {
				const regex = /^1[3456789]\d{9}$/; //使用此正则
				if (!regex.test(this.newPhone)) {
					this.$message.error("手机号格式不正确");
					//光标定位
					document.getElementById("newPhone").focus();
					return;
				}
				this.codeText = this.newNum--;
				this.newCodeDisable = true;
				//记时间
				this.oldTime = setInterval(() => {
					this.newCodeText = this.newNum--;
					if (this.newNum < 0) {
						this.newNum = 120;
						this.newCodeDisable = false;
						this.newCodeText = "发送验证码"
						clearInterval(this.oldTime);
					}
				}, 1000)

				//发送请求
				this.request.get("/user/" + this.newPhone + "/" + this.oldPhone).then(res => {
					if (res.code == 200) {
						this.$message.success("验证码发成功请注意查收");
					} else {
						this.$message.error(res.msg);
					}
				});

			},
			//是否为空
			isNull_new() {
				if (this.newPhone == "" || this.newCode == "") {
					this.isFinishShow = true;
				} else {
					this.isFinishShow = false;
				}
			},
			//发送验证码(旧手机)
			sendCode() {
				const regex = /^1[3456789]\d{9}$/; //使用此正则
				if (!regex.test(this.oldPhone)) {
					this.$message.error("手机号格式不正确");
					//光标定位
					document.getElementById("oldPhone").focus();
					return;
				}

				this.codeText = this.num--;
				this.oldCodeDisable = true;
				//发送请求
				this.request.get("/login/phone/" + this.oldPhone).then(res => {
					if (res.code == 200) {
						this.$message.success("验证码发成功请注意查收");
					} else {
						this.$message.error(res.msg);
					}
				});

				//记时间
				this.newTime = setInterval(() => {
					this.codeText = this.num--;
					if (this.num < 0) {
						this.num = 120;
						this.oldCodeDisable = false;
						this.codeText = "发送验证码"
						clearInterval(this.newTime);
					}
				}, 1000)
			},
			//点击下一步
			next() {
				const regex = /^1[3456789]\d{9}$/; //使用此正则
				if (!regex.test(this.oldPhone)) {
					this.$message.error("手机号格式不正确");
					//光标定位
					document.getElementById("oldPhone").focus();
					return;
				}
				this.active++;
				var oldPhone = document.getElementById("oldPhone");
				var newPhone = document.getElementById("newPhone");
				oldPhone.style = "display:none";
				newPhone.style = "display:block";
				newPhone.style = "margin-top:15px";
				//var next= document.getElementById("next");
			},
			//判断手机号是否为空
			isNull() {
				if (this.oldPhone == "" || this.oldCode == "") {
					this.nextIsAble = true;
				} else {
					this.nextIsAble = false;
				}
			},
			//返回上一步
			back() {
				this.active--;
				var oldPhone = document.getElementById("oldPhone");
				var newPhone = document.getElementById("newPhone");
				newPhone.style = "display:none";
				oldPhone.style = "display:block";
				oldPhone.style = "margin-top:15px";
			},
			//完成
			finish() {
				//发送请求
				this.request.get("/user/setPhone/" + this.user.id + "/" + this.newPhone + "/" + this.newCode).then(res => {
					if (res.code == 200) {
						this.active++;
						var oldPhone = document.getElementById("oldPhone");
						var newPhone = document.getElementById("newPhone");
						var result = document.getElementById("result");
						newPhone.style = "display:none";
						oldPhone.style = "display:none";
						result.style = "display:block";
						result.style = "margin-top:15px";
						this.user.phone = res.data;
						var user = JSON.parse(localStorage.getItem("userInfo"));
						user.phone = res.data;
						localStorage.setItem("userInfo", JSON.stringify(user));

						this.$message.success(res.msg);
					} else {
						this.$message.error(res.msg);
					}
				})

			},
			//返回第一页
			backHome() {
				var oldPhone = document.getElementById("oldPhone");
				var result = document.getElementById("result");
				result.style = "display:none";
				oldPhone.style = "display:block";
				oldPhone.style = "margin-top:15px";
				this.active = 1;

				this.oldPhone = "";
				this.oldCode = "";
				this.newPhone = "";
				this.newCode = "";
				this.codeText = "发送验证码";
				this.newCodeText = "发送验证码";
				this.num = 120;
				this.newNum = 120;
				clearTimeout(this.oldTime);
				clearTimeout(this.newTime);
				this.oldCodeDisable = false;
				this.nextIsAble = true;
				this.newCodeDisable = false;
				this.isFinishShow = true;
			},



			//初始化
			Init() {

				var user = JSON.parse(localStorage.getItem("userInfo"));

				this.request.get("/user/" + user.account).then(res => {
					console.log(res.data);
					this.user = res.data;
					this.uploadData = {
						'account': this.user.account
					};
				});
				this.request.get("/weather").then(res => {
					console.log(res);
					//this.weather = res.data;
					//this.weather.info.high = this.weather.info.high.split(' ')[1]
				})
			},
			//修改用户
			editUserInfo() {
				console.log(this.user.birthday)
				var user = JSON.parse(localStorage.getItem("userInfo"));
				//var data=new FormData();
				//data.append("userInfo",this.user);
				if (this.user.age == "" || this.user.age == undefined) {
					this.$message.error("年纪不能为空")
					return;

				}
				if (this.user.email == "" || this.user.email == undefined) {
					this.$message.error("年邮箱不能为空");
					return;
				}
				var verify = /^\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/;
				if (!verify.test(this.user.email)) {
					this.$message.error('邮箱格式错误, 请重新输入');
					return;
				}

				this.request.post("/user", this.user).then(res => {
					if (res.code == 200) {
						this.Init();
						const nickname = this.user.nickName;

						this.$root.nickName = nickname;
						this.$message.success(res.msg);
					} else {
						this.$message.error(res.msg);
					}
				})

			},
			//上传图片
			handleAvatarSuccess(res, file) {
				if (res.code == 200) {
					this.$message.success(res.msg)
					this.$root.accountImg = res.data;
					this.user.accountImg = res.data
				} else {
					this.$message.error(res.msg);
				}

			},
			beforeAvatarUpload(file) {
				const isJPG = file.type === 'image/jpeg';
				const IsPNG = file.type === "image/png";
				const IsBMP = file.type === "image/bmp";
				const ISJPEG = file.type === "image/jpg";
				const IsGIF = file.type === "image/gif";
				const isLt2M = file.size / 1024 / 1024 < 20;
				if (!isJPG && !IsPNG && !IsBMP && !IsJPEG && !IsGIF) {
					this.$message.error('上传头像图片格式不正确!');
				}
				if (!isLt2M) {
					this.$message.error('上传头像图片大小不能超过 20MB!');
				}
				return isJPG && isLt2M;
			},
			//修改密码
			updatePwd() {
				if (this.oldPwd == '' || this.newPwd == '' || this.truePwd == '') {
					this.$message.error("请填写完整");
					return;
				}
				if (this.newPwd != this.truePwd) {
					this.$message.error("两次输入的密码不一致");
					return;
				} else {
					this.request.get("/user/" + this.user.id + "/" + this.oldPwd + "/" + this.newPwd).then(res => {
						if (res.code == 200) {
							this.$message.success("密码修改成功，请重新登录");
							//移除存入的信息
							localStorage.removeItem("userInfo");
							//跳转页面吗
							this.$router.push("/");
						} else {
							this.$message.error(res.msg);
						}
					})
					//$root
				}
			}

		}
	}
</script>

<style scoped>
	#img {
		box-shadow: 8px 5px 6px rgba(0, 0, 0, .12), 4px 4px 6px 4px rgba(0, 0, 0, .04)
	}
	#box{
		box-shadow: 8px 5px 6px rgba(0, 0, 0, .12), 4px 4px 6px 4px rgba(0, 0, 0, .04)
	}
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}

	.transition-box {
		width: 250px;
		margin-bottom: 10px;
		/* width: 200px; */
		height: 250px;
		border-radius: 4px;
		background-color: #409EFF;
		text-align: center;
		color: #fff;
		padding: 40px 20px;
		box-sizing: border-box;
		/* margin-right: 20px; */
	}
</style>
