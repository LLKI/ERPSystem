<template>
	<div>
		<div class="head"
			style="margin-bottom: 10px;display: flex;align-items: center;justify-content: space-between;width: 100%;">
			<div>
				公告类型：
				<el-select v-model="value.typeId" clearable placeholder="请选择">
					<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</div>
			<div>
				<el-button type="success" icon="el-icon-check" @click="send">发布</el-button>
			</div>
		</div>
		<div class="title"
			style="display: flex;justify-content:center;width: 20%;margin: 0px auto;align-items: center;">
			<div style="width: 80px;">标题：</div>
			<el-input type="text" placeholder="请输入内容" v-model="value.title" maxlength="15" show-word-limit>
			</el-input>
		</div>
		<div class="edit_container" style="height: 100%;margin-top: 0px;">
			<!-- 图片上传组件辅助-->
			<el-upload class="avatar-uploader" :action="uploadUrl" name="files" :show-file-list="false"
				:on-success="uploadSuccess">
			</el-upload>
			<quill-editor v-model="value.content" ref="QuillEditor" :options="editorOption" @blur="onEditorBlur($event)"
				@focus="onEditorFocus($event)" @change="onEditorChange($event)" style="height: 66vh;">
			</quill-editor>
		</div>
	</div>
</template>

<script>
	// import {
	// 	quillEditor
	// } from "vue-quill-editor"; //调用编辑器
	// import 'quill/dist/quill.core.css';
	// import 'quill/dist/quill.snow.css';
	// import 'quill/dist/quill.bubble.css';

	// // 新增下面代码：改变图片大小
	// import resizeImage from 'quill-image-resize-module' // 调整大小组件。
	// import {
	// 	ImageDrop
	// } from 'quill-image-drop-module'; // 拖动加载图片组件。
	// Quill.register('modules/imageDrop', ImageDrop);
	// Quill.register('modules/resizeImage ', resizeImage)
	import 'quill/dist/quill.core.css'
	import 'quill/dist/quill.snow.css'
	import 'quill/dist/quill.bubble.css'
	import Quill from 'quill'
	import {
		quillEditor
	} from 'vue-quill-editor'
	import {
		ImageDrop
	} from 'quill-image-drop-module'
	import ImageResize from 'quill-image-resize-module'
	Quill.register('modules/imageDrop', ImageDrop)
	Quill.register('modules/imageResize', ImageResize)
	export default {
		components: {
			quillEditor
		},
		data() {
			return {
				content: '',
				editorOption: {
					placeholder: "请在这里输入",
					modules: {
						history: {
							delay: 1000,
							maxStack: 50,
							userOnly: false
						},
						imageDrop: true,
						imageResize: {
							displayStyles: {
						 	backgroundColor: 'black',
								border: 'none',
								color: 'white'
							},
							modules: ['Resize', 'DisplaySize', 'Toolbar']
						},
						toolbar: {
							container: [
								['bold', 'italic', 'underline', 'strike'], //加粗，斜体，下划线，删除线
								['blockquote', 'code-block'], //引用，代码块
								[{
									'header': 1
								}, {
									'header': 2
								}], // 标题，键值对的形式；1、2表示字体大小
								[{
									'list': 'ordered'
								}, {
									'list': 'bullet'
								}], //列表
								[{
									'script': 'sub'
								}, {
									'script': 'super'
								}], // 上下标
								[{
									'indent': '-1'
								}, {
									'indent': '+1'
								}], // 缩进
								[{
									'direction': 'rtl'
								}], // 文本方向
								[{
									'size': ['small', false, 'large', 'huge']
								}], // 字体大小
								[{
									'header': [1, 2, 3, 4, 5, 6, false]
								}], //几级标题
								[{
									'color': []
								}, {
									'background': []
								}], // 字体颜色，字体背景颜色
								[{
									'font': []
								}], //字体
								[{
									'align': []
								}], //对齐方式
								['clean'], //清除字体样式
								['image', 'video'] //上传图片、上传视频
							],
							handlers: {
								image: function(value) {
									if (value) {
										// 调用element的图片上传组件
										document.querySelector('.avatar-uploader input').click()
									} else {
										this.quill.format('image', false)
									}
								}
							},
						},
					}
				},
				title: '',
				options: [],
				value: {},
				uploadUrl: 'http://localhost:5000/api/notify/upload'
			}
		},
		created() {
			this.Init();
		},
		methods: {
			Init() {
				this.request.get("/notify/type").then(res => {
					var list = res.data;

					for (var i = 0; i < list.length; i++) {
						if(list[i].typeName!="我的消息"){
							var content = {
								value: list[i].id,
								label: list[i].typeName
							};
							this.options.push(content);
						}
						
					}
				})
			},
			onEditorReady(editor) { // 准备编辑器

			},
			onEditorBlur() {}, // 失去焦点事件
			onEditorFocus() {}, // 获得焦点事件
			onEditorChange() {}, // 内容改变事件
			send() {
				var id = JSON.parse(localStorage.getItem("userInfo")).id;
				this.value.userId = id;
				if(this.value.title==undefined){
					this.$message.error("请输入标题");
					return;
				}else if(this.value.typeId==undefined){
					this.$message.error("请选择类型");
					return;
				}
				this.request.post("/notify", this.value).then(res => {
					console.log(res);
					if (res.code == 200) {
						this.$message.success("发表成功");
						this.$router.push("/home");
						
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			uploadSuccess(res) {
				// 获取富文本组件实例
				let quill = this.$refs.QuillEditor.quill;
				// 如果上传成功
				if (res) {
					// 获取光标所在位置
					let length = quill.getSelection().index;
					// 插入图片，res为服务器返回的图片链接地址
					quill.insertEmbed(length, 'image', res.data.url)
					// 调整光标到最后
					quill.setSelection(length + 1)
				} else {
					// 提示信息，需引入Message
					this.$message.error('图片插入失败！')
				}
			},
			// 转码
			escapeStringHTML(str) {
				str = str.replace(/&lt;/g, '<');
				str = str.replace(/&gt;/g, '>');
				return str;
			}
		},
		computed: {
			editor() {
				return this.$refs.myQuillEditor.quill;
			},
		}
	}
</script>

<style>
</style>
