<template>
	<div>
		<div style="margin-bottom: 20px;">
			<el-input placeholder="请输入类型名称" v-model="typeName" clearable style="width: 200px;">
			</el-input>
			<el-button type="primary" icon="el-icon-search" style="margin-left: 20px;" @click="search">搜索</el-button>
		</div>
		<div>
			<el-table :data="notifyTypeList" stripe style="width: 100%;" border highlight-current-row
				:cell-style="rowStyle" :header-cell-style="{color:'black'}">
				<el-table-column prop="id" label="类型编号" align="center">
				</el-table-column>
				<el-table-column prop="typeName" label="类型名称" align="center">
				</el-table-column>
				<el-table-column prop="sign" label="标识" align="center">
					<template slot-scope="scope">
						<el-tag type="danger">{{scope.row.sign}}</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="类型图标" align="center">
					<template slot-scope="scope">
						<span :class="scope.row.icon" style="font-size:30px;"></span>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center">

				</el-table-column>
				<el-table-column label="操作" align="center">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference" style="margin-right: 5px;"
								size="small">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id)" size="small">修改
						</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>

		<div>
			<el-dialog :title="title" :visible.sync="dialogVisible" width="30%">
				<div>
					<div style="display: flex;">
						<div style="width: 100px;">类型名称：</div>
						<div>
							<el-input v-model="notifyType.typeName" clearable placeholder="请输入类型名称"></el-input>
						</div>
					</div>
					<div style="display: flex;margin-top: 15px;">
						<div style="width: 100px;">标识：</div>
						<div>
							<el-tag type="danger">{{notifyType.sign}}</el-tag>
						</div>
					</div>
					<div style="display: flex;margin-top: 15px;">
						<div style="width: 100px;">类型图标：</div>
						<div>
							<el-select v-model="notifyType.icon" clearable placeholder="请选择" style="width: 100%;">
								<template slot="prefix">
									<span style="padding: 5px;line-height: 40px;font-size: 18px; color: #409eff;">
										<i :class="notifyType.icon"></i>
									</span>
								</template>
								<el-option v-for="item in options"  :class="item.label"
									:label="item.label" :value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
				</div>
				<span slot="footer" class="dialog-footer">
					<el-button @click="dialogVisible = false">取 消</el-button>
					<el-button type="primary" @click="option" icon="el-icon-circle-check">确 定</el-button>
				</span>
			</el-dialog>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				notifyTypeList: [],
				typeName: '',
				dialogVisible: false,
				title: "",
				notifyType:{},
				options:[]
			}
		},
		methods: {
			rowStyle() {
				return "text-align:center";
			},
			option(){
				
				this.request.put("/notify/notifyType",this.notifyType).then(res=>{
					if(res.code==200){
						this.Init();
						this.dialogVisible = false;
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//初始化
			Init() {
				this.request.get("/notify/type").then(res => {
					this.notifyTypeList = res.data;
				});
				
				// 图标
				this.request.get("/icon").then(res => {
					if (res.code == 200) {
						this.options = [];
						for (var i = 0; i < res.data.length; i++) {
							let obj = {
								label: res.data[i].name,
								value: res.data[i].name,
							}
							this.options.push(obj)
						}
					}
				});
			},
			//显示修改的窗体
			editData(id) {
				this.title = "修改公告类型";
				this.dialogVisible = true;
				
				this.request.get("/notify/notifyType/"+id).then(res=>{
					if(res.code==200){
						console.log(res.data);
						this.notifyType=res.data;
					}
				})
			},
			//搜索
			search() {
				this.request.get("/notify/type/" + this.typeName).then(res => {
					if (res.code = 200) {
						this.notifyTypeList = res.data;
					}
				})
			},
			delData(id) {
				this.request.delete("notify/notifyType/"+id).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			}

		},
		created() {
			this.Init();
		}
	}
</script>

<style>
</style>
