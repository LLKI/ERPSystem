<template>
	<div>
		<div class="head" style="margin-bottom: 20px;">
			<el-input placeholder="请输入公告标题" v-model="title" clearable style="width: 200px;"></el-input>
			<span style="margin: 0px 20px;">类别:</span>
			<el-select v-model="type" clearable placeholder="请选择">
				<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
				</el-option>
			</el-select>
			<el-button type="primary" icon="el-icon-search" style="margin-left: 20px;" @click="search">搜索</el-button>
			<el-button type="danger" icon="el-icon-remove" style="margin-left: 20px;" @click="delData_batch">批量删除
			</el-button>
		</div>
		<div>
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black'}" :row-style="{height:'10px'}"
				@selection-change="handleSelectionChange" ref="multipleTable">
				<el-table-column type="selection" width="55">
				</el-table-column>
				<el-table-column prop="id" label="公告编号" align="center">
				</el-table-column>
				<el-table-column prop="title" label="公告标题" align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.type.sign!='MYNEWS'">{{scope.row.title}}</span>
						<span v-else v-html="scope.row.title"></span>
					</template>
				</el-table-column>
				<el-table-column label="公告类型" align="center">
					<template slot-scope='scope'>
						<el-tag :color="scope.row.type.tabColor">{{scope.row.type.typeName}}</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="内容详情" align="center">
					<template slot-scope="scope">
						<span class="el-icon-view" style="cursor: pointer;font-size: 20px;color: green;"
							@click="look(scope.row.id)"></span>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center">
				</el-table-column>
				<el-table-column label="操作" align="center">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id,scope.row.type.id)"
							style="padding:10px;font-size: 10px;" v-if="scope.row.type.sign!='MYNEWS'">修改</el-button>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id,scope.row.type.id)"
							style="padding:10px;font-size: 10px;" v-else disabled>修改</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
		<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">

			<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page.sync="param.pageIndex" :page-sizes="[5, 7,10,15]" :page-size="param.pageSize"
				layout="sizes, prev, pager, next,total" :total="param.total">
			</el-pagination>
		</div>

		<!-- 弹出框 -->
		<div>
			<el-dialog title="内容详情" :visible.sync="dialogVisible" style="min-width: 30%;">
				<div v-html="content">

				</div>
				<span slot="footer" class="dialog-footer">
					<!-- <el-button @click="dialogVisible = false">取 消</el-button>
					<el-button type="primary" @click="dialogVisible = false">确 定</el-button> -->
				</span>
			</el-dialog>
		</div>


		<!-- 编辑弹出窗 -->

		<el-drawer title="编辑内容" :visible.sync="isShowEdit" :direction="direction" :before-close="handleClose"
			style="width: 60%;height: 100%;margin: 0px auto;" size='80%'>
			<div style="display: flex;justify-content: center;width: 90%;margin: 0px auto;">
				<div>
					<span>公告类型：</span>
					<el-select v-model="value.typeId" clearable placeholder="请选择" ref="typeList">
						<el-option v-for="(item,index) in typeList" :key="index" :label="item.label"
							:value="item.value">
						</el-option>
					</el-select>
				</div>
				<div class="title"
					style="display: flex;justify-content:center;width: 30%;margin: 0px auto;align-items: center;">
					<div style="width: 80px;">标题：</div>
					<el-input type="text" placeholder="请输入内容" v-model="value.title" maxlength="15" show-word-limit>
					</el-input>
				</div>
				<div>
					<el-button type="primary" @click="editNotify" icon="el-icon-edit">修改</el-button>
				</div>
			</div>

			<div class="edit_container" style="height:90%;margin-top: 0px;">
				<!-- 图片上传组件辅助-->
				<el-upload class="avatar-uploader" :action="uploadUrl" name="files" :show-file-list="false"
					:on-success="uploadSuccess">
				</el-upload>
				<quill-editor v-model="value.content" ref="QuillEditor" :options="editorOption"
					@blur="onEditorBlur($event)" @focus="onEditorFocus($event)" @change="onEditorChange($event)"
					style="height: 50vh;">
				</quill-editor>
			</div>
		</el-drawer>

	</div>
</template>

<script>
	import 'quill/dist/quill.core.css'
	import 'quill/dist/quill.snow.css'
	import 'quill/dist/quill.bubble.css'
	import Quill from 'quill'
	import {
		quillEditor
	} from 'vue-quill-editor'
	import {
		ImageDrop
	} from 'quill-image-drop-module'
	import ImageResize from 'quill-image-resize-module'
	Quill.register('modules/imageDrop', ImageDrop)
	Quill.register('modules/imageResize', ImageResize)
	export default {
		components: {
			quillEditor
		},
		data() {
			return {
				myList: [],
				param: {
					id: JSON.parse(localStorage.getItem("userInfo")).id,
					pageIndex: 1,
					pageSize: 5,
					total: 0,
					typeName: '',
					title: ''
				},
				title: '',
				options: [],
				type: '',
				dialogVisible: false,
				content: "",
				isShowEdit: false,
				value: {
					content: '',
					title: '',
					typeId: ''
				},
				direction: 'ttb',
				editorOption: {
					placeholder: "请在这里输入",
					modules: {
						history: {
							delay: 1000,
							maxStack: 50,
							userOnly: false
						},
						imageDrop: true,
						imageResize: {
							displayStyles: {
								backgroundColor: 'black',
								border: 'none',
								color: 'white'
							},
							modules: ['Resize', 'DisplaySize', 'Toolbar']
						},
						toolbar: {
							container: [
								['bold', 'italic', 'underline', 'strike'], //加粗，斜体，下划线，删除线
								['blockquote', 'code-block'], //引用，代码块
								[{
									'header': 1
								}, {
									'header': 2
								}], // 标题，键值对的形式；1、2表示字体大小
								[{
									'list': 'ordered'
								}, {
									'list': 'bullet'
								}], //列表
								[{
									'script': 'sub'
								}, {
									'script': 'super'
								}], // 上下标
								[{
									'indent': '-1'
								}, {
									'indent': '+1'
								}], // 缩进
								[{
									'direction': 'rtl'
								}], // 文本方向
								[{
									'size': ['small', false, 'large', 'huge']
								}], // 字体大小
								[{
									'header': [1, 2, 3, 4, 5, 6, false]
								}], //几级标题
								[{
									'color': []
								}, {
									'background': []
								}], // 字体颜色，字体背景颜色
								[{
									'font': []
								}], //字体
								[{
									'align': []
								}], //对齐方式
								['clean'], //清除字体样式
								['image'] //上传图片、上传视频
							],
							handlers: {
								image: function(value) {
									if (value) {
										// 调用element的图片上传组件
										document.querySelector('.avatar-uploader input').click()
									} else {
										this.quill.format('image', false)
									}
								}
							},
						},
					}
				},

				uploadUrl: 'http://localhost:5000/api/notify/upload',
				selectId: '',
				editContent: '',
				typeList: [],
				ids:[]
			}
		},
		created() {
			this.Init(this.param);
		},
		methods: {
			Init(param) {
				//获取类型列表
				this.options = [];
				this.typeList = [];
				this.request.get("/notify/type").then(res => {
					var notifyTypeList = res.data;
					for (var i = 0; i < notifyTypeList.length; i++) {
						var content = {
							value: notifyTypeList[i].typeName,
							label: notifyTypeList[i].typeName,
						};
						var content2 = {
							value: notifyTypeList[i].id,
							label: notifyTypeList[i].typeName,
						}
						this.options.push(content);
						this.typeList.push(content2);
					}
				});
				this.request.post("/notify/self", param).then(res => {
					if (res.code == 200) {
						console.log(res);
						this.param.total = parseInt(res.msg);
						this.myList = res.data;
						console.log(this.myList)
					}
				})
			},
			//批量删除
			delData_batch() {
				if(this.ids.length<=0){
					this.$message.warning("请先选择数据");
					return;
				}
				
				this.request.put("/notify/self",this.ids).then(res=>{
					if(res.code==200){
						this.Init(this.param);
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			handleSelectionChange(val) {
				for (var i = 0; i < val.length; i++) {
					this.ids.push(val[i].id);
				}
			},
			//切换页码
			handleCurrentChange(index) {
				this.param.pageIndex = index;
				this.Init(this.param);
			},
			handleSizeChange(pageSize) {
				this.param.pageSize = pageSize;
				this.Init(this.param);
			},
			//搜索
			search() {
				this.param.typeName = this.type;
				this.param.title = this.title;
				this.Init(this.param);
			},
			//查看详情
			look(id) {
				this.dialogVisible = true;
				this.request.get("/notify/" + id).then(res => {
					this.content = res.data.content;
				})
			},
			//修改内容
			editData(id, typeId) {

				this.value.typeId = typeId;
				this.request.get("/notify/" + id).then(res => {
					this.selectId = res.data.id;
					this.value.content = res.data.content;
					this.value.title = res.data.title;
					//this.editContent=res.data.content
				});

				this.isShowEdit = true;
			},
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {});
			},
			onEditorReady(editor) { // 准备编辑器
			},
			onEditorBlur() {}, // 失去焦点事件
			onEditorFocus() {}, // 获得焦点事件
			onEditorChange() {
				//this.value.content=this.editContent;
				let quill = this.$refs.QuillEditor.quill // 获取富文本编辑器
				var length = this.value.content.length // 获取光标位置
				setTimeout(() => { //将光标插入文本最后
					quill.setSelection(length + 1);
				}, 1);
			}, // 内容改变事件
			uploadSuccess(res) {
				// 获取富文本组件实例
				let quill = this.$refs.QuillEditor.quill;
				// 如果上传成功
				if (res) {
					// 获取光标所在位置
					let length = quill.getSelection().index;
					// 插入图片，res为服务器返回的图片链接地址
					quill.insertEmbed(length, 'image', res.data.url)
					// 调整光标到最后
					quill.setSelection(length + 1)
				} else {
					// 提示信息，需引入Message
					this.$message.error('图片插入失败！')
				}
			},
			// 转码
			escapeStringHTML(str) {
				str = str.replace(/&lt;/g, '<');
				str = str.replace(/&gt;/g, '>');
				return str;
			},
			//将修改的内容 提交到数据库
			editNotify() {
				this.request.put("/notify/update/" + this.selectId, this.value).then(res => {
					if (res.code == 200) {
						this.$message.success(res.msg);
						this.Init(this.param);
						this.isShowEdit = false;

					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//删除公告
			delData(id) {
				this.request.delete("/notify/delete/" + id).then(res => {
					if (res.code == 200) {
						this.$message.success(res.msg);
						this.Init(this.param);
					} else {
						this.$message.error(res.msg);
					}
				})
			}
		},
		computed: {
			editor() {
				return this.$refs.myQuillEditor.quill;
			},
		}

	}
</script>

<style>
</style>
