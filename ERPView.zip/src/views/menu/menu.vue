<template>
	<div>
		<div>
			<el-button type="primary" icon="el-icon-circle-plus-outline" @click="addMenu">添加</el-button>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}" tooltip-effect="dark"
				ref="multipleTable" >
				<el-table-column prop="id" label="编号" align="center">
				</el-table-column>
				<el-table-column prop="menuName" label="菜单名称" align="center">
				</el-table-column>
				<el-table-column prop="icon" label="图标" align="center">
					<template slot-scope="scope">
						<i :class="scope.row.icon" style="font-size: 20px;"></i>
					</template>
				</el-table-column>
				
				<el-table-column  label="子菜单" align="center">
					<template slot-scope="scope">
						<li class="el-icon-view" style="font-size: 20px;color: #67c23a;cursor: pointer;" @click="lookSon(scope.row.id)"></li>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="remark" label="备注" align="center">
				</el-table-column>
				<el-table-column align="center" label="操作">
					<template slot-scope="scope">
						<el-button type="success" icon="el-icon-edit" size="mini" @click="showEdit(scope.row.id)">修改
						</el-button>
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delMenu(scope.row.id)"
							style="margin-left: 10px;">
							<el-button type="danger" icon="el-icon-delete" size="mini" slot="reference">删除
							</el-button>
						</el-popconfirm>
					</template>
				</el-table-column>
			</el-table>
		</div>

		<!-- 弹窗 -->
		<div>
			<el-drawer :title="title" :visible.sync="drawer" direction="ttb" style="width: 25%;margin: 0px auto;"
				size="60%">
				<div style="padding: 15px;width: 90%;position: relative;">
					<div style="display: flex;margin-top: 15px;">
						<div style="width: 150px;">菜单名称：</div>
						<div style="width: 100%;">
							<el-input clearable v-model="menu.menuName" placeholder="请输入菜单名称"></el-input>
						</div>
					</div>
					
					<div style="display: flex;margin-top: 15px;" v-if="title=='添加菜单'">
						<div style="width: 150px;">分配角色：</div>
						<div style="width: 100%;">
							<el-select v-model="menu.ids" clearable placeholder="请选择角色" style="width: 100%;" multiple>
								<el-option v-for="item in roleOptions"  :class="item.label"
									:label="item.label" :value="item.value">
									<!-- <template slot="prefix">
										<span style="padding: 5px;line-height: 40px;font-size: 18px; color: #409eff;">
											<i :class="sonMenu.icon"></i>
										</span>
									</template> -->
									<!-- <span style="float: left;color:rgb(8,131,216);">
										<i :class="item.icon"></i>
									</span> -->
									<!-- <span style="float: right; color: #8492a6; font-size: 13px">{{ item.label }}</span> -->
								</el-option>
							</el-select>
						</div>
					</div>
					
					<div style="display: flex;margin-top: 15px;">
						<div style="width: 150px;">菜单图标：</div>
						<div style="width: 100%;">
							<el-select v-model="menu.icon" clearable placeholder="请选择" >
								<template slot="prefix">
									<span style="padding: 5px;line-height: 40px;font-size: 18px; color: #409eff;">
										<i :class="menu.icon"></i>
									</span>
								</template>
								<el-option v-for="item in options"  :class="item.label"
									:label="item.label" :value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
					<div style="display: flex;margin-top: 15px;">
						<div style="width: 150px;">备注：</div>
						<div style="width: 100%;">
							<el-input type="textarea" v-model="menu.remark" placeholder="请输入备注"></el-input>
						</div>
					</div>
					<div style="margin-top: 20px;position: absolute;right: 0;padding: 15px;">
						<el-button type="primary" icon="el-icon-check" @click="option">确定</el-button>
					</div>
				</div>
			</el-drawer>
		</div>
	
		<!--子菜单  -->
		<div>
			 <el-dialog title="子菜单" :visible.sync="outerVisible" width="80%">
				 <div style="margin-bottom: 10px;">
				 	<el-button type="primary" icon="el-icon-circle-plus-outline" @click="addSonMenu">添加</el-button>
				 </div>
				 <div>
					 <el-table :data="sonMenuList" stripe style="width: 100%;" border highlight-current-row
					 	:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}" tooltip-effect="dark"
					 	ref="multipleTable" >
					 	<el-table-column prop="id" label="编号" align="center">
					 	</el-table-column>
					 	<el-table-column prop="menuName" label="菜单名称" align="center">
					 	</el-table-column>
						<el-table-column prop="url" label="路径" align="center">
						</el-table-column>
					 	<el-table-column prop="icon" label="图标" align="center">
					 		<template slot-scope="scope">
					 			<i :class="scope.row.icon" style="font-size: 20px;"></i>
					 		</template>
					 	</el-table-column>
					 	
					 	<el-table-column prop="addTime" label="添加时间" align="center">
					 		<template slot-scope="scope">
					 			<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					 		</template>
					 	</el-table-column>
						<el-table-column prop="remark" label="备注" align="center">
						</el-table-column>
					 	<el-table-column align="center" label="操作" width="180px">
					 		<template slot-scope="scope">
					 			<el-button type="primary" icon="el-icon-edit" size="mini" @click="showSonMenuEdit(scope.row.id)">修改
					 			</el-button>
					 			<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
					 				icon-color="red" title="确认删除该数据吗？" @confirm="delSonMenu(scope.row.id)"
					 				style="margin-left: 10px;">
					 				<el-button type="danger" icon="el-icon-delete" size="mini" slot="reference">删除
					 				</el-button>
					 			</el-popconfirm>
					 		</template>
					 	</el-table-column>
					 </el-table>
				 </div>
			    <el-dialog
			      width="30%"
			      :title="sonTitle"
			      :visible.sync="innerVisible"
			      append-to-body>
				  <div>
					  <div style="padding: 15px;width: 90%;position: relative;">
					  	<div style="display: flex;margin-top: 15px;">
					  		<div style="width: 150px;">菜单名称：</div>
					  		<div style="width: 100%;">
					  			<el-input clearable v-model="sonMenu.menuName" placeholder="请输入菜单名称"></el-input>
					  		</div>
					  	</div>
						<div style="display: flex;margin-top: 15px;">
							<div style="width: 150px;">路径：</div>
							<div style="width: 100%;">
								<el-input clearable v-model="sonMenu.url" placeholder="请输入菜单名称"></el-input>
							</div>
						</div>
					  	<div style="display: flex;margin-top: 15px;">
					  		<div style="width: 150px;">菜单图标：</div>
					  		<div style="width: 100%;">
					  			<el-select v-model="sonMenu.icon" clearable placeholder="请选择" style="width: 100%;">
					  				<template slot="prefix">
					  					<span style="padding: 5px;line-height: 40px;font-size: 18px; color: #409eff;">
					  						<i :class="sonMenu.icon"></i>
					  					</span>
					  				</template>
					  				<el-option v-for="item in options"  :class="item.label"
					  					:label="item.label" :value="item.value">
					  				</el-option>
					  			</el-select>
					  		</div>
					  	</div>
						<div style="display: flex;margin-top: 15px;">
							<div style="width: 150px;">父级菜单：</div>
							<div style="width: 100%;">
								<el-select v-model="sonMenu.parentId" clearable placeholder="请选择" style="width: 100%;">
									<el-option v-for="item in Parentoptions"  :class="item.label"
										:label="item.label" :value="item.value">
										<!-- <template slot="prefix">
											<span style="padding: 5px;line-height: 40px;font-size: 18px; color: #409eff;">
												<i :class="sonMenu.icon"></i>
											</span>
										</template> -->
										<span style="float: left;color:rgb(8,131,216);">
											<i :class="item.icon"></i>
										</span>
										<span style="float: right; color: #8492a6; font-size: 13px">{{ item.label }}</span>
									</el-option>
								</el-select>
							</div>
						</div>
						
					  	<div style="display: flex;margin-top: 15px;">
					  		<div style="width: 150px;">备注：</div>
					  		<div style="width: 100%;">
					  			<el-input type="textarea" v-model="sonMenu.remark" placeholder="请输入备注"></el-input>
					  		</div>
					  	</div>
					  	<div style="margin-top: 10px;position: absolute;right: 0;padding: 20px;">
					  		<el-button type="primary" icon="el-icon-check" @click="sonOption">确定</el-button>
					  	</div>
						<div style="height: 50px;">
							
						</div>
					  </div>
				  </div>
			    </el-dialog>
			   <!-- <div slot="footer" class="dialog-footer">
			      <el-button @click="outerVisible = false">取 消</el-button>
			      <el-button type="primary" @click="innerVisible = true">打开内层 Dialog</el-button>
			    </div> -->
			  </el-dialog>
		</div>
	</div>

</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				iconList: [],
				drawer: false,
				title: '',
				menu: {
					
				},
				options: [],
				selectId:'',
				sonMenuList:[],
				outerVisible:false,
				innerVisible:false,
				sonMenu:{},
				sonTitle:'',
				sonSelectId:'',
				selectParentId:'',
				Parentoptions:[],
				roleOptions:[]
			}
		},
		created() {
			this.Init();
		},
		methods: {
			Init() {
				this.request.get("/menu").then(res => {
					if (res.code == 200) {
						this.myList=res.data;
					}
				});
				// 图标
				this.request.get("/icon").then(res => {
					if (res.code == 200) {
						this.options = [];
						for (var i = 0; i < res.data.length; i++) {
							let obj = {
								label: res.data[i].name,
								value: res.data[i].name,
							}
							this.options.push(obj)
						}
					}
				});
			},
			sonInit(){
				this.request.get("/menu/son/"+this.selectParentId).then(res=>{
					if(res.code==200){
						this.sonMenuList=res.data;
					}
				})
			},
			//查看子菜单
			lookSon(id){
				this.outerVisible=true;
				this.selectParentId=id;
				this.sonInit();
			},
			//显示修改的窗体
			showEdit(id) {
				this.title = "修改信息"
				this.drawer = true;
				this.selectId=id;
				this.request.get("/menu/icon/"+id).then(res=>{
					if(res.code==200){
						console.log(res.data)
						this.menu=res.data;
					}
				})
				
				
			},
			option(){
				if(this.menu.menuName==""||this.menu.menuName==undefined){
					this.$message.warning("菜单名称不能为空");
					return;
				}
				if(this.menu.icon==""||this.menu.icon==undefined){
					this.$message.warning("菜单图标不能为空");
					return;
				}
				if(this.title=="修改信息"){
					this.menu.id=this.selectId;
					this.request.post("/menu",this.menu).then(res=>{
						if(res.code==200){
							this.Init();
							this.drawer=false;
							this.$root.menuName=this.menu.menuName;
							this.$root.menuName=this.menu.icon;
							this.$message.success(res.msg)
						}else{
							this.$message.error(res.msg)
						}
					})
				}else{
					this.menu.id=0;
					console.log(this.menu);
					//添加菜单
					this.request.post("/menu/add",this.menu).then(res=>{
						if(res.code==200){
							this.Init();
							this.$root.addSonMenu=!this.$root.addSonMenu;
							this.drawer=false;
							this.$message.success(res.msg)
						}else{
							this.$message.error(res.msg)
						}
					})
				}
			},
			//添加菜单
			addMenu(){
				this.menu={
					menuName:'',
					icon:'',
					remark:''
				}
				this.title = "添加菜单"
				this.drawer = true;
				
				this.request.get("/roles").then(res=>{
					if(res.code==200){
						this.roleOptions=[];
						for (var i = 0; i < res.data.length; i++) {
							let obj={
								value:res.data[i].id,
								label:res.data[i].roleName
							}
							this.roleOptions.push(obj);
						}
					}
				})
				
			},
			//显示子菜单的修改窗体
			showSonMenuEdit(id){
				this.sonTitle="修改信息"
				this.innerVisible=true;
				this.sonSelectId=id;
				this.request.get("/sonMenu/"+this.sonSelectId).then(res=>{
					if(res.code==200){
						this.sonMenu=res.data;
					}
				})
				
				// 显示父级菜单
				this.request.get("/menu").then(res=>{
					this.Parentoptions=[];
					console.log(res.data)
					for (var i = 0; i < res.data.length; i++) {
						let obj={
							value:res.data[i].id,
							label:res.data[i].menuName,
							icon: res.data[i].icon
						}
						this.Parentoptions.push(obj);
					}
				})
			},
			delMenu(id) {
				this.request.delete('/menu/' + id).then(res => {
					if (res.code == 200) {
						this.Init();
						this.$root.addSonMenu = !this.$root.addSonMenu;
						this.$message.success(res.msg);
					} else {
						this.$message.error(res.msg);
					}
				});
			},
			//添加子菜单
			addSonMenu(){
				this.sonTitle="添加子菜单";
				this.innerVisible=true;
				this.sonMenu={};
				
				// 显示父级菜单
				this.request.get("/menu").then(res=>{
					this.Parentoptions=[];
					console.log(res.data)
					for (var i = 0; i < res.data.length; i++) {
						let obj={
							value:res.data[i].id,
							label:res.data[i].menuName,
							icon: res.data[i].icon
						}
						this.Parentoptions.push(obj);
					}
				})
			},
			//子菜单的操作
			sonOption(){
				if(this.sonMenu.menuName==""||this.sonMenu.menuName==undefined){
					this.$message.warning("菜单名称不能为空");
					return;
				}if(this.sonMenu.icon==""||this.sonMenu.icon==undefined){
					this.$message.warning("菜单图标不能为空");
					return;
				}
				if(this.sonMenu.parentId==undefined||this.sonMenu.parentId.length<=0){
					this.$message.warning("请选择父级菜单");
					return;
				}
				if(this.sonMenu.url==undefined||this.sonMenu.url==""){
					this.$message.warning("菜单路径不能为空");
					return;
				}
				
				if(this.sonTitle=="修改信息"){
					this.sonMenu.id=this.sonSelectId;
					this.request.put("/sonMenu",this.sonMenu).then(res=>{
						if(res.code==200){
							if(this.$root.sonMenuIcon!=this.sonMenu.icon){
								this.$root.sonMenuIcon=this.sonMenu.icon;
							}else if(this.$root.sonMenuName!=this.sonMenu.menuName){
								this.$root.sonMenuName=this.sonMenu.menuName;
							}else if(this.$root.sonMenuParentId!=this.sonMenu.parentId){
								this.$root.sonMenuParentId=this.sonMenu.parentId;
							}
							this.sonInit();
							this.innerVisible=false;
							this.$message.success(res.msg);
						}else{
							this.$message.error(res.msg);
						}
					})
				}
				else{
					//添加新的子菜单
					this.sonMenu.id=0;
					this.request.post("/sonMenu",this.sonMenu).then(res=>{
						if(res.code==200){
							this.$root.addSonMenu=!this.$root.addSonMenu;
							this.sonInit();
							this.innerVisible=false;
							this.$message.success(res.msg);
						}else{
							this.$message.error(res.msg);
						}
					})
				}
			},
			//删除子菜单
			delSonMenu(id){
				this.request.delete("/sonMenu/"+id).then(res=>{
					if(res.code==200){
						this.sonInit();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			}
		}
	}
</script>

<style>
</style>
