<template>
	<div>
		<div class="head">
			<el-button type="primary" icon="el-icon-circle-plus-outline" @click="addRole">添加</el-button>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}" tooltip-effect="dark">
				<el-table-column prop="id" label="编号" align="center" width="50">
				</el-table-column>
				<el-table-column prop="roleName" label="角色名称" align="center">
				</el-table-column>
				<el-table-column prop="isEnable" label="是否启用" align="center">
					<template slot-scope="scope">
						<el-switch v-model="scope.row.isEnable" active-color="#13ce66" inactive-color="#ff4949"
							:active-value="0" :inactive-value="1">
						</el-switch>
					</template>
				</el-table-column>
				<el-table-column prop="sign" label="标识" align="center">
					<template slot-scope="scope">
						<el-tag type="danger">{{scope.row.sign}}</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="权限菜单" align="center">
					<template slot-scope="scope">
						<i class="el-icon-view" style="color: rgb(103,194,58);font-size: 16px;cursor: pointer;"
							@click="lookDetail(scope.row.id)"></i>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center" width="180px">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column align="center" label="操作" width="290">
					<template slot-scope="scope">
						<el-button type="success" icon="el-icon-edit" size="mini" @click="editData(scope.row.id)">修改
						</el-button>
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)"
							style="margin-left: 10px;">
							<el-button type="danger" icon="el-icon-delete" size="mini" slot="reference">删除
							</el-button>
						</el-popconfirm>
					</template>
				</el-table-column>
			</el-table>
		</div>
		<!-- 菜单 -->
		<div>
			<el-dialog title="库房信息" :visible.sync="menuVisable">
				<el-table :data="gridData">
					<el-table-column property="menu.id" label="编号" width="150"></el-table-column>
					<el-table-column property="menu.menuName" label="菜单名称"></el-table-column>
					<el-table-column property="menu.menuName" label="图标">
						<template slot-scope="scope">
							<li :class="scope.row.menu.icon" style="font-size: 16px;"></li>
						</template>
					</el-table-column>
					<el-table-column label="状态">
						<template slot-scope="scope">
							<el-tag type="success" v-if="scope.row.menu.isEnable==0" size="medium">启用</el-tag>
							<el-tag type="danger" v-else size="medium">禁用</el-tag>
						</template>
					</el-table-column>
				</el-table>
			</el-dialog>
		</div>
		<!-- 修改或添加 -->
		<div>
			<el-dialog :title="title" :visible.sync="roleVisable" width="40%" :before-close="handleClose">
				<div style="width: 100%;position: relative;">
					<div style="display: flex;margin-top: 10px;align-items: center;">
						<div style="width: 100px;">角色名称：</div>
						<div style="width: 100%;">
							<el-input clearable v-model="role.roleName"></el-input>
						</div>
					</div>
					<div style="display: flex;margin-top: 10px;align-items: center;" v-if="title=='修改信息'">
						<div style="width: 100px;">标识：</div>
						<div style="width: 100%;">
							<el-tag type="danger">{{role.sign}}</el-tag>
						</div>
					</div>
					<div style="display: flex;margin-top: 10px;align-items: center;" v-if="title=='添加角色'">
						<div style="width: 100px;">标识：</div>
						<div style="width: 100%;">
							<el-input placeholder="请输入内容" v-model="role.sign" clearable>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-top: 10px;align-items: center;">
						<div style="width: 100px;">分配菜单：</div>
						<div style="width: 100%;">
							<el-select v-model="menuIds" multiple placeholder="请选择" style="width: 100%;">
								<el-option v-for="item in options" :key="item.value" :label="item.label"
									:value="item.value">
									<span style="float: left;color:rgb(8,131,216);">
										<i :class="item.icon"></i>
									</span>
									<span style="float: right; color: #8492a6; font-size: 13px">{{ item.label }}</span>
								</el-option>
							</el-select>
						</div>
					</div>
					<div style="position: absolute;right: 0;margin-top: 20px;">
						<el-button type="primary" icon="el-icon-circle-check" @click="option">确定</el-button>
					</div>
					<div style="margin-top: 50px;">

					</div>
				</div>
			</el-dialog>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				isEnable: 0,
				menuVisable: false,
				gridData: [],
				title: '',
				roleVisable: false,
				role: {},
				menuIds: [],
				options: [],
				selectId: ''
			}
		},
		methods: {
			Init() {
				this.request.get("/roles").then(res => {
					if (res.code == 200) {
						this.myList = res.data;
						console.log(this.myList);
					}
				});
				this.request.get("/menu").then(res => {
					if (res.code == 200) {
						this.options = [];
						let list = res.data;
						for (var i = 0; i < list.length; i++) {
							let obj = {
								value: list[i].id,
								label: list[i].menuName,
								icon: list[i].icon
							}
							this.options.push(obj);
						}
						//console.log(res.data);
					}
				});
			},
			//添加角色
			addRole() {
				this.title = "添加角色";
				this.roleVisable = true;
				this.role = {};
				this.menuIds = [];
			},
			//查看菜单
			lookDetail(id) {
				this.request.get("/roles/menu/" + id).then(res => {
					if (res.code == 200) {
						this.menuVisable = true;
						this.gridData = res.data
					}
				})
			},
			//修改或添加
			option() {
				if (this.role.roleName == undefined || this.role.roleName == "") {
					this.$message.error("角色名称不能为空");
					return;
				}
				if (this.menuIds.length <= 0) {
					this.$message.error("请选择菜单");
					return;
				}
				this.role.menuIds = this.menuIds;
				if (this.title == "修改信息") {
					this.role.id = this.selectId;
					// let roles={
					// 	menuIds:this.menuIds,
					// 	id:this.selectId,
					// 	roleName:this.role.roleName
					// }
					this.request.post("/roles", this.role).then(res => {
						if (res.code == 200) {
							this.Init();
							this.roleVisable = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				} else {
					this.role.id = 0;
					this.request.post("/roles/add", this.role).then(res => {
						if (res.code == 200) {
							this.Init();
							this.roleVisable = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				}
			},
			//显示 修改的窗体
			editData(id) {

				this.selectId = id;
				this.title = "修改信息";

				this.request.get("/roles/menu/" + id).then(res => {
					if (res.code == 200) {
						this.role = res.data[0].role
						//this.role.menuId=res.data
						let list = []
						for (var i = 0; i < res.data.length; i++) {
							list.push(res.data[i].menuId);
						}
						this.menuIds = list;
						//console.log(res.data)
					}
				})
				//this.role=
				this.roleVisable = true;
			},
			//删除
			delData(id) {
				alert(id);
				this.request.delete("/roles/"+id).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {});
			}

		},
		created() {
			this.Init();
		}
	}
</script>

<style>
</style>
