<template>
	<div style="white-space:pre-wrap">
		<div id="box" v-html="htmlText" ref="reportHTML">
			
		</div>
	</div>
	
</template>

<script>
	export default{
		name:'page',
		data(){
			return{
				htmlText:this.$route.params.html,
			}
		},
		created() {
			let JSScript="";
			console.log(this.htmlText)
			// 使用正则获取js内容
			   this.htmlText.replace(/<script.*?>([\s\S]+?)<\/script>/img,function(_,js){    //正则匹配出script中的内容
			    	JSScript = js
			   })
			   // 这里需要使用$nextTick  需要等dom更新后才能操作reportHTML
			   this.$nextTick(() => {
				   // 将js脚本内容插入到标签当中
				    var newElement = document.createElement("script")
				    newElement.innerHTML = JSScript
				    this.$refs.reportHTML.append(newElement)
			  })

			//console.log(this.html)
			//document.getElementById("box").appendChild(this.$route.params.html);
			//this.html=this.$route.params.html;
		}
	}
</script>

<style>
</style>