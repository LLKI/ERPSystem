<template>
	<div>
		<el-tabs type="border-card" style="min-height: 85vh;" @tab-click='changeState'>
			<el-tab-pane label="待付款" name="0"></el-tab-pane>
			<el-tab-pane label="已付款" name="1"></el-tab-pane>
			<el-tab-pane label="已取消" name="2"></el-tab-pane>
			<div>
				<payOrderList :key="state" :state='state'></payOrderList>
			</div>
			
		</el-tabs>
	</div>
</template>

<script>
	import payOrderList from './payOrderList.vue'
	export default{
		components:{
			payOrderList
		},
		data(){
			return{
				detail: {},
				state: 0,
				title: '',
				timer: ''
			}
			
		},
		methods:{
			changeState(tab, event) {
				this.state = tab.name;
			},
		}
	}
</script>

<style>
</style>