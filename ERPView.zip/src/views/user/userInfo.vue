<template>
	<div>
		<div class="head" style="display: flex;">
			<div>
				<el-input v-model="search_user.userName" placeholder="请输入用户姓名" prefix-icon="el-icon-user" clearable>
				</el-input>
			</div>
			<div>
				<el-input v-model="search_user.phone" placeholder="请输入手机号" prefix-icon="el-icon-phone" clearable>
				</el-input>
			</div>
			<div>
				<el-input v-model="search_user.userAccount" placeholder="请输入用户账号" prefix-icon="el-icon-coordinate"
					clearable></el-input>
			</div>
			<div>
				<el-select v-model="departmentId" clearable placeholder="请选择部门">
					<el-option v-for="item in departmentOptions" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</div>
			<div>
				<el-select v-model="roleId" clearable placeholder="请选择角色">
					<el-option v-for="item in roleOptions" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</div>
			<div>
				<el-button type="primary" icon="el-icon-search" @click="search">搜索</el-button>
			</div>
		</div>
		<div style="margin: 20px 0px;display: flex;">
			<div>
				<el-button type="success" icon="el-icon-circle-plus-outline" @click="addUser" size="mini">添加</el-button>
			</div>
			<div style="margin-left: 10px;">
				<el-button type="warning" icon="el-icon-download" size="mini" @click="exportData">导出excel</el-button>
			</div>
			<div style="margin-left: 10px;">
				<el-upload class="upload-demo" :action="importDataAction" :limit="1" :on-success="importExcelSuccess"
					:before-upload="beforeImportExcel" :show-file-list="false" :data="userId" ref="upload2"
					:on-error="importError">
					<el-button type="primary" icon="el-icon-upload el-icon--right" size="mini">导入excel</el-button>
				</el-upload>
			</div>
			<div style="margin-left: 10px;">
				<el-button type="success" @click="download" icon="el-icon-download" size="mini">下载模板</el-button>
			</div>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}"
				@selection-change="handleSelectionChange" tooltip-effect="dark" ref="multipleTable">
				<el-table-column type="selection" width="55">
				</el-table-column>
				<el-table-column prop="id" label="编号" align="center" width="50">
				</el-table-column>
				<el-table-column prop="account" label="账号" align="center" width="140">
				</el-table-column>
				<el-table-column prop="trueName" label="姓名" align="center">
				</el-table-column>
				<el-table-column prop="sex" label="性别" align="center" width="60">
				</el-table-column>
				<el-table-column prop="age" label="年纪" align="center" width="60">
				</el-table-column>
				</el-table-column>
				<el-table-column prop="phone" label="手机号" align="center" width="130">
				</el-table-column>
				<el-table-column prop="department.depaName" label="部门" align="center">
				</el-table-column>
				<el-table-column prop="role.roleName" label="角色" align="center">
					<template slot-scope="scope">
						<el-tag type="danger" v-if="scope.row.role.sign=='ADMIN'">{{scope.row.role.roleName}}</el-tag>
						<el-tag type="primary" v-else>{{scope.row.role.roleName}}</el-tag>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center" width="180px">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column align="center" label="操作" width="290">
					<template slot-scope="scope">
						<el-button type="success" icon="el-icon-edit" size="mini" @click="showEdit(scope.row.id)">修改
						</el-button>
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delUser(scope.row.id)"
							style="margin-left: 10px;">
							<el-button type="danger" icon="el-icon-delete" size="mini" slot="reference">删除
							</el-button>
						</el-popconfirm>
						<!-- <el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delUser(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" size="mini">删除
							</el-button>
						</el-popconfirm> -->

						<el-dropdown size="mini" split-button type="primary" style="margin-left: 10px;" trigger="click">
							更多
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item style="width:100px;color: #67C23A;">
									<span class="el-icon-check" style="display: inline-block;width: 100%;"
										@click="rePwd(scope.row.id)">重置密码</span>
								</el-dropdown-item>
								<el-dropdown-item style="width:100px;color: #E6A23C;">
									<span class="el-icon-s-grid" style="display: inline-block;width: 100%;"
										@click="lookDetail(scope.row.id)">更多信息</span>
								</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
						<!-- <el-button type="primary" icon="el-icon-s-grid" @click="editData(scope.row.id)"-->
					</template>
				</el-table-column>
			</el-table>
		</div>
		<!-- 分页 -->
		<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
			<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page.sync="search_user.pageIndex" :page-sizes="[7,10,15,20]" :page-size="search_user.pageSize"
				layout="sizes, prev, pager, next,total" :total="search_user.total">
			</el-pagination>
		</div>

		<!-- 弹窗 查看详情-->
		<div>
			<el-dialog title="用户详情" :visible.sync="dialogVisible" width="30%">
				<el-card class="box-card">
					<div class="detail">
						<div style="display: flex;justify-content: space-between;position: relative;">
							<div>
								<span>昵称：</span>
								<!-- <span v-if="detail.nickName ==undefined" style="color: #F56C6C;">未知</span> -->
								<span>{{detail.nickName }}</span>
							</div>
						</div>
						<div>
							<span>邮箱：</span>
							<span>{{detail.email}}</span>
						</div>
						<div>
							<span>QQ：</span>
							<!-- <span v-if="detail.size==undefined" style="color: #F56C6C;">未知</span> -->
							<span>{{detail.qq}}</span>
						</div>
						<div>
							<span>地址：</span>
							<!-- <span v-if="detaqil.material==undefined||detail.material==''"
								style="color: #F56C6C;">未知</span> -->
							<span>{{detail.address}}</span>
						</div>
						<div>
							<span>生日：</span>
							<span>{{detail.birthday}}</span>
							<!-- <span v-text="detail.isEnough==0?'不缺货':'缺货'"></span> -->
						</div>
						<div>
							<span>添加人：</span>
							<!-- <span v-if="detail.ackTime==undefined" style="color: #F56C6C;">未审核</span> -->
							<span>{{detail.addperson}}</span>
						</div>
						<div>
							<span>添加时间：</span>
							<span>{{detail.addTime}}</span>
						</div>
					</div>
				</el-card>
			</el-dialog>
		</div>
		<!-- 添加或修改 -->
		<div>
			<el-drawer :title="title" :visible.sync="drawer" direction="ttb" style="width: 50%;margin: 0px auto;"
				size="75%">
				<div class="drawer" style="padding: 15px;position: relative;">
					<div>
						<div>
							<div>姓名：</div>
							<div>
								<el-input clearable v-model="user.trueName" placeholder="请输入姓名" style="width: 100%;">
								</el-input>
							</div>
						</div>
						<div>
							<div>性别：</div>
							<div>
								<el-radio-group v-model="user.sex">
									<el-radio label="男">男</el-radio>
									<el-radio label="女">女</el-radio>
								</el-radio-group>
							</div>
						</div>
						<div>
							<div>年纪：</div>
							<el-input oninput="value=value.replace(/[^\d]/g,'')" clearable v-model="user.age"
								placeholder="请输入年纪"></el-input>
						</div>
						<div>
							<div>部门：</div>
							<div>
								<el-select v-model="user.departmentId" clearable placeholder="请选择部门"
									style="width: 100%;">
									<el-option v-for="item in departmentOptions" :label="item.label"
										:value="item.value">
									</el-option>
								</el-select>
							</div>

						</div>
						<div>
							<div>角色：</div>
							<div>
								<el-select v-model="user.roleId" clearable placeholder="请选择角色" style="width: 100%;">
									<el-option v-for="item in roleOptions" :label="item.label" :value="item.value">
									</el-option>
								</el-select>
							</div>
						</div>
						<div>
							<div>手机号：</div>
							<el-input clearable v-model="user.phone" placeholder="请输入手机号"></el-input>
						</div>
					</div>
					<div>
						<div>
							<div>邮箱：</div>
							<el-input clearable v-model="user.email" placeholder="请输入邮箱"></el-input>
						</div>
						<div>
							<div>QQ：</div>
							<el-input clearable v-model="user.qq" placeholder="请输入QQ号"></el-input>
						</div>
						<div>
							<div>地址：</div>
							<el-input clearable v-model="user.address" placeholder="请输入地址" type="textarea" rows="4">
							</el-input>
						</div>
						<div>
							<div>生日：</div>
							<el-date-picker v-model="user.birthday" type="datetime" placeholder="选择日期时间"
								format="yyyy-MM-dd HH:mm">
							</el-date-picker>
						</div>
						<div>
							<div>备注：</div>
							<el-input clearable v-model="user.remark" type="textarea" placeholder="请输入备注"></el-input>
						</div>
					</div>

				</div>
				<div style="padding:0px 15px 0px 15px;position: absolute;right: 0;">
					<el-button type="primary" icon="el-icon-check" @click="option">确定</el-button>
				</div>
			</el-drawer>
		</div>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				search_user: {
					total: 0,
					pageIndex: 1,
					pageSize: 7,
					phone: '',
					userName: '',
					userAccount: '',
				},
				roleId: "",
				departmentId: "",
				departmentOptions: [],
				roleOptions: [],
				userId: {
					id: JSON.parse(localStorage.getItem("userInfo")).id
				},
				importDataAction: 'http://localhost:5000/api/userInfo/import',
				dialogVisible: false,
				detail: {},
				title: "",
				drawer: false,
				selectId: '',
				user: {
					sex: '男'
				},
			}
		},
		created() {
			this.Init();
		},
		methods: {
			//初始化
			Init() {
				if (this.roleId == "") {
					this.search_user.roleId = 0;
				} else {
					this.search_user.roleId = this.roleId
				}
				if (this.departmentId == "") {
					this.search_user.departmentId = 0;
				} else {
					this.search_user.departmentId = this.departmentId
				}
				this.request.post("/userInfo", this.search_user).then(res => {
					if (res.code == 200) {
						console.log(res.data)
						this.myList = res.data.myList;
						this.search_user.total = res.data.total;
					}
				});
				//部门
				this.request.get("/roles").then(res => {
					if (res.code == 200) {
						let list = res.data;
						console.log(res.data)
						this.roleOptions = []
						for (var i = 0; i < list.length; i++) {
							let obj = {
								label: list[i].roleName,
								value: list[i].id
							};
							this.roleOptions.push(obj);
						}
					}
				})
				//角色
				this.request.get("/department").then(res => {
					if (res.code == 200) {
						console.log(res.data)
						let list = res.data;
						this.departmentOptions = [];
						for (var i = 0; i < list.length; i++) {
							let obj = {
								label: list[i].depaName,
								value: list[i].id
							};
							this.departmentOptions.push(obj);
						}
					}
				})
			},
			//展示修改的窗体
			showEdit(id) {
				this.selectId = id;
				this.title = "修改用户信息"
				this.drawer = true;
				this.request.get("/userInfo/getUser/" + id).then(res => {
					if (res.code == 200) {
						this.user = res.data;
					}
				})
			},
			//删除用户
			delUser(id) {
				this.request.delete("/userInfo/" + id).then(res => {
					if (res.code == 200) {
						this.Init();
						this.$message.success(res.msg)
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//添加用户
			addUser() {
				this.title = "添加用户";
				this.drawer = true;
				this.user = {
					sex: '男'
				}
			},
			option() {
				var verify = /^\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/;
				if (!verify.test(this.user.email)) {
					this.$message.error('邮箱格式错误, 请重新输入');
					return;
				}
				if (this.user.trueName == "" || this.user.trueName == undefined) {
					this.$message.warning("用户姓名不能为空");
					return;
				}
				if (this.user.age == "" || this.user.age == undefined) {
					this.$message.warning("用户年纪不能为空");
					return;
				}
				if (this.user.departmentId == "" || this.user.departmentId == undefined) {
					this.$message.warning("请选择部门");
					return;
				}
				if (this.user.roleId == "" || this.user.roleId == undefined) {
					this.$message.warning("请选择角色");
					return;
				}
				if (this.user.phone == "" || this.user.phone == undefined) {
					this.$message.warning("手机号不能为空");
					return;
				} else {
					var reg = /^[1][3,4,5,7,8,9][0-9]{9}$/;
					if (!reg.test(this.user.phone)) {
						this.$message.warning("手机号格不正确");
						return;
					}
				}
				if (this.title == "修改用户信息") {
					this.request.post("/user", this.user).then(res => {
						if (res.code == 200) {
							if (this.selectId == this.userId.id) {
								if (this.$root.role != this.user.roleId) {
									this.$root.role = this.user.roleId
								}
							}
							this.Init();
							this.drawer = false;
							this.$message.success(res.msg);

						} else {
							this.$message.error(res.msg);
						}
					})
				} else {
					//添加
					this.request.post("/userInfo/add", this.user).then(res => {
						if (res.code == 200) {
							this.Init();
							this.drawer = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				}
			},
			//查看详情
			lookDetail(id) {
				this.request.get("/userInfo/getUser/" + id).then(res => {
					if (res.code == 200) {
						this.detail = res.data;
						this.dialogVisible = true;
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//导出
			exportData() {
				if (this.myList.length <= 0 || this.myList == null) {
					this.$message.error("没有数据")
					return;
				}
				this.request.post("/userInfo/export", this.search_user).then(res => {
					if (res.code == 200) {
						this.$message.success("导出成功");
						window.open(res.data, "_self");
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//excel 导入成功后
			importExcelSuccess(res, file) {
				if (res.code == 200) {
					this.$refs.upload2.clearFiles(); //上传成功之后清除历史记录
					this.Init();
					this.$message.success(res.msg)
				} else {
					this.$refs.upload2.clearFiles(); //上传成功之后清除历史记录
					this.$message.error(res.msg);
				}
			},
			//导入失败
			importError(err, file, fileList) {
				this.$refs.upload2.clearFiles(); //上传成功之后清除历史记录
				alert(err);
			},
			//导入excel 之前
			beforeImportExcel(file) {
				const isXLSX = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

				if (!isXLSX) {
					this.$message.error('上传文件格式不正确!');
				}
				return isXLSX;
			},
			//重置密码
			rePwd(id) {
				this.$confirm('重置密码, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					this.request.get("/userInfo/" + id).then(res => {
						if (res.code == 200) {
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				})
			},
			//搜索
			search() {
				this.Init();
			},
			handleSelectionChange(val) {
				// this.ids = [];
				// for (var i = 0; i < val.length; i++) {
				// 	this.ids.push(val[i].id);
				// }
			},
			//切换页码
			handleCurrentChange(index) {
				this.search_user.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_user.pageSize = pageSize;
				this.Init();
			},
			//下载模板
			download(){
				this.request.get("/user").then(res=>{
					if(res.code==200){
						window.open(res.data, "_self");
						this.$message.success(res.msg)
					}
				})
			}
		},
	}
</script>

<style scoped>
	.head div {
		margin-right: 10px;
	}

	.detail div {
		margin-bottom: 20px;
	}

	.detail div span:nth-child(1) {
		width: 100px;
		display: inline-block;
	}

	.detail div span:nth-child(2) {
		color: #909399;
	}

	.drawer {
		display: flex;
	}

	.drawer>div {
		flex: 1;
	}

	.drawer div div {
		display: flex;
		align-items: center;
		margin-bottom: 10px;
	}

	.drawer div div>div {
		width: 100px;
	}

	.drawer div div div:nth-child(2) {
		width: 50%;
	}
</style>
