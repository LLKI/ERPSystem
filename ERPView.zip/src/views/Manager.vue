<template>
	<el-container style="height: 100%;margin: 0px;">
		<!-- 侧边栏 -->
		<el-aside :width="asidewidth" style="background-color: rgb(48,65,86);">
			<Aside :iscollapse="iscollapse" :fontsize="fontsize"></Aside>
		</el-aside>
		<!-- 个人中心 -->
		<el-container>
			<!-- <span class="el-icon-s-unfold"></span> -->
			<el-header>
				<Head :collapse1="collapse1" :collapseBtnClass="collapseBtnClass"></Head>
			</el-header>
			<el-main>
				<router-view></router-view>
			</el-main>
		</el-container>
	</el-container>
</template>

<script>
	import Aside from '../components/Aside.vue'
	import Head from '../components/Head.vue'
	export default{
		name:'manager',
		data(){
			return{
				iscollapse: false,
				asidewidth:220+'px',
				fontsize:"",
				collapseBtnClass:'el-icon-s-fold',
			}
		},
		components:{
			Aside,
			Head,
		},
		methods:{
			collapse1() {
					this.iscollapse = !this.iscollapse;
					if (this.iscollapse) {
						this.collapseBtnClass = 'el-icon-s-fold';
						this.asidewidth = 60 + 'px';
						// this.logowidth = 14 + 'px';
						this.fontsize = {
							'display': 'none'
						};
					} else {
						this.collapseBtnClass = 'el-icon-s-unfold';
						this.asidewidth = 220 + 'px';
						// this.logowidth = 20 + 'px';
						this.fontsize = {
							'font-size': '20px'
						}
					}
			},
		}
	}
</script>

<style scoped>
	.el-header {
		border-bottom: 1px solid black;
		color: #333;
		line-height: 60px;
	}
</style>