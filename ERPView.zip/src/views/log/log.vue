<template>
	<div>
		<el-card class="box-card" style="min-height: 85vh;">
			<div style="display: flex;flex-wrap: wrap;">
				<div style="display: flex;width: 40%;">
					<template v-for="(item,index) in myList">
						<div style="margin-left: 20px;">
							<dl @click="lookDetail(item)">
								<dd>
									<li class="el-icon-folder-opened"
										style="font-size: 100px;color: rgb(235, 186, 62);cursor: pointer;"></li>
								</dd>
								<dt style="text-align: center;"><span
										style="display: block;color: #606266;cursor: pointer;">{{item}}</span></dt>
							</dl>
						</div>
					</template>
				</div>
				<div style="margin-top: 20px;">
					<div style="display: flex;padding: 20px;text-align: center;">
						<div style="flex: 1;margin-right: 10px;">
							<el-card class="box-card">
								<div style="display: flex;justify-content: space-around;align-items: center;">
									<div class="el-icon-s-data" style="color: #F56C6C;">

									</div>
									<div>系统今日出现错误数量:<span style="color: #F56C6C;font-size: 20px;margin-left: 10px;">{{nowDay}}</span></div>
								</div>
							</el-card>
						</div>
						<div style="flex: 1;">
							<el-card class="box-card">
								<div style="display: flex;justify-content: space-around;align-items: center;">
									<div class="el-icon-s-data" style="color: #F56C6C;">

									</div>
									<div>系统总共出现错误数量:<span style="color: #F56C6C;font-size: 20px;margin-left: 10px;">{{total}}</span></div>
								</div>
							</el-card>
						</div>
					</div>
					<div style="padding:0px 20px;">
						 <el-alert
						    title="正常"
						    type="success"
						    description="您的系统运行正常"
						    show-icon v-if="nowDay==0">
						  </el-alert>
						  <el-alert
						     title="错误"
						     type="error"
						     :description="desc"
						     show-icon v-else>
						   </el-alert>
					</div>
					<div id="main" style="width:700px;height: 380px;">

					</div>
				</div>
			</div>
		</el-card>
	</div>
</template>

<script>
	import * as echarts from 'echarts';
	export default {
		data() {
			return {
				myList: [],
				icon: 'el-icon-folder',
				data: [],
				option: {},
				list: [],
				option: {},
				nowDay:0,
				total:0,
				desc:''
			}
		},
		methods: {
			Init() {
				//console.log("二："+this.list);
				this.request.get("/error").then(res => {
					if (res.code == 200) {
						this.list=[res.data.count[0],res.data.count[1],res.data.count[2],res.data.count[3],res.data.count[4]
						,res.data.count[5],res.data.count[6]];
						this.nowDay=res.data.count[7];
						this.total=res.data.count[8];
						console.log(this.list)
						this.desc="您的系统今日出现:"+this.nowDay+"条错误";
						let option = {
							xAxis: {
								data: ['星期一', '星期二', '星期三', '星期四', '星期五', "星期六", "星期日"]
							},
							yAxis: {
						
							},
							series: [{
								data: this.list,
								type: 'line',
								areaStyle: {
									color: '#F56C6C',
									opacity: 0.5
								}
								
								
							}],
							tooltip:{
								trigger:'axis', //设置提示框的触发类型为坐标轴触发，主要在柱状图，折线图等会使用类目轴的图表中使用
								axisPointer:{ 
									type:'shadow' //设置坐标轴指示器的类型是阴影指示器，坐标轴指示器是指示坐标轴当前刻度的工具。
								}
							}
						};
						//let option = this.option;
						var chartDom = document.getElementById('main');
						var myChart = echarts.init(chartDom);
						option && myChart.setOption(option);
					}
				});
			},
			//查看子级目录
			lookDetail(name) {
				this.request.get("/log/" + name).then(res => {
					if (res.code == 200) {
						this.$router.push({
							name: '日志详情',
							params: {
								myList: res.data,
								sign: name
							}
						})
					}
				})
			}

		},
		mounted() {
			this.Init();
		},
		created() {
			this.request.get("/log").then(res => {
				if (res.code == 200) {
					this.myList = res.data.parent;
				}
			});
			
			
			
		}
	}
</script>

<style scoped>

</style>
