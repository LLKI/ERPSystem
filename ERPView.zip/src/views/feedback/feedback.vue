<template>
	<div >
		<div class="head" style="display: flex;">
			<div style="width: 200px;">
				<el-input v-model="search_feedback.content" placeholder="请输入内容"></el-input>
			</div>
			<div style="margin-left: 20px;">
				反馈时间：
				<el-date-picker v-model="search_feedback.addTime" type="datetime" placeholder="选择日期时间" align="right"
					:picker-options="pickerOptions">
				</el-date-picker>
			</div>
			<div  style="margin-left: 15px;">
				<el-button icon="el-icon-search" type="primary" @click="search">搜索</el-button>
			</div>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}" tooltip-effect="dark">
				<el-table-column prop="id" label="编号" align="center" width="50">
				</el-table-column>
				<el-table-column prop="content" label="内容" align="center">
				</el-table-column>
				<el-table-column prop="isSolve" label="是否解决" align="center">
					<template slot-scope="scope">
						<el-tag type="success" v-if="scope.row.isSolve==1">已解决</el-tag>
						<el-tag type="danger" v-else>未解决</el-tag>
					</template>
				</el-table-column>
				<el-table-column prop="addPerson" label="反馈人" align="center">

				</el-table-column>
				<el-table-column prop="contact" label="联系方式" align="center">
				</el-table-column>
				<el-table-column prop="addTime" label="反馈时间" align="center" width="180px">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column align="center" label="操作">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除此订单吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="mini">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" @click="option(scope.row.id,scope.row.isSolve)" size="small" icon="el-icon-edit" v-if="scope.row.isSolve==0">
							已解决
						</el-button>
						<el-button type="warning" @click="option(scope.row.id,scope.row.isSolve)" size="small" icon="el-icon-edit" v-else>
							未解决
						</el-button>
					</template>
				</el-table-column>
			</el-table>
			
			<!-- 分页 -->
			<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
				<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page.sync="search_feedback.pageIndex" :page-sizes="[7,10,15,20]"
					:page-size="search_feedback.pageSize" layout="sizes, prev, pager, next,total"
					:total="search_feedback.total">
				</el-pagination>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				pickerOptions: {
					shortcuts: [{
						text: '今天',
						onClick(picker) {
							picker.$emit('pick', new Date());
				 	}
					}, {
						text: '昨天',
						onClick(picker) {
							let date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24);
							picker.$emit('pick', date);
						}
					}, {
						text: '一周前',
						onClick(picker) {
							let date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
							picker.$emit('pick', date);
						}
				 }]
				},
				myList: [],
				search_feedback: {
					pageSize: 7,
					pageIndex: 1,
					total: 0,
					content: ''
				},
				title:''
			}
		},
		created() {
			this.Init();
		},
		methods: {
			//初始化
			Init() {
				this.request.post("/feedback", this.search_feedback).then(res => {
					if (res.code == 200) {
						this.myList = res.data.myList;
						this.search_feedback.total = res.data.count;
					}
				})
			},
			option(id,isSolve){
				this.request.get("/feedback/"+id+"/"+isSolve).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg)
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			delData(id){
				this.request.delete("/feedback/"+id).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//搜索
			search(){
				this.Init();
			},
			//切换页码
			handleCurrentChange(index) {
				this.search_feedback.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_feedback.pageSize = pageSize;
				this.Init();
			},
		}
	}
</script>

<style>
</style>
