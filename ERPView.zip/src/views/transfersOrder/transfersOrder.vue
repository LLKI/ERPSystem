<template>
	<div>
		<el-tabs type="border-card" style="min-height: 85vh;" @tab-click='changeState'>
			<el-tab-pane label="未审核" name="0"></el-tab-pane>
			<el-tab-pane label="已审核" name="1"></el-tab-pane>
			<el-tab-pane label="已驳回" name="2"></el-tab-pane>
			<el-tab-pane label="已撤销" name="3"></el-tab-pane>
			<div>
				<transfersOrderList :key="state" :state='state'></transfersOrderList>
			</div>
		</el-tabs>
	</div>
</template>

<script>
	import transfersOrderList from './transfersOrderList.vue'
	export default{
		components:{
			transfersOrderList
		},
		data(){
			return{
				detail: {},
				state: 0,
				title: '',
				timer: ''
			}
		},
		methods:{
			changeState(tab, event) {
				this.state = tab.name;
			},
		}
	}
</script>

<style>
</style>