<template>
	<div>
		<div style="display: flex;">
			<div style="width: 200px;">
				<el-input clearable v-model="search_order.proNo" placeholder="请输入订单号"></el-input>
			</div>
			<div style="margin-left: 15px;">
				<el-button type="primary" icon="el-icon-search" @click="search">搜索</el-button>
			</div>
			<div style="margin-left: 15px;">
				<el-dropdown split-button type="success" style="margin-right: 10px;" trigger="click">
					批量操作
					<el-dropdown-menu slot="dropdown">
						<el-dropdown-item style="width:100px;color: #67C23A;" v-if="state==0&&sign=='ADMIN'">
							<span class="el-icon-check"
								style="display: inline-block;width: 100%;" @click="option(0,'批量通过')">通过</span>
						</el-dropdown-item>
						<el-dropdown-item style="width:100px;color: #F56C6C;" v-if="state==0&&sign=='ADMIN'">
							<span class="el-icon-close"
								style="display: inline-block;width: 100%;" @click="option(0,'批量驳回')">驳回</span>
						</el-dropdown-item>
						<el-dropdown-item style="width:100px;color: red;" v-if="state!=0">
							<span @click="option_batch('删除')" class="el-icon-delete"
								style="display: inline-block;width: 100%;">删除</span>
						</el-dropdown-item>
						<el-dropdown-item style="width:100px;color: red;" v-if="state==0">
							<span @click="option(0,'批量撤销')" class="el-icon-remove-outline"
								style="display: inline-block;width: 100%;">撤销</span>
						</el-dropdown-item>
					</el-dropdown-menu>
				</el-dropdown>
			</div>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}"
				@selection-change="handleSelectionChange" tooltip-effect="dark" ref="multipleTable">
				<el-table-column type="selection" width="55">
				</el-table-column>
				<el-table-column prop="id" label="编号" align="center" width="50" type="expand">
					 <template slot-scope="props">
						 <div style="margin-left: 50px;">
							 <span>调拨的理由：</span>
							 <span style="color: #F56C6C;">{{props.row.remark}}</span>
						 </div>
					</template>
				</el-table-column>
				<el-table-column prop="proNo" label="订单编号" align="center" width="320">
					<template slot-scope="scope">
						<el-link type="warning" @click="lookDetail(scope.row.proNo,scope.row.remark)" v-if="state==0">
							{{scope.row.proNo}}
						</el-link>
						<el-link type="success" @click="lookDetail(scope.row.proNo,scope.row.remark)" v-if="state==1">
							{{scope.row.proNo}}
						</el-link>
						<el-link type="danger" @click="lookDetail(scope.row.proNo,scope.row.remark)" v-if="state==2">
							{{scope.row.proNo}}
						</el-link>
						<el-link type="info" @click="lookDetail(scope.row.proNo,scope.row.remark)" v-if="state==3">
							{{scope.row.proNo}}
						</el-link>
					</template>
				</el-table-column>
				<el-table-column label="订单状态" align="center">
					<template slot-scope="scope">
						<el-tag type="warning" v-if="scope.row.auditState==0">待审核</el-tag>
						<el-tag type="success" v-if="scope.row.auditState==1">已审核</el-tag>
						<el-tag type="danger" v-if="scope.row.auditState==2">已驳回</el-tag>
						<el-tag type="info" v-if="scope.row.auditState==3">已撤销</el-tag> 
					</template>
				</el-table-column>
				<el-table-column label="总金额" align="center">
					<template slot-scope="scope">
						<span style="color: red;">{{scope.row.totalMoney}}元</span>
					</template>
				</el-table-column>
				
				
				<el-table-column prop="addTime" label="生成时间" align="center" width="180px" v-if="state==0">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="auditTime" label="审核时间" align="center" width="180px" v-if="state==1">
					<template slot-scope="scope">
						<span >{{scope.row.auditTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="auditTime" label="驳回时间" align="center" width="180px" v-if="state==2">
					<template slot-scope="scope">
						<span >{{scope.row.auditTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="auditTime" label="撤销时间" align="center" width="180px" v-if="state==3">
					<template slot-scope="scope">
						<span >{{scope.row.auditTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				
				
				
				
				<el-table-column prop="count" label="调拨数量" align="center" >
					<template slot-scope="scope">
						<span  style="color: #F56C6C;">{{scope.row.count}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="addPerson" label="调拨人" align="center" >
					<template slot-scope="scope">
						<span >{{scope.row.addPerson}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="auditPersion" label="撤销人" align="center" v-if="state==3">
					<template slot-scope="scope">
						<span >{{scope.row.auditPersion}}</span>
					</template>
				</el-table-column>
				<!-- <el-table-column prop="remark" label="理由" align="center" v-if="state==0">
					<template slot-scope="scope">
						<span  style="color: #F56C6C;">{{scope.row.remark}}</span>
					</template>
				</el-table-column> -->
				
				<el-table-column prop="auditPersion" label="审核人" align="center" v-if="state==1||state==2">
					<template slot-scope="scope">
						<span v-if="scope.row.auditPersion!=null">{{scope.row.auditPersion}}</span>
						<span v-else style="color: #F56C6C;">未审核</span>
					</template>
				</el-table-column>
				
				<el-table-column align="center" label="操作" width="220">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除此订单吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="mini" v-if="state!=0"
								>
								删除
							</el-button>
						</el-popconfirm>
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认撤销此订单吗？" @confirm="backOrder(scope.row.id)" v-if="state==0">
							<el-button type="warning" icon="el-icon-remove-outline" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="mini" >
								撤销
							</el-button>
						</el-popconfirm>
						<el-dropdown size="small" split-button type="primary" style="margin-right: 10px;"
							trigger="click" v-if="state==0&&sign=='ADMIN'">
							更多
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item style="width:100px;color: #67C23A;">
									<span @click="option(scope.row.id,'通过')" class="el-icon-check"
										style="display: inline-block;width: 100%;">通过</span>
								</el-dropdown-item>
								<el-dropdown-item style="width:100px;color: #F56C6C;">
									<span @click="option(scope.row.id,'驳回')" class="el-icon-close"
										style="display: inline-block;width: 100%;">驳回</span>
								</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
						
					</template>
				</el-table-column>
			</el-table>
		
			<!-- 分页 -->
			<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
				<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page.sync="search_order.pageIndex" :page-sizes="[7,10,15,20]"
					:page-size="search_order.pageSize" layout="sizes, prev, pager, next,total"
					:total="search_order.total">
				</el-pagination>
			</div>
		</div>
		
		<!-- 弹窗 驳回的理由 -->
			<div>
				<el-dialog :title="title" :visible.sync="dialogVisible" width="30%">
					<div>
						<el-input type="textarea" v-model="auditOrder.remark" clearable />
					</div>
					<span slot="footer" class="dialog-footer">
						<el-button @click="dialogVisible = false">取 消</el-button>
						<el-button type="primary" @click="backOrders">确 定</el-button>
					</span>
				</el-dialog>
			</div>
		
		<!-- 弹窗 显示订单详情 -->
		<div>
			<el-drawer title="订单详情" :visible.sync="drawer" direction="btt" style="width: 50%;margin: 0px auto;"
				size="90%">
				<div style="padding: 20px;">
					<template v-for="item in detail">
						<div style="margin-bottom: 20px;">
							<el-descriptions class="margin-top" :column="3" border>
								<el-descriptions-item :labelStyle="{'width':'100px'}">
									<template slot="label">
										<i class="el-icon-document"></i>
										商品名称
									</template>
									{{item.pro.proName}}
								</el-descriptions-item>
								<el-descriptions-item>
									<template slot="label">
										<i class="el-icon-wallet"></i>
										成本
									</template>
									<span style="color: red;">{{item.pro.costPrice}}元</span>
								</el-descriptions-item>
								<el-descriptions-item>
									<template slot="label">
										<i class="el-icon-data-analysis"></i>
										调拨数量
									</template>
									<span style="color: red;">{{item.number}}-{{item.pro.stock.split("-")[1]}}</span>
								</el-descriptions-item>
								<el-descriptions-item>
									<template slot="label">
										<i class="el-icon-box"></i>
										库存
									</template>
									{{item.pro.stock}}
								</el-descriptions-item>
								<el-descriptions-item :labelStyle="{'width':'100px'}">
									<template slot="label">
										<i class="el-icon-copy-document"></i>
										商品种类
									</template>
									{{item.pro.proType}}
								</el-descriptions-item>
								<el-descriptions-item :labelStyle="{'width':'100px'}">
									<template slot="label">
										<i class="el-icon-location-information"></i>
										之前位置
									</template>
									<span style="color: #909399;">{{item.inAddress}}</span>
								</el-descriptions-item>
								<el-descriptions-item>
									<template slot="label">
										<i class="el-icon-film"></i>
										状态
									</template>
									<span v-if="state==0" style="color: #E6A23C;">未审核</span>
									<span v-if="state==1" style="color: #67C23A;">已审核</span>
									<span v-if="state==2" style="color: #F56C6C;">已驳回</span>
									<span v-if="state==3" style="color: #909399;">已撤销</span>
								</el-descriptions-item>
								
								<el-descriptions-item>
									<template slot="label">
										<i class="el-icon-user"></i>
										调拨人
									</template>
									{{item.transfersPerson}}
								</el-descriptions-item>
								
								<el-descriptions-item>
									<template slot="label">
										<i class="el-icon-truck"></i>
										调拨位置
									</template>
									<span style="color: #409EFF;">{{item.outAddress}}</span>
								</el-descriptions-item>
								
								
								<el-descriptions-item v-if="state==2">
									<template slot="label">
										<i class="el-icon-chat-line-square"></i>
										驳回理由
									</template>
									<span style="color: red;">{{item.proNoNavigation.remark}}</span>
								</el-descriptions-item>
								<el-descriptions-item v-if="state==3">
									<template slot="label">
										<i class="el-icon-chat-line-square"></i>
										撤销理由
									</template>
									<span style="color: red;">{{item.proNoNavigation.remark}}</span>
								</el-descriptions-item>
								
								<el-descriptions-item v-if="state!=0">
									<template slot="label">
										<i class="el-icon-time"></i>
										申请时间
									</template>
									{{item.proNoNavigation.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}
								</el-descriptions-item>
								
							</el-descriptions>
						</div>
					</template>
				</div>
			</el-drawer>
		</div>
	</div>
</template>

<script>
	export default{
		props: ['state'],
		data(){
			return{
				search_order: {
					total: 0,
					pageIndex: 1,
					pageSize: 7,
					proNo: '',
					state:parseInt(this.state),
					userId: JSON.parse(localStorage.getItem("userInfo")).id
				},
				ids:[],
				myList:[],
				auditTime:'',
				drawer:false,
				detail:[],
				sign:'',
				auditOrder:{},
				dialogVisible:false,
				title:''
			}
		},
		created() {
			this.Init();
			//判断身份
			this.request.get("/roles/"+this.search_order.userId).then(res=>{
				if(res.code==200){
					this.sign=res.data.sign;
				}
			})
		},
		methods:{
			//初始化
			Init(){
				this.request.post("/Transfers",this.search_order).then(res=>{
					console.log(res.msg);
					if(res.code==200){
						this.myList=res.data.myList;
						this.search_order.total=res.data.count;
						console.log(res.data);
					}
				})
			},
			//查看详情
			lookDetail(id,remark){
				this.request.get("/Transfers/"+id).then(res=>{
					if(res.code==200){
						this.detail=res.data;
						this.drawer=true;
						console.log(this.detail)
					}
				})
			},
			//通过或驳回
			option(id,sign){
				this.auditOrder={};
				this.auditOrder.userId=this.search_order.userId;
				if(id==0){
					if(this.ids.length<=0){
						this.$message.warning("请先选择数据");
						return;
					}
					if(sign=="批量通过"){
						this.auditOrder.state=1;
						this.auditOrder.ids=this.ids;
					}else if(sign=="批量驳回"){
						this.auditOrder.state=2;
						this.auditOrder.ids=this.ids;
						this.title="驳回理由";
						this.dialogVisible=true;
						return;
					}else if(sign="批量撤销"){
						this.auditOrder.state=3;
						this.auditOrder.ids=this.ids;
					}
					//发送请求
					this.request.post("/Transfers/option",this.auditOrder).then(res=>{
						if(res.code==200){
							this.Init();
							this.$message.success(res.msg);
						}else{
							this.$message.error(res.msg);
						}
					})
				}else{
					this.auditOrder.id=id;
					if(sign=="通过"){
						this.auditOrder.state=1;
						//发送请求
						this.request.post("/Transfers/option",this.auditOrder).then(res=>{
							if(res.code==200){
								this.Init();
								this.$message.success(res.msg);
							}else{
								this.$message.error(res.msg);
							}
						})
					}else if(sign=="驳回"){
						this.auditOrder.state=2;
						this.title="驳回理由";
						this.dialogVisible=true;
					}
				}
				
				
				
			},
			backOrders(){
				if(this.auditOrder.remark==''){
					this.$message.warning("驳回理由不能为空");
					return;
				}
				//发送请求
				this.request.post("/Transfers/option",this.auditOrder).then(res=>{
					if(res.code==200){
						this.Init();
						this.dialogVisible=false;
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//删除
			delData(id){
				this.request.delete("/Transfers/"+id+"/"+this.search_order.userId).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg)
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//撤销
			backOrder(id){
				this.auditOrder={};
				this.auditOrder.id=id;
				this.auditOrder.userId=this.search_order.userId;
				this.auditOrder.state=3;
				//发送请求
				this.request.post("/Transfers/option",this.auditOrder).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//搜索
			search(){
				this.Init();
			},
			handleSelectionChange(val) {
				this.ids = [];
				for (var i = 0; i < val.length; i++) {
					this.ids.push(val[i].id);
				}
			},
			//切换页码
			handleCurrentChange(index) {
				this.search_order.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_order.pageSize = pageSize;
				this.Init();
			},
		}
	}
	
</script>

<style>
</style>