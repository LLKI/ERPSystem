<template>
	<div>
		<!-- 图形化显示 -->
		<div style="height:20vh;display: flex;margin-bottom: 20px;">
			<div style="flex: 1;">
				<el-card shadow="hover" style="height: 100%;">
					<div>
						<el-tag effect='plain' style="width: 100%;text-align: center;">本日发送数量</el-tag>
					</div>
					<div style="margin-top: 20px;display: flex;justify-content: space-between;">
						<div>
							<span class="el-icon-pie-chart" style="font-size: 40px;color: #409EFF;"></span>
						</div>
						<div>
							<span style="font-size: 30px;color: red;">{{count.dayCount}}</span>
						</div>
					</div>

				</el-card>
			</div>
			<div style="flex: 1;">
				<el-card shadow="hover" style="height: 100%;">
					<div>
						<el-tag effect='plain' type="success" style="width: 100%;text-align: center;">本周发送数量</el-tag>
					</div>
					<div style="margin-top: 20px;display: flex;justify-content: space-between;">
						<div>
							<span class="el-icon-pie-chart" style="font-size: 40px;color: #67C23A;"></span>
						</div>
						<div>
							<span style="font-size: 30px;color: red;">{{count.weekCount}}</span>
						</div>
					</div>
				</el-card>

			</div>
			<div style="flex: 1;">
				<el-card shadow="hover" style="height: 100%;">
					<div>
						<el-tag effect='plain' type="info" style="width: 100%;text-align: center;">总发送数量</el-tag>
					</div>
					<div style="margin-top: 20px;display: flex;justify-content: space-between;">
						<div>
							<span class="el-icon-pie-chart" style="font-size: 40px;color: #909399;"></span>
						</div>
						<div>
							<span style="font-size: 30px;color: red;">{{count.userCount}}</span>
						</div>
					</div>
				</el-card>

			</div>
			<div style="flex: 1;">
				<el-card shadow="hover" style="height: 100%;">
					<div>
						<el-tag effect='plain' type="danger" style="width: 100%;text-align: center;">所有公告数量</el-tag>
					</div>
					<div style="margin-top: 20px;display: flex;justify-content: space-between;">
						<div>
							<span class="el-icon-pie-chart" style="font-size: 40px;color: #F56C6C;"></span>
						</div>
						<div>
							<span style="font-size: 30px;color: red;">{{count.totalCount}}</span>
						</div>
					</div>
				</el-card>

			</div>
		</div>
		<div class="con">
			<div class="box">
				<div v-for="(item,index) in typeList" :key="index">
					<div>
						<el-card class="box-card" style="border: 1px solid rgba(0,0,0,0.2);">
							<div slot="header" class="clearfix">
								<span>{{item.typeName}}</span>
								<span :class="item.icon" style="float: right; padding: 3px 0;color:red;"></span>
							</div>
							<div class="content">
								<div>
									<template v-if="item.notice.length==0">
										<span style="color: red;">暂无数据</span>
									</template>
									<template v-else>
										
											<div v-for="(con,index) in item.notice">
												<div class="title" >
													<div @click="gotoDetail(con.id,item.sign)" v-if="item.sign!='MYNEWS'">
														{{index+1}}-{{con.title}}
													</div>
													<div v-else v-html="(index+1)+'-'+con.title" @click="gotoDetail(con.id,item.sign)">
														
													</div>
													<div style="font-weight: 200;font-size: 10px;line-height: 30px;">
														-{{con.addTime}}
													</div>
												</div>
											</div>
									</template>
								</div>

							</div>
						</el-card>
					</div>
				</div>
			</div>
		</div>

		<!-- 弹窗 -->
		<el-drawer title="" :visible.sync="drawer" :direction="direction" size="50%">
			<div v-html="detail.title"  slot="title"></div>
			<div style="padding: 30px;" v-html="detail.content">

			</div>
			<div style="display: flex;font-size: 14px;color: gray;justify-content: flex-end;padding-right: 30px;">
				<div>发布时间：{{detail.addTime}}</div>&emsp;

				<div>发布人：{{trueName}}</div>
			</div>
		</el-drawer>
	</div>
</template>

<script>
	import {
		Loading
	} from 'element-ui'
	import {
		quillEditor
	} from "vue-quill-editor"; //调用编辑器
	import 'quill/dist/quill.core.css';
	import 'quill/dist/quill.snow.css';
	import 'quill/dist/quill.bubble.css';
	export default {
		name: 'Home',
		components: {

			quillEditor

		},
		data() {
			return {
				typeList: [],
				activeNames: [],
				titleList: [],
				drawer: false,
				detail: {},
				direction: 'rtl',
				editorOption: {},
				count: {},
				trueName: '',
				userId: JSON.parse(localStorage.getItem("userInfo")).id
			}
		},
		mounted() {
			this.Init();
		},
		methods: {
			
			//初始化
			Init() {
				this.loadingInstance = Loading.service({
					text: "加载中请稍后...",
					spinner: 'el-icon-loading',
					background: 'rgba(0,0,0,0.7)'
				});
				this.request.get("/notify/all/"+this.userId).then(res => {
					this.typeList = res.data;
					for (var i = 0; i < res.data.length; i++) {
						this.activeNames.push(res.data[i].id);
					}
				});
				//统计数据
				this.request.get("/notify/count/" +this.userId).then(res => {
					this.count = res.data;
				})
				
				this.loadingInstance.close();
			},
			//查看详情
			gotoDetail(id, sign) {
				this.drawer = true;
				this.request.get("/notify/" + id).then(res => {
					this.detail = res.data;
					if (sign == "MYNEWS") {
						this.trueName = "系统"
					} else {
						this.trueName = res.data.trueName;
					}

				});

			},
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {});
			},

		},
		computed: {}
	}
</script>

<style scoped>
	#title:hover {
		color: red;
	}

	/* .con{
		height: calc(80vh - 103px);
	} */
	.box {
		display: flex;
		flex-direction: row;
	}

	.box div {
		flex: 1;
	}

	.content {
		height: calc(80vh - 31vh);
		overflow: auto;
	}

	.title {
		font-size: 1em;
		color: #808080;
		font-weight: bold;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: space-around;
	}

	.title:hover {
		color: black;
	}
</style>
