<template>
	<div>
		<el-tabs type="border-card" style="min-height: 85vh;" @tab-click='changeState'>
			<el-tab-pane label="未审核" name="0"></el-tab-pane>
			<el-tab-pane label="已审核" name="1"></el-tab-pane>
			<el-tab-pane label="已驳回" name="2"></el-tab-pane>
			<el-tab-pane label="已撤销" name="3"></el-tab-pane>
			<div>
				<buyOrderList :key="state" :state='state'></buyOrderList>
			</div>
			
		</el-tabs>
	</div>
</template>

<script>
	import buyOrderList from '../../components/buyOrderList.vue'
	export default {
		components: {
			buyOrderList
		},
		data() {
			return {
				detail: {},
				state: 0,
				title: '',
				timer: ''
			}
		},
		created() {

		},
		methods: {
			changeState(tab, event) {
				this.state = tab.name;
				
			},
			//删除
			delData(id) {

			},
			//修改
			editData(id) {

			},

		},
	}
</script>

<style>
</style>
