<template>
	<div>
		<!-- 头部 搜索栏 -->
		<div class="head" style="display: flex;">
			<div style="margin-right: 20px;">
				<el-input type="text" placeholder="请输入商品名称" v-model="search_pro.proName" clearable></el-input>
			</div>
			<div style="margin-right: 20px;">
				<el-input type="text" placeholder="请输入审核人名称" v-model="search_pro.addPerson" clearable></el-input>
			</div>
			<div style="margin-right: 20px;">
				<span>审核状态：</span>
				<span>
					<el-select v-model="search_pro.isAudio" clearable placeholder="请选择">
						<el-option v-for="item in isAudioOptions" :key="item.value" :label="item.label"
							:value="item.value">
						</el-option>
					</el-select>
				</span>
			</div>
			<div style="margin-right: 20px;">
				<span>是否启用：</span>
				<span>
					<el-select v-model="search_pro.isEnable" clearable placeholder="请选择">
						<el-option v-for="item in isEnableOptions" :key="item.value" :label="item.label"
							:value="item.value">
						</el-option>
					</el-select>
				</span>
			</div>
			<div>
				<el-button type="primary" icon="el-icon-search" @click="searchData">搜索</el-button>
			</div>
		</div>
		<div style="margin-top: 20px;display: flex;" class="option">
			<div>
				<el-button type="success" icon="el-icon-plus" @click="addBrand" size="mini">添加</el-button>
			</div>
			<div>
				<el-button type="warning" icon="el-icon-download" size="mini" @click="exportData">导出excel</el-button>
			</div>

			<div>
				<el-upload class="upload-demo" :action="importDataAction" :limit="1" :on-success="importExcelSuccess"
					:before-upload="beforeImportExcel" :show-file-list="false" :data="userId" ref="upload2">
					<el-button type="primary" icon="el-icon-upload el-icon--right" size="mini">导入excel</el-button>
				</el-upload>
			</div>
			<div>
				<el-button type="danger" icon="el-icon-close" size="mini" @click="backPro_batch">批量退货</el-button>
			</div>
			<div >
				<el-button type="success" @click="download" icon="el-icon-download" size="mini">下载模板</el-button>
			</div>
		</div>

		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}"
				@selection-change="handleSelectionChange" tooltip-effect="dark" ref="multipleTable" @select="select"
				@select-all="selectAll">
				<el-table-column type="selection" width="55">
				</el-table-column>
				<el-table-column prop="id" label="编号" align="center" width="50">
				</el-table-column>
				<el-table-column prop="proName" label="商品名称" align="center">
				</el-table-column>
				<el-table-column label="商品图片" align="center">
					<template slot-scope="scope">
						<img :src="scope.row.proImg" style="width: 50px;height: 50px;cursor: pointer;"
							@click="showImg(scope.row.proImg)" />
					</template>
				</el-table-column>
				<el-table-column label="是否启用" align="center">
					<template slot-scope="scope">
						<el-switch v-model="isEnable=scope.row.isEnable" :active-value="0" :inactive-value="1"
							active-color="#13ce66" inactive-color="#ff4949"
							@change="changeState(scope.row.id,scope.row.isEnable)">
						</el-switch>
					</template>
				</el-table-column>
				<el-table-column prop="costPrice" label="成本" align="center">
					<template slot-scope="scope">
						<span style="color: #F56C6C;">￥{{scope.row.costPrice}}元</span>
					</template>
				</el-table-column>
				<el-table-column prop="price" label="售价" align="center">
					<template slot-scope="scope">
						<span style="color: #F56C6C;">￥{{scope.row.price}}元</span>
					</template>
				</el-table-column>
				<el-table-column prop="stock" label="库存" align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.stock.split('-')[0]!='0'">{{scope.row.stock}}</span>
						<el-tag type="danger" v-else>缺货</el-tag>
					</template>
				</el-table-column>
				<el-table-column prop="isBackPro" label="是否支持退货" align="center">
					<template slot-scope="scope">
						<el-tag type="success" v-if="scope.row.isBackPro==0">支持</el-tag>
						<el-tag type="danger" v-else>不支持</el-tag>
					</template>

				</el-table-column>
				<el-table-column prop="isAudio" label="状态" align="center">
					<template slot-scope="scope">
						<el-tag type="warning" v-if="scope.row.isAudio==0">未审核</el-tag>
						<!-- <el-tag type="success" v-if="scope.row.isAudio==1">已审核</el-tag> -->
						<el-tag type="danger" v-if="scope.row.isAudio==2">未通过</el-tag>
						<el-tag type="info" v-if="scope.row.isAudio==3">已撤销</el-tag>

						<el-tag type="primary" v-if="scope.row.isAudio==4">待付款</el-tag>
						<el-tag type="success" v-if="scope.row.isAudio==5">已付款</el-tag>

						<el-tag type="danger" v-if="scope.row.isAudio==6">取消支付</el-tag>
						<el-tag type="success" v-if="scope.row.isAudio==7">待退货</el-tag>
						<el-tag type="success" v-if="scope.row.isAudio==8">已退货</el-tag>
						<!-- <el-tag type="success" v-if="scope.row.isAudio==9">出库</el-tag> -->
						<!-- <el-tag type="success" v-if="scope.row.isAudio==10">调拨</el-tag> -->
					</template>
				</el-table-column>
				<el-table-column align="center" label="操作" width="270">
					<template slot-scope="scope">
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id)" size="small">修改
						</el-button>
						<el-button type="warning" size="small" icon="el-icon-view" @click="lookDetail(scope.row.id)">详情
						</el-button>
						<el-dropdown split-button type="success" style="margin-left: 10px;" trigger="click" size="small"
							icon="el-icon-s-grid">
							更多
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item style="width:100px;color: #F56C6C;"
									v-if="scope.row.isAudio==5&&scope.row.isBackPro==0">
									<span class="el-icon-remove" style="display: inline-block;width: 100%;"
										@click="delData(scope.row.id)">退货</span>
								</el-dropdown-item>
								<el-dropdown-item style="width:100px;color: #F56C6C;"
									v-if="scope.row.isAudio==3||scope.row.isAudio==6||scope.row.isAudio==2">
									<span class="el-icon-close" style="display: inline-block;width: 100%;"
										@click="delPro(scope.row.id)">删除</span>
								</el-dropdown-item>
								<el-dropdown-item style="width:100px;color: #409EFF;" v-if="scope.row.isAudio==5">
									<span class="el-icon-circle-check" style="display: inline-block;width: 100%;"
										@click="outWarehouse(scope.row.id)">出库</span>
								</el-dropdown-item>
								<el-dropdown-item style="width:100px;color: #E6A23C;" v-if="scope.row.isAudio==5">
									<span class="el-icon-truck" style="display: inline-block;width: 100%;"
										@click="transfersShow(scope.row.id)">调拨</span>
								</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
					</template>
				</el-table-column>
			</el-table>
		</div>
		<!-- 分页 -->
		<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
			<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page.sync="search_pro.pageIndex" :page-sizes="[7,10,15,20]" :page-size="search_pro.pageSize"
				layout="sizes, prev, pager, next,total" :total="search_pro.total">
			</el-pagination>
		</div>


		<!-- 弹窗 查看详情-->
		<div>
			<el-dialog title="商品详情" :visible.sync="dialogVisible" width="30%">
				<el-card class="box-card">
					<div class="detail">
						<div style="display: flex;justify-content: space-between;position: relative;">
							<div v-if="orderDetail.paymentOrder.length<=0||orderDetail==null">
								<span>采购订单号：</span>
								<span style="color:#409EFF;font-size: 12px;">{{orderDetail.proNo}}</span>
								<!-- <span v-else>{{detail.color}}</span> -->
							</div>
							<div v-else>
								<span>付款订单号：</span>
								<span
									style="color:#409EFF;font-size: 12px;">{{orderDetail.paymentOrder[0].proNo}}</span>
								<!-- <span v-else>{{detail.color}}</span> -->
							</div>
							<div style="position: absolute;right: 0;">
								<div v-if="detail.isAudio==0">
									<el-result icon="warning" title="未审核">
									</el-result>
								</div>
								<div v-if="detail.isAudio==1">
									<el-result icon="success" title="已审核">
									</el-result>
								</div>
								<div v-if="detail.isAudio==2">
									<el-result icon="error" title="已驳回">
									</el-result>
								</div>
								<div v-if="detail.isAudio==3">
									<el-result icon="warning" title="已撤销">
									</el-result>
								</div>
								<div v-if="detail.isAudio==4">
									<el-result icon="info" title="待付款">
									</el-result>
								</div>
								<div v-if="detail.isAudio==5">
									<el-result icon="success" title="已付款">
									</el-result>
								</div>
								<div v-if="detail.isAudio==6">
									<el-result icon="danger" title="取消支付">
									</el-result>
								</div>
								<div v-if="detail.isAudio==7">
									<el-result icon="info" title="待退货">
									</el-result>
								</div>
								<div v-if="detail.isAudio==8">
									<el-result icon="success" title="已退货">
									</el-result>
								</div>
							</div>

						</div>
						<div>
							<span>品牌方：</span><span>{{detail.brand.brandName}}</span>
						</div>
						<div>
							<span>重量：</span>
							<span v-if="detail.proWeight==undefined||detail.proWeight==''"
								style="color: #F56C6C;">未知</span>
							<span v-else>{{detail.proWeight}}</span>
						</div>
						<div>
							<span>颜色：</span>
							<span v-if="detail.color==undefined||detail.color==''" style="color: #F56C6C;">未知</span>
							<span v-else>{{detail.color}}</span>
						</div>
						<div>
							<span>规格：</span>
							<span v-if="detail.size==undefined" style="color: #F56C6C;">未知</span>
							<span v-else>{{detail.size}}</span>
						</div>
						<div>
							<span>材质：</span>
							<span v-if="detail.material==undefined||detail.material==''"
								style="color: #F56C6C;">未知</span>
							<span>{{detail.material}}</span>
						</div>
						<div>
							<span>是否缺货：</span>
							<span v-text="detail.isEnough==0?'不缺货':'缺货'"></span>
						</div>
						<div>
							<span>审核时间：</span>
							<span v-if="detail.ackTime==undefined" style="color: #F56C6C;">未审核</span>
							<span v-else>{{detail.ackTime}}</span>
						</div>

						<div>
							<span>供应商：</span><span>{{detail.supplier.supplierName}}</span>
						</div>
						<div>
							<span>存放位置：</span><span>{{detail.address}}</span>
						</div>
						<div>
							<span>添加时间：</span>
							<span>{{detail.addTime}}</span>
						</div>
						<div v-if="detail.isAudio==2">
							<span>驳回理由：</span>
							<span style="color:#F56C6C;">{{orderDetail.remark}}</span>
						</div>
						<div v-if="detail.isAudio==3">
							<span>撤销理由：</span>
							<span style="color:#F56C6C;">{{orderDetail.remark}}</span>
						</div>
					</div>
				</el-card>
			</el-dialog>
		</div>

		<!-- 预览图片 -->
		<el-dialog :visible.sync="imgVisible" width="30%" center :modal='false'>
			<div>
				<img :src="imgUrl" style="width: 100%;height: 100%;" />
			</div>
		</el-dialog>
		<!-- 添加或修改 -->
		<el-drawer :title="title" :visible.sync="drawer" direction="ttb" style="width: 50%;margin: 0px auto;"
			size="95%">
			<div id="add">
				<div class="addPro">
					<div>
						<div><span style="color: red;">*</span>商品名称：</div>
						<div>
							<el-input placeholder="请输入商品名称" v-model="addPro.proName" clearable>
							</el-input>
						</div>
					</div>
					<div v-if="title=='添加商品'">
						<div><span style="color: red;">*</span>存放位置：</div>
						<div>
							<el-cascader v-model="reservoirId" :options="reservoryOptions" clearable>
							</el-cascader>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>品牌名：</div>
						<div>
							<el-select v-model="brandId" clearable placeholder="请选择品牌名">
								<el-option v-for="item in brandoptions" :key="item.value" :label="item.label"
									:value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>供应商：</div>
						<div>
							<el-select v-model="supplierId" clearable placeholder="请选择供应商">
								<el-option v-for="item in supplierptions" :key="item.value" :label="item.label"
									:value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>库存数量：</div>
						<div>
							<el-input placeholder="请输入库存数量" v-model="addPro.stock" clearable>
							</el-input>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>成本(单位元)：</div>
						<div>
							<el-input placeholder="请输入成本" v-model="addPro.costPrice" clearable>
							</el-input>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>售价(单位元)：</div>
						<div>
							<el-input placeholder="请输入售价" v-model="addPro.price" clearable>
							</el-input>
						</div>
					</div>
					<div>
						<div>图片：</div>
						<div>
							<el-upload class="avatar-uploader" :action="action" :show-file-list="false"
								:on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload" :data="addPro"
								:auto-upload="false" ref="upload" :on-change="changeImg" id="upload"
								list-type="picture-card" :file-list="filelist" :on-error="error">
								<img v-if="addPro.proImg" :src="addPro.proImg" class="avatar"
									style="width: 100%;height: 100%;">
								<i v-else class="el-icon-plus avatar-uploader-icon"></i>
							</el-upload>
						</div>
					</div>
				</div>
				<!-- 另一页 -->
				<div class="addPro" style="margin-left: 20px;">
					<div>
						<div><span style="color: red;">*</span>是否启用：</div>
						<div>
							<el-select v-model="addPro.isEnable" clearable placeholder="请选择品牌名">
								<el-option v-for="item in isEnableoptions" :key="item.value" :label="item.label"
									:value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>是否支持退货：</div>
						<div>
							<el-select v-model="addPro.isBackPro" clearable placeholder="请选择品牌名">
								<el-option v-for="item in isBackProoptions" :key="item.value" :label="item.label"
									:value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
					<div>
						<div><span style="color: red;">*</span>商品类型：</div>
						<div>
							<el-select v-model="addPro.proType" clearable placeholder="请选择品牌名">
								<el-option v-for="item in proTypeOptions" :key="item.value" :label="item.label"
									:value="item.value">
								</el-option>
							</el-select>
						</div>
					</div>
					<div>
						<div>大小：</div>
						<div>
							<el-input placeholder="请输入商品大小" v-model="addPro.size" clearable>
							</el-input>
						</div>
					</div>
					<div>
						<div>重量：</div>
						<div>
							<el-input placeholder="请输入重量" v-model="addPro.proWeight" clearable>
							</el-input>
						</div>
					</div>
					<div>
						<div>材质：</div>
						<div>
							<el-input placeholder="请输入商品材质" v-model="addPro.material" clearable>
							</el-input>
						</div>
					</div>
					<div>
						<div>颜色：</div>
						<div>
							<el-input placeholder="请输入商品颜色" v-model="addPro.color" clearable>
							</el-input>
						</div>
					</div>

					<div>
						<div>备注：</div>
						<div>
							<el-input placeholder="请输入备注" v-model="addPro.remark" clearable type="textarea">
							</el-input>
						</div>
					</div>
					<div style="margin-top: 50px;">
						<el-button type="primary" @click="option">提交</el-button>
					</div>
				</div>
			</div>
		</el-drawer>
		<!-- 退货弹窗 -->
		<div>
			<el-dialog :visible.sync="backVisible" width="45%" center :title="optionTitle">
				<el-card class="box-card">
					<!-- 单个 显示商品的原库存、单价、理由、退货去向 -->
					<template v-if="prosDetail.length<=0">
						<div style="display: flex;line-height: 50px;">
							<div style="border-right: 1px solid #2B2D42;flex: 1;">
								<!-- 显示商品信息 -->
								<div style="display: flex;">
									<div>商品名称：</div>
									<div>{{backOrderDetail.proName}}</div>
								</div>
								<div style="display: flex;">
									<div>商品成本：</div>
									<div style="color: #F56C6C;">￥{{backOrderDetail.costPrice}}元</div>
								</div>
								<div style="display: flex;">
									<div>现有库存：</div>
									<div>{{backOrderDetail.stock}}</div>
								</div>
							</div>
							<div style="flex: 1;margin-left: 15px;">
								<div style="display: flex;" v-if="optionTitle=='退货详情'">
									<div>退货数量：</div>
									<div style="margin-right: 5px;">
										<el-input-number :min="1" :max="max" size="mini" v-model="backOrder.backNum">
										</el-input-number>
									</div>
									<div>
										<el-button size="mini" round type="success" plain @click="allStock">全部库存
										</el-button>
									</div>
								</div>
								<div style="display: flex;" v-if="optionTitle=='出库详情'">
									<div>出库数量：</div>
									<div style="margin-right: 5px;">
										<el-input-number :min="1" :max="max" size="mini" v-model="outOrder.backNum">
										</el-input-number>
									</div>
									<div>
										<el-button size="mini" round type="success" plain @click="allStock">全部库存
										</el-button>
									</div>
								</div>
								<div style="display: flex;" v-if="optionTitle=='退货详情'">
									<div>退货原由：</div>
									<div>
										<el-input v-model="backOrder.remark" placeholder="请输入退货原由"></el-input>
									</div>
								</div>
								<div style="display: flex;align-items: center;width: 100%;" v-if="optionTitle=='出库详情'">
									<div>出库原由：</div>
									<div>
										<el-input v-model="outOrder.remark" placeholder="请输入出库原由" style="width: 100%;">
										</el-input>
									</div>
								</div>
								<div style="display: flex;">
									<div>货物去向：</div>
									<div>
										<el-input v-model="backOrder.gotoAddress" placeholder="请输入物品去向"></el-input>
									</div>
								</div>

							</div>
						</div>
					</template>
					<!-- 多个 -->
					<template v-else>
						<div v-for="(item,index) in prosDetail">
							<div
								style="display: flex;line-height: 50px;margin-top: 20px;background-color: rgba(255,255,255,0.1)">
								<div style="border-right: 1px solid #2B2D42;flex: 1;">
									<!-- 显示商品信息 -->
									<div style="display: flex;">
										<div>商品名称：</div>
										<div>{{item.proName}}</div>
									</div>
									<div style="display: flex;">
										<div>商品成本：</div>
										<div style="color: #F56C6C;">￥{{item.costPrice}}元</div>
									</div>
									<div style="display: flex;">
										<div>现有库存：</div>
										<div>{{item.stock}}</div>
									</div>
								</div>
								<div style="flex: 1;margin-left: 15px;">
									<div style="display: flex;">
										<div>退货数量：</div>
										<div style="margin-right: 5px;">
											<el-input-number :min="1" :max="parseInt(item.stock.split('-')[0])"
												size="mini" v-model="item.backNum"></el-input-number>
										</div>
										<div>
											<el-button size="mini" round type="success" plain
												@click="allStock_batch(item.stock,index)">全部库存</el-button>
										</div>
									</div>

									<div style="display: flex;">
										<div>货物去向：</div>
										<div>
											<el-input v-model="item.gotoAddress" placeholder="请输入物品去向"></el-input>
										</div>
									</div>
								</div>
							</div>

						</div>
						<div style="display: flex;align-items: center;margin-top: 20px;width: 100%;">
							<div>退货原由：</div>
							<div>
								<el-input v-model="backOrder_batch.remark" placeholder="请输入退货原由" style="width: 100%;">
								</el-input>
							</div>
						</div>

					</template>
				</el-card>
				<div style="margin-top: 10px;float: right;">
					<el-button type="primary" round icon="el-icon-circle-check" @click="backPro">确定</el-button>
				</div>
				<div style="clear: both;"></div>
			</el-dialog>
		</div>
		<!-- 调拨仓库 -->
		<div>
			<el-dialog title="调拨信息" :visible.sync="transfersVisible" width="45%">
				<div style="display: flex;line-height: 50px;">
					<div style="border-right: 1px solid #2B2D42;flex: 1;">
						<!-- 显示商品信息 -->
						<div style="display: flex;">
							<div>商品名称：</div>
							<div>{{transfersDetail.proName}}</div>
						</div>
						<div style="display: flex;">
							<div>现有库存：</div>
							<div>{{transfersDetail.stock}}</div>
						</div>
						<div style="display: flex;">
							<div>所在仓库：</div>
							<div style="color: #F56C6C;">{{transfersDetail.address}}</div>
						</div>
					</div>
					<div style="flex: 1;margin-left: 15px;">
						<div style="display: flex;">
							<div>调拨数量：</div>
							<div style="margin-right: 5px;">
								<el-input-number :min="1" :max="max" size="mini" v-model="transfers.backNum">
								</el-input-number>
							</div>
							<div>
								<el-button size="mini" round type="success" plain @click="allStock_transfers">全部库存
								</el-button>
							</div>
						</div>
						<div style="display: flex;align-items: center;width: 100%;">
							<div>调拨原由：</div>
							<div>
								<el-input v-model="transfers.remark" placeholder="请输入调拨原由" style="width: 100%;">
								</el-input>
							</div>
						</div>
						<div style="display: flex;">
							<div>调拨仓库：</div>
							<div>
								<el-cascader v-model="transfers.outAddress" :options="reservoryOptions" clearable>
								</el-cascader>
								</el-input>
							</div>
						</div>
					</div>
				</div>
				<span slot="footer" class="dialog-footer">
					<el-button @click="dialogVisible = false">取 消</el-button>
					<el-button type="primary" @click="transfers_option">确 定</el-button>
				</span>
			</el-dialog>
		</div>
	</div>
</template>

<script>
	import {
		Loading
	} from 'element-ui'
	export default {
		data() {
			return {
				transfersMax: 0,
				transfers: {},
				transfersDetail: {},
				transfersVisible: false,
				optionTitle: "",
				myList: [],
				search_pro: {
					pageIndex: 1,
					total: 0,
					pageSize: 7,
					proName: '',
					isAudio: '',
					isEnable: '',
					addPerson: '',
					isEnough: ''
				},
				detail: {
					brand: {},
					supplier: {}
				},
				isEnable: 0,
				isAudioOptions: [],
				isEnableOptions: [],
				dialogVisible: false,
				imgVisible: false,
				imgUrl: '',
				title: '',
				drawer: false,
				addPro: {
					id: '',
					isEnable: 0,
					proName: '',
					stock: '',
					costPrice: '',
					price: '',
					isBackPro: 0,
					proType: ''
				},
				brandoptions: [],
				supplierptions: [],
				reservoryOptions: [],
				brandId: '',
				supplierId: '',
				reservoirId: [],
				isBackProoptions: [],
				isEnableoptions: [],
				action: '',
				filelist: [],
				proTypeOptions: [],
				importDataAction: 'http://localhost:5000/api/product/import',
				userId: {
					id: JSON.parse(localStorage.getItem("userInfo")).id
				},
				disable: true,
				selectId: '',
				orderDetail: {
					paymentOrder: []
				},
				backOrder: {
					ids: [],
					backNum: 0
				},
				backVisible: false,
				backIds: [],
				backOrderDetail: {},
				max: 0,
				prosDetail: [],
				backOrder_batch: {
					userId: JSON.parse(localStorage.getItem("userInfo")).id,
					remark: '',
					gotoAddresses: [],
					backNums: [],
					ids: []
				},
				outOrder: {
					backNum: 0
				}
			}
		},
		methods: {
			//下载模板
			download(){
				this.request.get("/product").then(res=>{
					if(res.code==200){
						window.open(res.data,"_self");
						this.$message.success(res.msg);
					}
				})
			},
			
			op() {
				this.supplierId = '';
				this.brandId = '';
				this.request.get("/brand").then(res => {
					console.log(res.data);
					if (res.code == 200) {
						this.brandoptions = [];
						//品牌
						let list = res.data;
						for (var i = 0; i < list.length; i++) {
							let obj = {
								label: list[i].brandName,
								value: list[i].id
							};
							this.brandoptions.push(obj);
						}
						//供应商
						this.request.get("/supplier").then(res => {
							if (res.code == 200) {
								this.supplierptions = [];
								let list = res.data;
								for (var i = 0; i < list.length; i++) {
									let obj = {
										label: list[i].supplierName,
										value: list[i].id
									};
									this.supplierptions.push(obj);
								}
							}
						});
						//库区
						this.request.get("/warehouse/reservory").then(res => {
							if (res.code == 200) {
								let list = res.data;
								this.reservoryOptions = [];
								let obj = {}
								for (var i = 0; i < list.length; i++) {
									obj = {
										label: list[i].reservoirName,
										value: list[i].reservoirName,
										children: []
									}
									for (var j = 0; j < list[i].warehouse.length; j++) {
										let str = {
											label: list[i].warehouse[j].houseName,
											value: list[i].warehouse[j].houseName
										}
										obj.children.push(str);
									}

									this.reservoryOptions.push(obj);
								}
							}
						})
						//类型
						this.request.get("/proType").then(res => {
							if (res.code == 200) {
								this.proTypeOptions = [];
								let list = res.data;
								for (var i = 0; i < list.length; i++) {
									let obj = {
										label: list[i].typeName,
										value: list[i].typeName
									};
									this.proTypeOptions.push(obj);
								}
							}
						})
						//是否启用 是否支持退货
						this.isBackProoptions = [];
						this.isEnableoptions = [];
						this.addPro.isEnable = 0;
						this.addPro.isBackPro = 0;
						let enable1 = {
							label: '启用',
							value: 0
						}
						let enable2 = {
							label: '禁用',
							value: 1
						}
						this.isEnableoptions.push(enable1);
						this.isEnableoptions.push(enable2);
						let back1 = {
							label: "支持",
							value: 0
						}
						let back2 = {
							label: "不支持",
							value: 1
						}
						this.isBackProoptions.push(back1);
						this.isBackProoptions.push(back2);
					}
				})
			},
			//初始化
			Init() {
				this.loadingInstance = Loading.service({
					text: "加载中请稍后...",
					spinner: 'el-icon-loading',
					background: 'rgba(0,0,0,0.7)'
				});
				
				//this.$refs.upload.clearFiles(); //上传成功之后清除历史记录
				this.isEnableOptions = [];
				this.isAudioOptions = [];

				this.request.post("/product", this.search_pro).then(res => {
					if (res.code == 200) {
						this.myList = res.data.products;
						this.search_pro.total = res.data.total
						console.log(this.search_pro.total);
					}
				});
				//审核状态
				let audio1 = {
					label: '未审核',
					value: '未审核'
				};
				let audio2 = {
					label: '待付款',
					value: '待付款'
				};
				let audio6 = {
					label: '已付款',
					value: '已付款'
				};
				let audio3 = {
					label: '未通过',
					value: '未通过'
				};
				let audio4 = {
					label: '已撤销',
					value: '已撤销'
				};
				let audio5 = {
					label: '取消支付',
					value: '取消支付'
				};
				let audio7 = {
					label: '已通过',
					value: '已通过'
				};
				let enable1 = {
					label: '启用',
					value: '启用'
				};
				let enable2 = {
					label: '禁用',
					value: '禁用'
				};
				this.isEnableOptions.push(enable1);
				this.isEnableOptions.push(enable2);
				this.isAudioOptions.push(audio1);
				this.isAudioOptions.push(audio2);
				this.isAudioOptions.push(audio6);
				this.isAudioOptions.push(audio3);
				this.isAudioOptions.push(audio4);
				this.isAudioOptions.push(audio5);
				
				
				this.loadingInstance.close();
			},
			//执行添加或修改
			option() {
				// console.log(this.addPro.proName)
				// console.log(this.addPro.reservoir.id)
				// console.log(this.addPro.brand.id)
				// console.log(this.addPro.supplier.id)
				// console.log(this.addPro.stock)
				// console.log(this.addPro.costPrice)
				// console.log(this.addPro.price)
				// console.log(this.addPro.isEnable)
				// console.log(this.addPro.isProBack)
				// if(this.title=="添加商品"){
				// 	if(this.addPro.proName.length<=0||this.addPro.reservoir.length<=0 ||this.addPro.brand.id.length<=0||this.addPro.supplier.length<=0
				// 	||this.addPro.stock.length<=0||this.addPro.costPrice.length<=0||this.addPro.price.length<=0||this.addPro.isEnable==""||this.addPro.isProBack==""){
				// 		this.$message.error("请填写完整");
				// 		return;
				// 	}
				if(this.addPro.proName==undefined||this.addPro.proName==""){
					this.$message.warning("商品名称不能为空");
					return;
				}
				if(this.brandId==""||this.brandId==undefined){
					this.$message.warning("请选择品牌名称");
					return;
				}
				if(this.supplierId==""){
					this.$message.warning("请选择供应商");
					return;
				}
				if(this.addPro.stock==""||this.addPro.stock==undefined){
					this.$message.warning("商品库存不能为空");
					return;
				}else{
					if(this.addPro.stock.search("-")==-1){
						this.$message.warning("库存格式为：数量-单位，请包括关键字'-'");
						return;
					}
					var reg= /^[1-9]\d*-{1}\D*$/;
					if(!reg.test(this.addPro.stock)){
						this.$message.warning("库存格式为：数量-单位，请包括关键字'-'");
						return;
					}
				}
				
				if(this.addPro.costPrice==""||this.addPro.costPrice==undefined){
					this.$message.warning("商品成本不能为空");
					return;
				}
				if(this.addPro.price==""||this.addPro.price==undefined){
					this.$message.warning("商品售价不能为空");
					return;
				}
				if(this.addPro.proType==""||this.addPro.proType==undefined){
					this.$message.warning("请选择商品类型");
					return;
				}
				if (this.title == "添加商品") {
					this.action = "http://localhost:5000/api/product/add/img";
					let user = JSON.parse(localStorage.getItem("userInfo"));
					this.addPro.id = user.id;
					this.addPro.address = this.reservoirId[0] + ">" + this.reservoirId[1];
					this.addPro.supplierId = this.supplierId;
					this.addPro.brandId = this.brandId;

					//默认图片
					if (this.filelist.length <= 0) {
						//let reservoir = this.addPro.reservoirId[0]
						this.request.post("/product/add", this.addPro).then(res => {
							if (res.code == 200) {
								this.Init();
								this.drawer = false;
								this.$message.success(res.msg);
							} else {
								this.$message.error(res.msg);
							}
						})
					} else {
						//带图片
						this.$refs.upload.submit();
					}
				} else {
					this.addPro.id = this.selectId;
					this.addPro.supplierId = this.supplierId;
					this.addPro.brandId = this.brandId;
					//this.addPro.address = this.reservoirId[0] + ">" + this.reservoirId[1];
					this.action = "http://localhost:5000/api/product/update/img";
					//修改
					if (this.filelist.length > 0) {
						//alert(this.action)
						//带图片
						//console.log(this.addPro)
						this.$refs.upload.submit();
					} else {
						//不带图片的修改
						this.request.put("/product", this.addPro).then(res => {
							if (res.code == 200) {
								this.Init();
								this.drawer = false;
								this.$message.success(res.msg);
							} else {
								this.$message.error(res.msg);
							}
						})
					}

				}

			},
			//显示 调拨的窗体
			transfersShow(id) {
				this.transfers = {
					userId: this.userId.id,
					backNum: 0,
					id:id
				}
				//this.backOrder={}
				this.request.get("/product/" + id).then(res => {
					if (res.code == 200) {
						this.transfersDetail = res.data.products
						this.max = parseInt(this.transfersDetail.stock.split('-')[0]);
					}
				});
				//库区
				this.request.get("/warehouse/reservory").then(res => {
					if (res.code == 200) {
						let list = res.data;
						this.reservoryOptions = [];
						let obj = {}
						for (var i = 0; i < list.length; i++) {
							obj = {
								label: list[i].reservoirName,
								value: list[i].reservoirName,
								children: []
							}
							for (var j = 0; j < list[i].warehouse.length; j++) {
								let str = {
									label: list[i].warehouse[j].houseName,
									value: list[i].warehouse[j].houseName
								}
								obj.children.push(str);
							}
				
							this.reservoryOptions.push(obj);
						}
					}
				})
				this.transfersVisible = true;
			},
			//添加(显示窗体)
			addBrand() {
				this.addPro = {};
				this.reservoirId = []
				this.title = "添加商品";
				this.drawer = true;
				this.op();
			},
			//显示出库的窗体
			outWarehouse(id) {
				this.optionTitle = "出库详情";
				this.backVisible = true;
				this.outOrder = {
					backNum: 0,
					id: id
				}
				//this.backOrder={}
				this.request.get("/product/" + id).then(res => {
					if (res.code == 200) {
						this.backOrderDetail = res.data.products
						this.max = parseInt(this.backOrderDetail.stock.split('-')[0]);
					}
				})
			},
			//显示退货的窗体
			delData(id) {
				this.optionTitle = "退货详情";
				this.$refs.multipleTable.clearSelection();
				this.backVisible = true;
				this.backIds = [];
				this.prosDetail = []
				this.backOrder = {
					ids: [],
					backNum: 0
				};
				this.backOrder.id = id;
				//this.backOrder={}
				this.request.get("/product/" + id).then(res => {
					if (res.code == 200) {
						this.backOrderDetail = res.data.products
						this.max = parseInt(this.backOrderDetail.stock.split('-')[0]);
					}
				})
			},
			//显示退货的窗体 批量退货
			backPro_batch() {
				this.optionTitle = "退货详情";
				if (this.backOrder.ids == null || this.backOrder.ids.length <= 0) {
					this.$message.warning("请先选择数据");
					return;
				}
				let obj = {
					ids: this.backOrder.ids
				}

				this.request.post("/product/ids", obj).then(res => {
					if (res.code == 200) {
						this.prosDetail = [];
						for (var i = 0; i < res.data.length; i++) {
							this.prosDetail.push(res.data[i]);
						}
					}
				})
				this.backVisible = true;
			},
			//退货
			backPro() {
				if (this.optionTitle == "退货详情") {
					this.backOrder.userId = this.userId.id;
					if (this.backOrder.backNum == 0) {
						this.$message.info("退货数量不能为0");
						return;
					}
					//单个退货
					if (this.backOrder.ids.length <= 0) {
						if (this.backOrder.remark == '' || this.backOrder.remark == undefined) {
							this.$message.warning("退货原由不能为空");
							return;
						} else if (this.backOrder.gotoAddress == '' || this.backOrder.gotoAddress == undefined) {
							this.$message.warning("物品去向不能为空");
							return;
						}
						this.request.post("/product/back", this.backOrder).then(res => {
							if (res.code == 200) {
								this.Init();
								this.backVisible = false;
								this.$message.success(res.msg);
							} else {
								this.$message.error(res.msg)
							}
						})
					} else {
						//批量操作
						if (this.backOrder_batch.remark == "") {
							this.$message.warning("退货原由不能为空");
							return;
						}
						console.log(this.prosDetail);
						this.backOrder_batch.gotoAddresses = [];
						this.backOrder_batch.backNums = [];
						this.backOrder_batch.ids = this.backOrder.ids;
						for (var i = 0; i < this.prosDetail.length; i++) {
							if (this.prosDetail[i].gotoAddress == "" || this.prosDetail[i].gotoAddress == null) {
								this.$message.warning("物品去向不能为空");
								return;
							}
							this.backOrder_batch.gotoAddresses.push(this.prosDetail[i].gotoAddress);
							this.backOrder_batch.backNums.push(this.prosDetail[i].backNum);
						}
						//发送请求
						this.request.post("/product/back", this.backOrder_batch).then(res => {
							if (res.code == 200) {
								this.Init();
								this.backVisible = false;
								this.$message.success(res.msg);
							} else {
								this.$message.error(res.msg)
							}
						})
						console.log(this.backOrder_batch);

					}
				} else {
					this.outOrder.gotoAddress = this.backOrder.gotoAddress
					this.outOrder.userId = this.userId.id;
					if (this.outOrder.remark == '' || this.outOrder.remark == undefined) {
						this.$message.warning("出库原由不能为空");
						return;
					} else if (this.outOrder.gotoAddress == '' || this.outOrder.gotoAddress == undefined) {
						this.$message.warning("出库去向不能为空");
						return;
					}
					//执行出库
					this.request.post("/product/outpro", this.outOrder).then(res => {
						if (res.code == 200) {
							this.Init();
							this.backVisible = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				}
			},
			//执行调拨
			transfers_option() {
				if(this.transfers.remark==""||this.transfers.remark==undefined){
					this.$message.warning("调拨理由不能为空");
					return;
				}
				if(this.transfers.outAddress==undefined||this.transfers.outAddress.length<=0){
					this.$message.warning("调拨仓库不能为空");
					return;
				}
				if(this.transfers.outAddress[0]+">"+this.transfers.outAddress[1]==this.transfersDetail.address){
					this.$message.warning("不能选择原位置");
					return
				}
				this.request.post("/product/transfers",this.transfers).then(res=>{
					if(res.code==200){
						this.Init();
						this.transfersVisible=false;
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			allStock_batch(stock, index) {
				this.prosDetail[index].backNum = stock.split("-")[0];
			},
			allStock_transfers() {
				this.transfers.backNum = this.transfersDetail.stock.split('-')[0];
			},
			allStock() {
				if (this.optionTitle == "退货详情") {
					this.backOrder.backNum = this.backOrderDetail.stock.split('-')[0];
				} else {
					this.outOrder.backNum = this.backOrderDetail.stock.split('-')[0];
				}


			},
			//删除
			delPro(id) {
				this.request.delete("/product/" + id).then(res => {
					if (res.code == 200) {
						this.Init();
						this.$message.success(res.msg)
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//修改（显示弹窗）
			editData(id) {
				this.op();
				this.filelist = [];
				this.title = "修改商品信息";
				this.drawer = true;
				this.selectId = id;
				///this.addPro
				this.request.get("/product/" + id).then(res => {
					if (res.code == 200) {
						this.addPro = res.data.products;
						this.addPro.proImg = res.data.products.proImg
						this.supplierId = res.data.products.supplierId;
						this.brandId = res.data.products.brandId;
					}
				})
			},
			//修改状态
			changeState(id, state) {
				this.request.get("/product/" + id + "/" + state).then(res => {
					if (res.code == 200) {
						this.$message.success(res.msg);
						this.isEnable = res.data;
					} else {
						this.$message.error(res.error);
					}
				})
			},
			//搜索
			searchData() {
				this.Init();
			},
			//预览图片
			showImg(url) {
				this.imgUrl = url;
				this.imgVisible = true;
			},
			//查看详情
			lookDetail(id) {
				this.dialogVisible = true;
				this.request.get("/product/" + id).then(res => {
					if (res.code == 200) {
						this.detail = res.data.products;
						this.orderDetail = res.data.order;
						console.log(res.data)
					}
				})
			},
			handleSelectionChange(val) {
				this.multipleSelection = val;
				this.backOrder.ids = []
				for (var i = 0; i < val.length; i++) {
					this.backOrder.ids.push(val[i].id);
				}
			},
			select(s, w) {

				if (w.isBackPro != 0) {
					this.$message.warning("您选中的商品不支持退货");
					this.$refs.multipleTable.toggleRowSelection(w);
					return;
				} else if (w.isEnough == 1) {
					this.$message.warning("您选中的商品库存不足");
					this.$refs.multipleTable.toggleRowSelection(w);
					return;
				} else if (w.isAudio != 5) {
					this.$message.warning("您选中的商品未付款");
					this.$refs.multipleTable.clearSelection();
				}
			},
			selectAll(s) {
				console.log(s)
				try {
					s.forEach((s) => {
						if (s.isBackPro != 0) {
							this.$message.warning("您选中了不支持退货的商品");
							this.$refs.multipleTable.clearSelection();
							return false;
						} else if (s.isEnough == 1) {
							this.$message.warning("您选中的商品库存不足");
							this.$refs.multipleTable.clearSelection();
							return false;
						} else if (s.isAudio != 5) {
							this.$message.warning("您选中的商品未付款");
							this.$refs.multipleTable.clearSelection();
							throw new Error("到d就停止吧");
						}
					})
				} catch (e) {

				}


			},
			//切换页码
			handleCurrentChange(index) {
				this.search_pro.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_pro.pageSize = pageSize;
				this.Init();
			},
			//更换图片
			changeImg(file, fileList) {
				this.filelist = [];
				this.filelist.push(file);
				//回显图片
				for (var i = 0; i < fileList.length; i++) {
					if (fileList.length >= 2) {
						fileList.splice(i - 2, 1);
					}
					this.addPro.proImg = fileList[fileList.length - 1].url;
				}

			},
			//成功
			handleAvatarSuccess(res, file) {
				if (res.code == 200) {
					this.$refs.upload.clearFiles(); //上传成功之后清除历史记录
					this.drawer = false;
					this.Init();
					this.$message.success(res.msg);
				} else {
					this.$refs.upload.clearFiles(); //上传成功之后清除历史记录
					this.$message.error(res.msg);
				}
				//this.addBrandData.img = res.data.img
			},
			//失败
			error(err, file, fileList) {
				//this.$refs.upload.clearFiles(); //上传成功之后清除历史记录
				this.$message.error("请重新选择图片");
			},
			//上传之前
			beforeAvatarUpload(file) {
				//console.log("你好");
				//console.log("文件"+file)
				//console.log(file)
				//this.addPro.proImg = file;
				const isJPG = file.type === 'image/jpeg';
				const IsPNG = file.type === "image/png";
				const IsBMP = file.type === "image/bmp";
				const ISJPEG = file.type === "image/jpg";
				const IsGIF = file.type === "image/gif";
				const isLt2M = file.size / 1024 / 1024 < 20;
				if (!isJPG && !IsPNG && !IsBMP && !ISJPEG && !IsGIF) {
					this.$message.error('上传头像图片格式不正确!');
					return false;
				}
				if (!isLt2M) {
					this.$message.error('上传头像图片大小不能超过 20MB!');
					return false;
				}
				return true;
			},
			//导出
			exportData() {
				if (this.myList.length <= 0 || this.myList == null) {
					this.$message.error("没有数据")
					return;
				}
				this.request.post("/product/export", this.search_pro).then(res => {
					if (res.code == 200) {
						console.log(res.data);
						this.$message.success("导出成功");
						window.open(res.data, "_self");
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//导入,
			//excel 导入成功后
			importExcelSuccess(res, file) {
				if (res.code == 200) {
					this.Init();
					this.$refs.upload2.clearFiles(); //上传成功之后清除历史记录
					this.$message.success(res.msg);
				} else {
					this.$refs.upload2.clearFiles(); //上传成功之后清除历史记录
					this.$message.error(res.msg);
				}
			},
			//导入excel 之前
			beforeImportExcel(file) {
				console.log(file);
				const isXLSX = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

				if (!isXLSX) {
					this.$message.error('上传文件格式不正确!');
				}

				return isXLSX;
			}
			//修改状态
		},
		created() {
			this.Init();
		},

	}
</script>

<style scoped>
	.detail div {
		display: flex;
		margin: 10px 0px;
	}

	.detail div span:nth-child(1) {
		display: block;
		width: 100px;
		font-weight: bold;
	}

	.detail div span:nth-child(2) {
		color: #2B2D42;
	}

	/* 添加商品 */
	#add {
		padding: 20px;
		display: flex;
	}

	#add div {
		/* display: flex; */
		/* align-items: center; */
		margin-bottom: 5px;
	}

	.addPro div {
		display: flex;
		align-items: center;
	}

	.addPro div div:nth-child(1) {
		width: 140px;
	}

	.option div {
		margin-right: 15px;
	}

	/* 	#add div div {
		display: flex;
		align-items: center;
	} */
</style>
