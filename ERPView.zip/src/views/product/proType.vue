<template>
	<div style="display: flex;flex-wrap:wrap;justify-content: start;align-items: center;">
		<div class="head" style="height: 50%;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);width: 100%;padding: 20px;">
			<h1 style="text-align: center;">添加类型</h1>
			<div style="width: 40%;margin: 0px auto;">
				<div style="display: flex;margin-top: 10px;">
					<div style="width: 150px;">类型名称：</div><el-input type="text" v-model="proType.typeName"></el-input>
				</div>
				<div style="display: flex;margin-top: 10px;">
					<div style="width: 150px;">备注：</div><el-input type="text" v-model="proType.remark"></el-input>
				</div>
				<div style="margin-top: 10px;display: flex;">
					<div style="width: 150px;">是否启用：</div>
					<el-switch v-model="proType.isEnable" :active-value="0" :inactive-value="1"
						active-color="#13ce66" inactive-color="#ff4949"
						>
					</el-switch>
				</div>
				<div style="margin: 10px auto;width: 50px;">
					<el-button type="primary" icon="el-icon-circle-plus-outline" @click="addProType">添加</el-button>
				</div>
				
			</div>
		</div>
		<div class="container" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList.filter(data => !search || data.typeName.toLowerCase().includes(search.toLowerCase()))" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black'}" :row-style="{height:'10px'}" height="45vh">
				<el-table-column prop="id" label="编号" align="center">
				</el-table-column>
				<el-table-column prop="typeName" label="类型名称" align="center">
				</el-table-column>
				<el-table-column label="是否启用" align="center">
					<template slot-scope="scope">
						<el-switch v-model="isEnable=scope.row.isEnable" :active-value="0" :inactive-value="1"
							active-color="#13ce66" inactive-color="#ff4949"
							@change="changeState(scope.row.id,scope.row.isEnable)">
						</el-switch>
					</template>
				</el-table-column>
				<el-table-column prop="remark" label="备注" align="center">
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center">
				</el-table-column>
				<el-table-column align="right">
					<template slot="header" slot-scope="scope">
						<div style="display: flex;">
							<div style="font-size: 12px;color: gray;width:100px;">类型名称：</div>
							<div>
								<el-input v-model="search" size="mini" placeholder="请输入类型名称" style="float: left;" />
							</div>
						</div>
					</template>
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="small">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id)"
							style="padding:10px;font-size: 10px;" size="small">修改</el-button>
					</template>
				</el-table-column>

				<!-- <el-table-column label="操作" align="center">
					
				</el-table-column> -->
			</el-table>
		</div>
		<!-- 弹窗 修改 -->
		<!-- 弹窗 -->
			<el-dialog
			  title="修改信息"
			  :visible.sync="dialogVisible"
			  width="30%"
			  >
			  <div class="head" style="height: 50%;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);padding: 20px;">
			  	<div style="margin: 0px auto;">
			  		<div style="display: flex;margin-top: 10px;">
			  			<div style="width: 150px;">类型名称：</div><el-input type="text" v-model="editProType.typeName" clearable></el-input>
			  		</div>
			  		<div style="display: flex;margin-top: 10px;">
			  			<div style="width: 150px;">备注：</div><el-input type="text" v-model="editProType.remark" clearable></el-input>
			  		</div>
			  		<div style="margin-top: 10px;display: flex;">
			  			<div style="width: 150px;">是否启用：</div>
			  			<el-switch v-model="editProType.isEnable" :active-value="0" :inactive-value="1"
			  				active-color="#13ce66" inactive-color="#ff4949"
			  				>
			  			</el-switch>
			  		</div>
			  	</div>
			  </div>
			  <span slot="footer" class="dialog-footer">
			    <el-button @click="dialogVisible = false">取 消</el-button>
			    <el-button type="primary" @click="updateProType">确 定</el-button>
			  </span>
			</el-dialog>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				search: '',
				proType:{
					isEnable:0
				},
				isEnable:0,
				dialogVisible:false,
				editProType:{
					isEnable:0,
				},
				proTypeId:0,
			}
		},
		created() {
			this.Init();
		},
		methods: {
			Init() {
				this.request.get("/proType").then(res => {
					this.myList = res.data;
				})
			},
			//更改状态
			changeState(id,state){
				this.request.put("/protype/"+id+"/"+state).then(res=>{
					if(res.code==200){
						this.isEnable=state;
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//删除
			delData(id) {
				this.request.delete("/proType/"+id).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//修改数据
			updateProType(){
				//
				this.dialogVisible=false;
			//	alert(this.proTypeId)
				this.request.put("/proType/"+this.proTypeId,this.editProType).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
				
			},
			//修改 (回显数据)
			editData(id) {
				this.proTypeId=id;
				this.dialogVisible=true;
				this.request.get("/proType/"+id).then(res=>{
					if(res.code==200){
						this.editProType=res.data;
					}
				})
			},
			//添加商品类型
			addProType(){
				if(this.proType.typeName==undefined){
					this.$message.error("请填写完整");
					return;
				}
				this.request.post("/proType",this.proType).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			}
		}
	}
</script>

<style>
</style>
