<template>
	<div>
		<div class="head" style="display: flex;margin-bottom: 20px;margin-top: 20px;">
			<div style="margin-right: 20px;">
				<el-input type="text" placeholder="请输入供应商名称" v-model="search_supplier.supplierName" clearable>
				</el-input>
			</div>
			<div style="margin-right: 20px;">
				<el-input type="text" placeholder="请输入手机号" v-model="search_supplier.phone" clearable></el-input>
			</div>
			<div style="margin-right: 20px;">
				<span>是否启用：</span>
				<span>
					<el-select v-model="search_supplier.isEnable" clearable placeholder="请选择">
						<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
						</el-option>
					</el-select>
				</span>
			</div>
			<div>
				<el-button type="primary" icon="el-icon-search" @click="searchData">搜索</el-button>
			</div>
		</div>
		<!-- 添加按钮 -->
		<div style="margin-top: 20px;">
			<el-button type="success" icon="el-icon-plus" @click="addSupplier">添加</el-button>
			<el-button type="warning" icon="el-icon-download" @click="exportSupplier">导出excel</el-button>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 30px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}">
				<el-table-column prop="id" label="编号" align="center" width="50">
				</el-table-column>
				<el-table-column prop="supplierName" label="供应商名称" align="center" width="150">
				</el-table-column>
				<el-table-column prop="contactperson" label="联系人" align="center">
				</el-table-column>
				<el-table-column prop="phone" label="联系电话" align="center" width="140">
				</el-table-column>
				<el-table-column label="公司网址" align="center" width="200">
					<template slot-scope="scope">
						<el-link type="primary" :href='scope.row.website' target="_brand">{{scope.row.website}}
						</el-link>
					</template>
				</el-table-column>
				<el-table-column label="是否启用" align="center">
					<template slot-scope="scope">
						<el-switch v-model="isEnable=scope.row.isEnable" :active-value="0" :inactive-value="1"
							active-color="#13ce66" inactive-color="#ff4949"
							@change="ChangeState(scope.row.id,scope.row.isEnable)">
						</el-switch>
					</template>
				</el-table-column>
				<el-table-column prop="email" label="邮箱" align="center" width="200">
				</el-table-column>
				<el-table-column prop="address" label="供应商地址" align="center" width="200">
				</el-table-column>
				<el-table-column prop="postalCode" label="邮政编码" align="center">
				</el-table-column>
				<el-table-column prop="mailingAddress" label="邮件地址" align="center" width="200">
				</el-table-column>
				<el-table-column prop="remark" label="备注" align="center">
				</el-table-column>
				<el-table-column prop="addTime" label="合作时间" align="center" width="180">
				</el-table-column>
				<el-table-column align="center" label="操作" fixed="right" width="180">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="small">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id)"
							style="padding:10px;font-size: 10px;" size="small">修改</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
		<!-- 分页 -->
		<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
			<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page.sync="search_supplier.pageIndex" :page-sizes="[7,10,15,20]"
				:page-size="search_supplier.pageSize" layout="sizes, prev, pager, next,total"
				:total="search_supplier.total">
			</el-pagination>
		</div>

		<!-- 弹窗 修改或者添加 -->
		<el-dialog :title="title" :visible.sync="dialogVisible" width="50%">
			<div style="display: flex;">
				<div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;"><span style="color: red;">*</span>供应商名称:</div>
						<div>
							<el-input placeholder="请输入供应商名称" v-model="supplier.supplierName" clearable autofocus>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;"><span style="color: red;">*</span>地址:</div>
						<div>
							<el-input placeholder="请输入地址" v-model="supplier.address" clearable>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;"><span style="color: red;">*</span>电子邮箱:</div>
						<div>
							<el-input placeholder="请输入电子邮箱" v-model="supplier.email" clearable type="email" id="email">
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;"><span style="color: red;">*</span>邮政地址:</div>
						<div>
							<el-input placeholder="请输入邮政地址" v-model="supplier.mailingAddress" clearable>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;"><span style="color: red;">*</span>联系人:</div>
						<div>
							<el-input placeholder="请输入联系人" v-model="supplier.contactperson" clearable>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;"><span style="color: red;">*</span>联系电话:</div>
						<div>
							<el-input placeholder="请输入联系电话" v-model="supplier.phone" id="phone" clearable
								:maxlength="11">
							</el-input>
						</div>
					</div>
				</div>
				<!-- 不是必填项 -->
				<div style="margin-left: 50px;">
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;">公司网址:</div>
						<div>
							<el-input placeholder="请输入网址" v-model="supplier.website" clearable>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;">邮政编码:</div>
						<div>
							<el-input placeholder="请输入邮政编码" v-model="supplier.postalCode" clearable>
							</el-input>
						</div>
					</div>
					<div style="display: flex;margin-bottom: 15px;align-items: center;">
						<div style="width: 100px;">备注:</div>
						<div>
							<el-input placeholder="备注" v-model="supplier.remark" clearable>
							</el-input>
						</div>
					</div>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button @click="dialogVisible = false">取 消</el-button>
				<el-button type="primary" @click="option">确 定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				search_supplier: {
					supplierName: '',
					isEnable: '',
					phone: '',
					pageIndex: 1,
					pageSize: 7,
					total: 0
				},
				options: [],
				title: '',
				dialogVisible: false,
				supplier: {

				},
				selectId: '',
			}
		},
		created() {
			this.Init();
		},
		methods: {
			Init() {
				this.request.post("/supplier", this.search_supplier).then(res => {
					this.myList = res.data;
					this.search_supplier.total = this.myList.length;
				})
				this.options = [];
				//是否启用
				let op1 = {
					label: '启用',
					value: '启用'
				};
				let op2 = {
					label: '禁用',
					value: '禁用'
				};
				this.options.push(op1);
				this.options.push(op2);
			},
			//执行添加或修改
			option() {
				//console.log(this.supplier.supplierName)
				if (this.supplier.supplierName == undefined || this.supplier.phone == undefined || this.supplier.email ==
					undefined || this.supplier.contactperson == undefined || this.supplier.mailingAddress == undefined ||
					this.supplier.address == undefined) {
					this.$message.error("请填写完整");
					return;
				}
				//添加
				const regex = /^1[3456789]\d{9}$/; //使用此正则即可
				if (!regex.test(this.supplier.phone)) {
					this.$message.error("手机号格式不正确");
					//光标定位
					document.getElementById("phone").focus();
					return;
				}
				var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
				if (!reg.test(this.supplier.email)) {
					this.$message.error("电子邮箱格式不正确");
					//光标定位
					document.getElementById("email").focus();
					return;
				}
				if (this.title == "添加供应商") {
					this.request.post("/supplier/add", this.supplier).then(res => {
						if (res.code == 200) {
							this.dialogVisible = false;
							this.Init();
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg)
						}
					})
				} else {
					//修改
					this.supplier.id == this.selectId;
					this.request.put("/supplier", this.supplier).then(res => {
						if (res.code == 200) {
							this.Init();
							this.dialogVisible = false;
							this.$message.success(res.msg);
						} else {
							this.$message.error(res.msg);
						}
					})
				}
			},
			//删除
			delData(id) {
				this.request.delete("/supplier/" + id).then(res => {
					if (res.code == 200) {
						this.Init();
						this.$message.success(res.msg);
					} else {
						this.$message.error(res.msg);
					}
				})
			},
			//修改(显示弹窗)
			editData(id) {
				this.title = "修改供应商信息"
				this.selectId = id;
				this.dialogVisible = true;
				this.request.get("/supplier/" + id).then(res => {
					if (res.code == 200) {
						console.log(res)
						this.supplier = res.data;
					}
				})
			},
			//搜索
			searchData() {
				this.Init();
			},
			//添加供应商(显示弹窗)
			addSupplier() {
				this.supplier = {}
				this.dialogVisible = true;
				this.title = "添加供应商";
			},
			//导出excel
			exportSupplier() {
				if(this.myList==null||this.myList.length<=0){
					this.$message.error("没有数据");
					return;
				}
				this.request.post("/supplier/export", this.search_supplier).then(res => {
					if (res.code == 200) {
						console.log(res.data);
						this.$message.success("导出成功");
						window.open(res.data, "_self");
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//更改状态
			ChangeState(id,state){
				this.request.put("/supplier/"+id+"/"+state).then(res=>{
					if(res.code==200){
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//切换页码
			handleCurrentChange(index) {
				this.search_supplier.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_supplier.pageSize = pageSize;
				this.Init();
			},
		},
	}
</script>

<style>
</style>
