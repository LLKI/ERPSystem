<template>
	<div>
		<div class="head" style="display: flex;">
			<div style="margin-right: 20px;">
				<el-input type="text" placeholder="请输入品牌名称" v-model="search_brand.brandName" clearable></el-input>
			</div>
			<div style="margin-right: 20px;">
				<span>类型：</span>
				<el-select v-model="search_brand.type" clearable placeholder="请选择">
					<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</div>
			<div style="margin-right: 20px;">
				<span>是否启用：</span>
				<span>
					<el-select v-model="search_brand.isEnable" clearable placeholder="请选择">
						<el-option v-for="item in isEnableOptions" :key="item.value" :label="item.label"
							:value="item.value">
						</el-option>
					</el-select>
				</span>
			</div>
			<div>
				<el-button type="primary" icon="el-icon-search" @click="searchData">搜索</el-button>
			</div>
		</div>
		<div style="margin-top: 20px;">
			<el-button type="success" icon="el-icon-plus" @click="addBrand">添加</el-button>
		</div>
		<!-- 表格内容 -->
		<div class="container" style="width: 100%;margin-top: 30px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black',height:'50px'}" :row-style="{height:'50px'}">
				<el-table-column prop="id" label="编号" align="center" width="100px">
				</el-table-column>
				<el-table-column prop="brandName" label="品牌名称" align="center">
				</el-table-column>
				<el-table-column label="品牌图片" align="center">
					<template slot-scope="scope">
						<img :src="scope.row.img" style="width: 50px;height: 50px;cursor: pointer;"
							@click="showImg(scope.row.img)" />
					</template>
				</el-table-column>
				<el-table-column label="是否启用" align="center">
					<template slot-scope="scope">
						<el-switch v-model="isEnable=scope.row.isEnable" :active-value="0" :inactive-value="1"
							active-color="#13ce66" inactive-color="#ff4949"
							@change="changeState(scope.row.id,scope.row.isEnable)">
						</el-switch>
					</template>
				</el-table-column>
				<el-table-column prop="proType.typeName" label="所属类型" align="center">
				</el-table-column>
				<el-table-column prop="remark" label="备注" align="center">
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center">
					<template slot-scope="scope">
						<span>{{scope.row.addTime.toLocaleString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '')}}</span>
					</template>
				</el-table-column>
				<el-table-column align="center" label="操作">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;" size="small">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id)"
							style="padding:10px;font-size: 10px;" size="small">修改</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
		<!-- 分页 -->
		<div class="block" style="width: 100%;margin-top: 20px;text-align: center;">
			<el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page.sync="search_brand.pageIndex" :page-sizes="[7,10,15,20]" :page-size="search_brand.pageSize"
				layout="sizes, prev, pager, next,total" :total="search_brand.total">
			</el-pagination>
		</div>
		<!-- 预览图片 -->
		<el-dialog :visible.sync="imgVisible" width="30%" center :modal='false'>
			<div>
				<img :src="imgUrl" style="width: 100%;height: 100%;" />
			</div>
		</el-dialog>

		<!-- 添加或者修改 -->
		<el-dialog :title="title" :visible.sync="dialogVisible" width="30%">
			<div>
				<div style="display: flex;align-items: center;margin-top: 15px;">
					<div style="width: 100px;"><span style="color:red;">*</span>品牌名称：</div>
					<div>
						<el-input placeholder="品牌名称" v-model="addBrandData.brandName" clearable style="width: 100%;">
						</el-input>
					</div>
				</div>
				<div style="display: flex;align-items: center;margin-top: 15px;">
					<div style="width: 100px;"><span style="color:red;">*</span>图片：</div>
					<div>
						<el-upload class="avatar-uploader" :action="action" :show-file-list="false"
							:on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload" :data="addBrandData"
							:auto-upload="false" ref="upload" :on-change="changeImg" id="upload" list-type="picture-card" 
							:file-list="filelist">
							<img v-if="addBrandData.img" :src="addBrandData.img" class="avatar" style="width: 100%;height: 100%;">
							<i v-else class="el-icon-plus avatar-uploader-icon"></i>
						</el-upload>
					</div>
				</div>
				<div style="display: flex;align-items: center;margin-top: 15px;">
					<div style="width: 100px;"><span style="color:red;">*</span>品牌类型：</div>
					<div>
						<el-select v-model="addBrandData.proTypeId" clearable placeholder="请选择">
							<el-option v-for="item in addOptions" :key="item.value" :label="item.label"
								:value="item.value">
							</el-option>
						</el-select>
					</div>
				</div>
				<div style="display: flex;align-items: center;margin-top: 15px;">
					<div style="width: 100px;"><span style="color:red;">*</span>是否启用：</div>
					<div>
						<el-select v-model="addBrandData.isEnable" clearable placeholder="请选择">
							<el-option v-for="item in addIsEnableOptions" :key="item.value" :label="item.label"
								:value="item.value">
							</el-option>
						</el-select>
					</div>
				</div>
				<div style="display: flex;align-items: center;margin-top: 15px;">
					<div style="width: 100px;">备注：</div>
					<div>
						<el-input placeholder="备注" v-model="addBrandData.remark" clearable style="width: 100%;">
						</el-input>
					</div>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button @click="dialogVisible = false">取 消</el-button>
				<el-button type="primary" @click="option">确 定</el-button>
			</span>
		</el-dialog>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				search: '',
				imgVisible: false,
				imgUrl: '',
				options: [],
				isEnable: '',
				isEnableOptions: [],
				search_brand: {
					isEnable: '',
					brandName: '',
					type: '',
					pageIndex:1,
					pageSize:7,
					total:0
				},
				title: '',
				dialogVisible: false,
				addOptions: [],
				addIsEnableOptions: [],
				addBrandData: {
					img:'',
					id:'',
					brandName:'',
					proTypeId:'',
					isEnable:0,
					remark:''
				},
				action: "http://localhost:5000/api/brand/update",
				brand: {},
				selectId:'',
				filelist:[]
			}
		},
		created() {
			this.Init();
		},
		methods: {
			Init() {
				this.options = [];
				this.addOptions = [];
				//let list=[];
				//类型
				this.request.get("/proType").then(res => {
					for (var i = 0; i < res.data.length; i++) {
						let option = {
							label: res.data[i].typeName,
							value: res.data[i].typeName
						};
						let option2 = {
							label: res.data[i].typeName,
							value: res.data[i].id
						};
						this.options.push(option);
						this.addOptions.push(option2);
					}
				})
				//所有数据
				this.request.post("/brand", this.search_brand).then(res => {
					if (res.code = 200) {
						console.log(res.data);
						this.myList = res.data;
						this.search_brand.total=res.data.length;
					}
				});
				this.isEnableOptions = [];
				this.addIsEnableOptions=[];
				var op1 = {
					value: '启用',
					label: '启用'
				};
				var op2 = {
					value: '禁用',
					label: '禁用'
				};
				var op3 = {
					value: 1,
					label: '禁用'
				};
				var op4 = {
					value: 0,
					label: '启用'
				};
				this.isEnableOptions.push(op1);
				this.isEnableOptions.push(op2);
				this.addIsEnableOptions.push(op3);
				this.addIsEnableOptions.push(op4);
			},
			//显示添加的窗口
			addBrand() {
				this.addBrandData={
					img:'',
					id:'',
					brandName:'',
					proTypeId:'',
					isEnable:0,
					remark:''
				}
				//this.addBrandData.id=-1;
				this.title = "添加品牌"
				this.dialogVisible = true;
				//this.uploadData={ 'id':-1 };
			},
			//添加或修改
			option(param) {
				if(this.addBrandData.brandName==""||this.addBrandData.img==""||this.addBrandData.proTypeId==""){
					this.$message.error("请填写完整");
					return;
				}
				if (this.title == "添加品牌") {
					this.addBrandData.id ='-1';
					this.$refs.upload.submit();
				} else {
					if(this.filelist.length>0){
						this.$refs.upload.submit();
					}else{
						this.request.put("/brand",this.addBrandData).then(res=>{
							if(res.code==200){
								this.Init();
								this.dialogVisible=false;
								this.$message.success(res.msg);
							}else{
								this.$message.error(res.msg);
							}
						})
					}
					
					
				}
			},
			//删除
			delData(id) {
				this.request.delete("/brand/"+id).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//修改
			editData(id) {
				//修改
				this.addBrandData.id=id;
				this.title="修改品牌信息";
				this.dialogVisible=true;
				this.filelist=[];
				this.request.get("/brand/"+id).then(res=>{
					if(res.code==200){
						console.log(res);
						this.addBrandData=res.data
						// this.fileList=[];
						// let file = res.data.img.split('/');
						// let imgName= file[file.length - 1];
						// this.fileList.push({
						// 	name:imgName,
						// 	url:res.data.img
						// })
						// console.log(this.fileList)
						this.addBrandData.id=res.data.id;
					}
				})
			},
			//预览图片
			showImg(url) {
				this.imgUrl = url;
				this.imgVisible = true;
			},
			//搜索
			searchData() {
				//所有数据
				this.request.post("/brand", this.search_brand).then(res => {
					if (res.code = 200) {
						console.log(res.data);
						this.myList = res.data;
						this.search_brand.total=res.data.length;
					}
				});
			},
			changeImg(file,fileList) {
				this.filelist=[];
				this.filelist.push(file);
				//回显图片
				for (var i = 0; i < fileList.length; i++) {
					if(fileList.length>=2){
						fileList.splice(i-2,1);
					}
					this.addBrandData.img=fileList[fileList.length-1].url;
				}
				
			},
			//更换图片
			handleAvatarSuccess(res, file) {
				console.log(res);
				if(res.code==200){
					this.$refs.upload.clearFiles(); //上传成功之后清除历史记录
					this.dialogVisible=false;
					this.Init();
					this.$message.success(res.msg);
				}else{
					this.$refs.upload.clearFiles();
					this.$message.error(res.msg);
				}
				//this.addBrandData.img = res.data.img
			},
			beforeAvatarUpload(file) {
				//console.log("你好");
				//console.log("文件"+file)
				
				this.addBrandData.img = file;
				const isJPG = file.type === 'image/jpeg';
				const IsPNG = file.type === "image/png";
				const IsBMP = file.type === "image/bmp";
				const ISJPEG = file.type === "image/jpg";
				const IsGIF = file.type === "image/gif";
				const isLt2M = file.size / 1024 / 1024 < 20;
				if (!isJPG && !IsPNG && !IsBMP && !ISJPEG && !IsGIF) {
					this.$message.error('上传头像图片格式不正确!');
					return false;
				}
				if (!isLt2M) {
					this.$message.error('上传头像图片大小不能超过 20MB!');
					return false;
				}
				return true;
			},
			//切换页码
			handleCurrentChange(index) {
				this.search_brand.pageIndex = index;
				this.Init();
			},
			handleSizeChange(pageSize) {
				this.search_brand.pageSize = pageSize;
				this.Init();
			},
			//修改状态
			changeState(id,state){
				this.request.put("/brand/"+id+"/"+state).then(res=>{
					if(res.code==200){
						this.addBrandData.isEnable=res.data;
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			}
		}
	}
</script>

<style scoped>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 60px;
		height: 60px;
		line-height: 60px;
		text-align: center;
	}

	.avatar {
		width: 60px;
		height: 60px;
		display: block;
	}
</style>
