<template>
	<div style="display: flex;flex-wrap:wrap;justify-content: start;align-items: center;">
		<div class="head" style="height: 50%;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);width: 100%;padding: 20px;">
			<h1 style="text-align: center;">添加库房</h1>
			<div style="width: 40%;margin: 0px auto;">
				<div style="display: flex;margin-top: 10px;">
					<div style="width: 150px;">库房名称：</div><el-input type="text" v-model="warehouse.houseName" clearable></el-input>
				</div>
				<div style="display: flex;margin-top: 10px;">
					<div style="width: 150px;">库区：</div>
					 <el-select v-model="value" clearable placeholder="请选择" style="width: 100%;">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				</div>
				<div style="display: flex;margin-top: 10px;">
					<div style="width: 150px;">备注：</div><el-input type="text" v-model="warehouse.remark" clearable></el-input>
				</div>
				<div style="margin-top: 10px;display: flex;">
					<div style="width: 150px;">是否启用：</div>
					<el-switch v-model="isEnable" :active-value="0" :inactive-value="1"
						active-color="#13ce66" inactive-color="#ff4949"
						>
					</el-switch>
				</div>
				<div style="margin: 10px auto;width: 50px;">
					<el-button type="primary" icon="el-icon-circle-plus-outline" @click="addWarehouse">添加</el-button>
				</div>
				
			</div>
		</div>
		<div class="" style="width: 100%;margin-top: 20px;">
			<el-table :data="myList" stripe style="width: 100%;" border highlight-current-row
				:header-cell-style="{color:'black'}" :row-style="{height:'10px'}" height="283px">
				<el-table-column prop="id" label="编号" align="center">
				</el-table-column>
				<el-table-column prop="houseName" label="库房名称" align="center">
				</el-table-column>
				<el-table-column prop="reservoir.reservoirName" label="库区名称" align="center">
				</el-table-column>
				<el-table-column label="是否启用" align="center">
					<template slot-scope="scope">
						<el-switch v-model="scope.row.isEnable" :active-value="0" :inactive-value="1"
							active-color="#13ce66" inactive-color="#ff4949"
							@change="changeState(scope.row.id,scope.row.isEnable)">
						</el-switch>
					</template>
				</el-table-column>
				<el-table-column prop="addTime" label="添加时间" align="center">
				</el-table-column>
				<el-table-column prop="remark" label="备注" align="center">
				</el-table-column>
				<el-table-column label="操作" align="center">
					<template slot-scope="scope">
						<el-popconfirm confirm-button-text='好的' cancel-button-text='不用了' icon="el-icon-info"
							icon-color="red" title="确认删除该数据吗？" @confirm="delData(scope.row.id)">
							<el-button type="danger" icon="el-icon-delete" slot="reference"
								style="padding:10px;font-size: 10px;margin-right: 10px;">
								删除
							</el-button>
						</el-popconfirm>
						<el-button type="primary" icon="el-icon-edit" @click="editData(scope.row.id)"
							style="padding:10px;font-size: 10px;">修改</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
		
		<!-- 弹窗 -->
		<el-dialog
		  title="修改信息"
		  :visible.sync="dialogVisible"
		  width="30%"
		  >
		  <div class="head" style="height: 50%;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);padding: 20px;">
		  	<div style="margin: 0px auto;">
		  		<div style="display: flex;margin-top: 10px;">
		  			<div style="width: 150px;">库房名称：</div><el-input type="text" v-model="editWarehouse.houseName" clearable></el-input>
		  		</div>
		  		<div style="display: flex;margin-top: 10px;">
		  			<div style="width: 150px;">库区：</div>
		  			 <el-select v-model="editWarehouse.reservoirId" clearable placeholder="请选择" style="width: 100%;">
		  			    <el-option
		  			      v-for="item in options"
		  			      :key="item.value"
		  			      :label="item.label"
		  			      :value="item.value">
		  			    </el-option>
		  			  </el-select>
		  		</div>
		  		<div style="display: flex;margin-top: 10px;">
		  			<div style="width: 150px;">备注：</div><el-input type="text" v-model="editWarehouse.remark" clearable></el-input>
		  		</div>
		  		<div style="margin-top: 10px;display: flex;">
		  			<div style="width: 150px;">是否启用：</div>
		  			<el-switch v-model="editWarehouse.isEnable" :active-value="0" :inactive-value="1"
		  				active-color="#13ce66" inactive-color="#ff4949"
		  				>
		  			</el-switch>
		  		</div>
		  	</div>
		  </div>
		  <span slot="footer" class="dialog-footer">
		    <el-button @click="dialogVisible = false">取 消</el-button>
		    <el-button type="primary" @click="updateWarehouse">确 定</el-button>
		  </span>
		</el-dialog>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				myList: [],
				isEnable: 0,
				options:[],
				value:'',
				warehouse:{},
				dialogVisible:false,
				editWarehouse:{
				},
				editIsEnable:0
			}
		},
		methods: {
			///确认修改
			updateWarehouse(){
				this.request.put("/warehouse",this.editWarehouse).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
						this.dialogVisible=false;
					}
					else{
						this.$message.error(res.msg);
					}
				})
				
			},
			//删除
			delData(id) {
				this.request.delete("/warehouse/"+id).then(res=>{
					if(res.code==200){
						this.Init();
						this.$message.success(res.msg);
					}else{
						this.$message.error(res.msg);
					}
				})
			},
			//修改信息
			editData(id) {
				
				this.dialogVisible=true;
				if(this.editWarehouse.houseName==""||this.editWarehouse.reservoirId==''||this.editWarehouse.remark==""){
					this.$message.error("请填写完整");
					return;
				}
				this.request.get("/warehouse/"+id).then(res=>{
					if(res.code==200){
						this.editWarehouse=res.data;
					}
				})
				
			},
			//添加
			addWarehouse(){
				this.warehouse.isEnable=this.isEnable;
				this.warehouse.reservoirId=this.value;
				if(this.warehouse.houseName==undefined||this.value==""||this.warehouse.remark==undefined){
					this.$message.error("请填写完整");
					return;
				}
				//发送请求
				this.request.post("/warehouse",this.warehouse).then(res=>{
					if(res.code==200){
						this.Init();
						this.warehouse={}
						this.$message.success("添加成功");
					}else{
						this.$message.error("添加失败");
					}
					
				});
			},
			//初始化
			Init() {
				this.request.get("/warehouse").then(res => {
					if (res.code == 200) {
						console.log(res.data);
						this.myList = res.data;
					}
				});
				
				this.request.get("/warehouse/reservory/state/0").then(res=>{
					if(res.code==200){
						this.options=[];
						console.log(res.data)
						let list=res.data;
						for (var i = 0; i < list.length; i++) {
							var obj={
								value:list[i].id,
								label:list[i].reservoirName,
								
							};
							this.options.push(obj);
						}
						
					}
				})
			},
			changeState(id, state) {
				var sta = state == 0 ? 0 : 1;
				//console.log(id+"===="+sta)
				this.request.get("/warehouse/" + id + "/" + sta).then(res => {
					if (res.code == 200) {
						this.$message.success(res.msg);
					} else {
						this.$message.error(res.msg)
					}
				})
			}
		},
		created() {
			this.Init();
		}
	}
</script>

<style>
</style>
