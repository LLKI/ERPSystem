<template>
	<div style="display: flex;">
		<div style="display: flex;width: 70%;flex-wrap: wrap;">
			<div v-for="(item,key) in myList" style="margin: 10px 10px 10px 0px;">
				<el-card :body-style="{ padding: '0px' }" style="width: 250px;">
					<img src="../../assets/img/仓库.webp" class="image" width="100%" height="150px">
					<div style="padding: 14px;">
						<div>
							<span class="el-icon-school" style="color: #909399;">仓库名称：</span>
							<span style="font-size: 14px;">{{key}}</span>
						</div>
						<div style="margin: 10px 0px;">
							<span class="el-icon-data-analysis" style="color: #909399;">现有物品数量：</span>
							<span style="color: #F56C6C;">{{item}}</span>
						</div>
						
						<!-- <div class="bottom clearfix">
							<time class="time"></time>
				 		<el-button type="text" class="button">操作按钮</el-button>
						</div> -->
					</div>
				</el-card>
			</div>
		</div>
		<div style="margin: auto 0px;">
			<h2 style="text-align: center;">商品分类数量</h2>
			<div style="margin-top: 100px;">
				<div id="main" style="width: 400px;height: 300px;">
					
				</div>
			</div>
			
		</div>
	</div>
</template>

<script>
	import * as echarts from 'echarts';
	export default {
		data() {
			return {
				myList: new Map()
			}
		},
		created() {
			this.Init();
		},
		mounted() {
			var chartDom = document.getElementById('main');
			var myChart = echarts.init(chartDom);
			var option;
			
			this.request.get("/proProfile").then(res=>{
				let list=[]
				if(res.code==200){
					for(var item in res.data){
						let obj={
							name:item,
							value:res.data[item]
						}
						list.push(obj);
					}
					option = {
					  tooltip: {
					    trigger: 'item'
					  },
					  legend: {
					    top: '5%',
					    left: 'center'
					  },
					  series: [
					    {
					      name: 'Access From',
					      type: 'pie',
					      radius: ['40%', '70%'],
					      avoidLabelOverlap: false,
					      itemStyle: {
					        borderRadius: 10,
					        borderColor: '#fff',
					        borderWidth: 2
					      },
					      label: {
					        show: false,
					        position: 'center'
					      },
					      emphasis: {
					        label: {
					          show: true,
					          fontSize: 40,
					          fontWeight: 'bold'
					        }
					      },
					      labelLine: {
					        show: false
					      },
					      data: list
					    }
					  ]
					};
					
					option && myChart.setOption(option);
					
					
				}
			})
		},
		methods: {
			Init() {
				this.request.get("/WarehouseInfo").then(res => {
					if (res.code == 200) {
						this.myList = res.data;
					}
				});
				
				
			}
		}
	}
</script>

<style>

</style>
