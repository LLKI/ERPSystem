<template>
	<div>
		<div class="head" style="display: flex;">
			<el-card class="box-card" style="flex: 1;margin-right: 10px;">
				<div
					style="color: #409EFF;margin-bottom: 10px;border-bottom: 1px solid #909399;line-height: 40px;text-align: center;">
					今日仓库总入库数量</div>
				<div style="display: flex;justify-content: space-between;">
					<span class="el-icon-shopping-cart-1" style="font-size: 25px;"></span>
					<span style="color: #F56C6C;font-size: 25px;">{{count[0]}}</span>
				</div>
			</el-card>
			<el-card class="box-card" style="flex: 1;margin-right: 10px;">
				<div
					style="color: #409EFF;margin-bottom: 10px;border-bottom: 1px solid #909399;line-height: 40px;text-align: center;">
					今日仓库总出库数量</div>
				<div style="display: flex;justify-content: space-between;">
					<span class="el-icon-truck" style="font-size: 25px;"></span>
					<span style="color: #F56C6C;font-size: 25px;">{{count[1]}}</span>
				</div>
			</el-card>
			<el-card class="box-card" style="flex: 1;margin-right: 10px;">
				<div
					style="color: #409EFF;margin-bottom: 10px;border-bottom: 1px solid #909399;line-height: 40px;text-align: center;">
					今日仓库总退货数量</div>
				<div style="display: flex;justify-content: space-between;">
					<span class="el-icon-truck" style="font-size: 25px;"></span>
					<span style="color: #F56C6C;font-size: 25px;">{{count[4]}}</span>
				</div>
			</el-card>
			<el-card class="box-card" style="flex: 1;margin-right: 10px;">
				<div
					style="color: #409EFF;margin-bottom: 10px;border-bottom: 1px solid #909399;line-height: 40px;text-align: center;">
					今日仓库总调拨数量</div>
				<div style="display: flex;justify-content: space-between;">
					<span class="el-icon-goods" style="font-size: 25px;"></span>
					<span style="color: #F56C6C;font-size: 25px;">{{count[2]}}</span>
				</div>
			</el-card>
			<el-card class="box-card" style="flex: 1;">
				<div
					style="color: #409EFF;margin-bottom: 10px;border-bottom: 1px solid #909399;line-height: 40px;text-align: center;">
					商品总数量</div>
				<div style="display: flex;justify-content: space-between;">
					<span class="el-icon-data-analysis" style="font-size: 25px;"></span>
					<span style="color: #F56C6C;font-size: 25px;">{{count[3]}}</span>
				</div>
			</el-card>
		</div>
		<div class="content" style="display: flex;height:400px;margin-top: 80px;">
			<div id="main" style="flex: 1;">
				
			</div>
			<div style="flex: 1;margin-left: 15px;" id="main2">
				
			</div>
		</div>
	</div>
</template>

<script>
	import * as echarts from 'echarts';
	export default {
		data() {
			return {
				list:[],
				count:[]
			}
		},
		mounted() {
			
				this.createOne();
				this.createTwo()
		},
		created() {
			this.Init();
			// list.forEach(function(value, key, list) {
			// 	console.log("Key:%s,Value:%s3333", key, value);
			// });

		},
		methods:{
			Init(){
				this.request.get("/warehouseInfo/count").then(res=>{
					if(res.code==200){
						this.count=res.data;
					}
				})
			},
		
			createOne(){
				let list = new Map();
				let myList=[];
				this.request.get("/WarehouseInfo").then(res => {
					if (res.code == 200) {
						list = res.data;
						for(var key in list){
							
							myList.push({
								value:list[key],
								name:key
							});
							option = {
								title: {
									text: '库存情况',
									subtext: '数据',
									left: 'center'
								},
								tooltip: {
									trigger: 'item'
								},
								legend: {
									orient: 'vertical',
									left: 'right'
								},
								series: [{
									name: '数量',
									type: 'pie',
									radius: '50%',
									data: myList,
									emphasis: {
										itemStyle: {
											shadowBlur: 10,
											shadowOffsetX: 0,
											shadowColor: 'rgba(0, 0, 0, 0.5)'
										}
									}
								}]
							};
							var chartDom = document.getElementById('main');
							var myChart = echarts.init(chartDom);
							option && myChart.setOption(option);
							
						}
					}
				})
				var option;
			},
			createTwo(){
				var chartDom = document.getElementById('main2');
				var myChart = echarts.init(chartDom);
				var option;
				
				let list=new Map();
				var myList=[]
				var title=[]
				this.request.get("/warehouseInfo/week").then(res=>{
					if(res.code==200){
						
						list=res.data;
						
						for(var item in list){
							title.push(item)
							let obj={
								name: item,
								type: 'line',
								stack: 'Total',
								areaStyle: {},
								emphasis: {
								  focus: 'series'
								},
								data:list[item]
							}
							myList.push(obj);
						}
						option = {
						  title: {
						    text: '数据'
						  },
						  tooltip: {
						    trigger: 'axis',
						    axisPointer: {
						      type: 'cross',
						      label: {
						        backgroundColor: '#6a7985'
						      }
						    }
						  },
						  legend: {
						    data: title
						  },
						  toolbox: {
						    feature: {
						      saveAsImage: {}
						    }
						  },
						  grid: {
						    left: '3%',
						    right: '4%',
						    bottom: '3%',
						    containLabel: true
						  },
						  xAxis: [
						    {
						      type: 'category',
						      boundaryGap: false,
						      data: ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
						    }
						  ],
						  yAxis: [
						    {
						      type: 'value'
						    }
						  ],
						  series: myList
						};
						
						option && myChart.setOption(option);
					}
				})
				
				

			}
		}
	}
	/**
	 * [
				    {
				      name: 'Email',
				      type: 'line',
				      stack: 'Total',
				      areaStyle: {},
				      emphasis: {
				        focus: 'series'
				      },
				      data: [120, 132, 101, 134, 90, 230, 210]
				    },
				    {
				      name: 'Union Ads',
				      type: 'line',
				      stack: 'Total',
				      areaStyle: {},
				      emphasis: {
				        focus: 'series'
				      },
				      data: [220, 182, 191, 234, 290, 330, 310]
				    },
				    {
				      name: 'Video Ads',
				      type: 'line',
				      stack: 'Total',
				      areaStyle: {},
				      emphasis: {
				        focus: 'series'
				      },
				      data: [150, 232, 201, 154, 190, 330, 410]
				    },
				    {
				      name: 'Direct',
				      type: 'line',
				      stack: 'Total',
				      areaStyle: {},
				      emphasis: {
				        focus: 'series'
				      },
				      data: [320, 332, 301, 334, 390, 330, 320]
				    },
				    {
				      name: 'Search Engine',
				      type: 'line',
				      stack: 'Total',
				      label: {
				        show: true,
				        position: 'top'
				      },
				      areaStyle: {},
				      emphasis: {
				        focus: 'series'
				      },
				      data: [820, 932, 901, 934, 1290, 1330, 1320]
				    }
				  ]
	 */
</script>

<style>
</style>
