﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class GetWeek
    {
        /// <summary>
        /// 获取本周的日期
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public static DateTime WeekStartTime(int i)
        {
            DateTime dt = DateTime.Now;
            //星期一
            //int dayOfWeek = -1 * (int)dt.Date.DayOfWeek;

            int dayOfWeek = -1 * (int)dt.Date.DayOfWeek;
            //Sunday = 0,Monday = 1,Tuesday = 2,Wednesday = 3,Thursday = 4,Friday = 5,Saturday = 6,

            DateTime weekStartTime = dt.AddDays(dayOfWeek + i);//取本周一
            if (dayOfWeek == 0) //如果今天是周日，则开始时间是上周一
            {
                weekStartTime = weekStartTime.AddDays(-7);
            }
            return weekStartTime.Date;

        }
    }
}
