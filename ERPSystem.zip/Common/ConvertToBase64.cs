﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Common
{
    public class ConvertToBase64
    {
        /// <summary>
        /// 将图片转换为字节
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string ToBase64(string url)
        {
            FileStream fs = File.OpenRead(url); //OpenRead
            int filelength = 0;
            filelength = (int)fs.Length; //获得文件长度 
            Byte[] image = new Byte[filelength]; //建立一个字节数组 
            fs.Read(image, 0, filelength); //按字节流读取 
            //System.Drawing.Image result = System.Drawing.Image.FromStream(fs);
            fs.Close();
            return Convert.ToBase64String(image);
        }
    }
}
