﻿using AlibabaCloud.SDK.Dysmsapi20170525.Models;
using AlibabaCloud.SDK.Dysmsapi20170525;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Tea;
using Tea.Utils;
using System.Net;
using System.Net.Http;
using Microsoft.EntityFrameworkCore.Internal;
using System.Text.RegularExpressions;
using common;
using System.Threading.Tasks;

namespace Common
{
    public class SendCode
    {
        public static async Task<ApiResult> SendCodeNum(string phone,string codeNum)
        {
            string code = "";
            Client client = CreateClient("LTAI5tM1JGMLb14Z7kVzXnXS", "c1TUMFzoD0pMmJ9UFhq0irYDpe2ONe");
            SendSmsRequest sendSmsRequest = new SendSmsRequest
            {
                PhoneNumbers = phone,
                SignName = "仓库管理",
                TemplateCode = "SMS_266935564",
                TemplateParam = "{\"code\":" + codeNum + "}"
            };
            AlibabaCloud.TeaUtil.Models.RuntimeOptions runtime = new AlibabaCloud.TeaUtil.Models.RuntimeOptions();
            try
            {
                SendSmsResponse sendSmsResponse = client.SendSms(sendSmsRequest);
                Debug.WriteLine(code = sendSmsResponse.Body.Code);
                Debug.WriteLine(sendSmsResponse.Body.Message);
                //判断是否发送成功
                if (code != "OK")
                {
                    await LogHelper.Error(phone + "=====>发送的验证码次数过多,错误消息："+ sendSmsResponse.Body.Message);
                    return ApiResult.Error("您发送的验证码次数过多，请明天再来发送:" + sendSmsResponse.Body.Message);
                }
                    
                //Debug.WriteLine("response返回的Code：" + code);
                //Debug.WriteLine("response返回的参数：" + JsonConvert.SerializeObject(sendSmsResponse.Body));
            }
            catch (Exception e)
            {
                await LogHelper.Error(phone + "=====>发送验证码失败");
                return ApiResult.Error("验证码发送失败：" + e.Message);
                //Debug.WriteLine("response的错误参数：" + e.StackTrace);
            }
            try
            {
                // 复制代码运行请自行打印 API 的返回值
                client.SendSmsWithOptions(sendSmsRequest, runtime);
            }
            catch (TeaException error)
            {
                // 如有需要，请打印 error
                string v = AlibabaCloud.TeaUtil.Common.AssertAsString(error.Message);
                await LogHelper.Error(phone + "=====>验证码发送失败，错误消息为：" + v+"====>位置在："+error.StackTrace);
                return ApiResult.Error("验证码发送失败：" + v);
                //Debug.WriteLine("错误消息：" + v);
            }
            catch (Exception _error)
            {
                TeaException error = new TeaException(new Dictionary<string, object>
                {
                    { "message", _error.Message }
                });
                // 如有需要，请打印 error
                string v = AlibabaCloud.TeaUtil.Common.AssertAsString(error.Message);
                await LogHelper.Error(phone + "=====>验证码发送失败，错误消息为：" + v + "====>位置在：" + error.StackTrace);
                return ApiResult.Error("验证码发送失败：" + v);
            }
            //UUser uUser = _schoolContext.UUser.SingleOrDefault(s => s.Phone == phone && s.IsDelete == 0);
            //if (uUser == null)
            //    return ApiResult.error((int)StateCode.PARAMERO, "该手机号暂未注册");
            //else
            //{
            //    UserReturn user = new UserReturn()
            //    {
            //        Account = uUser.Account,
            //        Phone = uUser.Phone,
            //        NickName = uUser.NickName,
            //        Img = uUser.Img,
            //        Code = codeNum
            //    };
            //    string userReturn = JsonConvert.SerializeObject(user);
            //    //将对象存入redis
            //    rc.Set("user", Encoding.UTF8.GetBytes(userReturn), new DistributedCacheEntryOptions().SetSlidingExpiration(TimeSpan.FromSeconds(60)));
            //    //rc.SetString("user", userReturn);
            //    //httpContext.HttpContext.Session.Set("user", Encoding.UTF8.GetBytes(userReturn));
            //}
            return ApiResult.Success("验证码发送成功",codeNum);
            //将接收到的code返回到前台
        }


        /// <summary>
        /// 发送验证码的配置类
        /// </summary>
        /// <param name="accessKeyId"></param>
        /// <param name="accessKeySecret"></param>
        /// <returns></returns>
        private static Client CreateClient(string accessKeyId, string accessKeySecret)
        {
            AlibabaCloud.OpenApiClient.Models.Config config = new AlibabaCloud.OpenApiClient.Models.Config
            {
                // 必填，您的 AccessKey ID
                AccessKeyId = accessKeyId,
                // 必填，您的 AccessKey Secret
                AccessKeySecret = accessKeySecret,
            };
            // 访问的域名
            config.Endpoint = "dysmsapi.aliyuncs.com";
            return new Client(config);
        }
    }
}
