﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class ApiResult
    {

        public  object Data { get; set; }
        public int Code { get; set; }
        public string Msg { get; set; }
        /// <summary>
        /// 成功 带数据
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static ApiResult Success(object data)
        {
            return new ApiResult() {Code=StateCode.CODE_200(), Data=data,Msg="成功"};
        }
        /// <summary>
        /// 成功 带消息
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static ApiResult Success(string msg)
        {
            return new ApiResult { Code = StateCode.CODE_200(), Data = null, Msg = msg };
        }
        /// <summary>
        /// 成功 带消息以及数据
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static ApiResult Success(string msg,object data)
        {
            return new ApiResult { Code=StateCode.CODE_200(),Data=data, Msg=msg};
        }
        /// <summary>
        /// 成功 不带任何参数
        /// </summary>
        /// <returns></returns>
        public static ApiResult Success()
        {
            return new ApiResult { Code = StateCode.CODE_200(), Data = null, Msg = "成功" };
        }
        /// <summary>
        /// 失败 不带任何参数
        /// </summary>
        /// <returns></returns>
        public static ApiResult Error()
        {
            return new ApiResult { Code = StateCode.CODE_500(), Data = null, Msg = "失败" };
        }
        /// <summary>
        /// 失败 带消息
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static ApiResult Error(string msg)
        {
            return new ApiResult { Code = StateCode.CODE_500(), Data = null, Msg = msg };
        }
        /// <summary>
        /// 失败 带消息以及状态码
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public static ApiResult Error(string msg,int code)
        {
            return new ApiResult { Code = code, Data = null, Msg = msg };
        }
        /// <summary>
        /// 失败 带状态码
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static ApiResult Error(int code)
        {
            return new ApiResult { Code = code, Data = null, Msg = "失败" };
        }
        /// <summary>
        /// 失败 带数据
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static ApiResult Error(object data)
        {
            return new ApiResult { Code = StateCode.CODE_500(), Data = data, Msg = "失败" };
        }
    }
}
