﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class GetCode
    {
        /// <summary>
        /// 获取验证码
        /// </summary>
        /// <param name="length">验证码的长度</param>
        /// <returns></returns>
        public static string GetValidateCode(int length)
        {
            string code = "";
            Random random = new Random();
            for (int i = 0; i < length; i++)
            {
                code+=random.Next(0, 9);
            }
            return code;
        }
    }
}
