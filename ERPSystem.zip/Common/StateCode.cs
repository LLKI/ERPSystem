﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class StateCode
    {
        private enum stateCode
        {
            /// <summary>
            /// 成功
            /// </summary>
            CODE_200=200,
            /// <summary>
            /// 参数有误
            /// </summary>
            CODE_401=401,
            CODE_402=402,
            /// <summary>
            /// 权限不足
            /// </summary>
            CODE_403=403,
            /// <summary>
            /// 找不到页面
            /// </summary>
            CODE_404=404,
            CODE_405=405,
            /// <summary>
            /// 系统错误
            /// </summary>
            CODE_500=500,
        }
        /// <summary>
        /// 成功
        /// </summary>
        /// <returns></returns>
        public static int CODE_200()
        {
            return Convert.ToInt32(stateCode.CODE_200);
        }
        /// <summary>
        /// 系统错误
        /// </summary>
        /// <returns></returns>
        public static int CODE_500()
        {
            return Convert.ToInt32(stateCode.CODE_500);
        }
    }
}
