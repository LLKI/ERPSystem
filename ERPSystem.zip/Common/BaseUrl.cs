﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Text;

namespace Common
{
    public class BaseUrl
    {
        /// <summary>
        /// 用户发布公告的图片的url
        /// </summary>
        public static readonly string NotifyImgUrl = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\notifyImg\\";
        /// <summary>
        /// 存放人脸的路径
        /// </summary>
        public static readonly string FaceImgUrl = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\faceImg\\";
        /// <summary>
        /// log4net的配置文件
        /// </summary>
        public  const string Log4NETConfig = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\config\\log4net.config";
        /// <summary>
        /// 存放账号图片的url
        /// </summary>
        public static readonly string AccountImgPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\accountImg\\";
        /// <summary>
        /// 账号图片的路径（对外访问）
        /// </summary>
        public static readonly string AccountImgUrl = "http://localhost:5000/files/accountImg/";
        /// <summary>
        /// 商品品牌的图片的路径
        /// </summary>
        public static readonly string BrandImgPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\brandImg\\";
        /// <summary>
        /// 商品品牌的图片的url(对外访问)
        /// </summary>
        public static readonly string BrandImgUrl = "http://localhost:5000/files/brandImg/";

        /// <summary>
        /// 存放供应商表格的路径
        /// </summary>
        public static readonly string SupplierExcelPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\supplierExcel\\";

        /// <summary>
        /// 存放供应商表格的路径(对外)
        /// </summary>
        public static readonly string SupplierExcelUrl = "http://localhost:5000/files/supplier/";


        /// <summary>
        /// 存放商品图片的路径
        /// </summary>
        public static readonly string ProductImgPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\productImg\\";

        /// <summary>
        /// 存放商品图片的url(对外访问)
        /// </summary>
        public static readonly string ProductImgUrl = "http://localhost:5000/files/productImg/";

        /// <summary>
        /// 存放日志文件的路径
        /// </summary>
        public static readonly string LogFilePath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\ERPWeb\\bin\\Debug\\netcoreapp3.1\\Log\\";

        /// <summary>
        /// 存放日志pdf的文件路径
        /// </summary>
        public static readonly string LogPdfErrorPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\logPdf\\error\\";

        public static readonly string LogPdfDebugPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\logPdf\\debug\\";

        public static readonly string LogPdfPath = "D:\\ERP仓库管理\\项目代码\\后台API\\ERPSystem\\files\\logPdf\\";
        /// <summary>
        /// 存放日志文件的文件url(对外访问)
        /// </summary>
        public static readonly string LogPdfUrl = "http://localhost:5000/files/logPdf/";
    }
}
