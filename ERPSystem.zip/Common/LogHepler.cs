﻿using Common;
using log4net;
using log4net.Config;
using log4net.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace common
{
    public class LogHelper
    {

        public static ILoggerRepository repository { get; set; }
        private static ILog _log;
        private static ILog log
        {
            get
            {
                if (_log == null)
                {
                    
                    Configure();
                }
                return _log;
            }
        }
        public static void Configure(string repositoryName = "NETCoreRepository", string configFile = BaseUrl.Log4NETConfig)
        {
            repository = LogManager.CreateRepository(repositoryName);
            XmlConfigurator.Configure(repository, new FileInfo(configFile));
            BasicConfigurator.Configure(repository);
            _log = LogManager.GetLogger(repository.Name, typeof(LogHelper));
        }

        /// <summary>
        /// 一般级别信息
        /// </summary>
        /// <returns></returns>
        public static Task<string> Info(string msg)
        {
            log.Info(msg);
            return Task.FromResult("成功了");
        }
        /// <summary>
        /// 调试级别
        /// </summary>
        /// <param name="msg">信息</param>
        /// <returns></returns>
        public static Task Debug(string msg)
        {
            log.Debug(msg);
            return Task.FromResult(0);
        }
        /// <summary>
        /// 调试级别
        /// </summary>
        /// <param name="msg">信息</param>
        /// <param name="e">错误消息</param>
        /// <returns></returns>
        public static Task Debug(string msg, Exception e)
        {
            log.Debug(msg, e);
            return Task.FromResult(0);
        }
        /// <summary>
        /// 错误级别
        /// </summary>
        /// <param name="msg">信息</param>
        /// <returns></returns>
        public static Task Error(string msg)
        {
            log.Error(msg);
            return Task.FromResult(0);
        }
        /// <summary>
        /// 错误级别
        /// </summary>
        /// <param name="msg">信息</param>
        /// <param name="e">错误消息</param>
        /// <returns></returns>
        public static Task Error(string msg, Exception e)
        {
            log.Error(msg, e);
            return Task.FromResult(0);
        }
        /// <summary>
        /// 严重错误级别
        /// </summary>
        /// <param name="msg">信息</param>
        /// <returns></returns>
        public static Task Fatal(string msg)
        {
            log.Fatal(msg);
            return Task.FromResult(0);
        }
        /// <summary>
        /// 严重错误级别
        /// </summary>
        /// <param name="msg">信息</param>
        /// <param name="e">错误消息</param>
        /// <returns></returns>
        public static Task Fatal(string msg, Exception e)
        {
            log.Fatal(msg);
            return Task.FromResult(0);
        }
    }
}
