﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Caching.Redis;
using Microsoft.Extensions.Options;
using Models.Dto;
using Models.json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class RedisHelper
    {
        //private static RedisCache rc;
      //  private IOptions<RedisConfig> options;//从配置文案读取
        public static RedisHelper RedisHelperInstance;
        //IOptions<RedisConfig> options
        private IDistributedCache rc;
        public RedisHelper(IDistributedCache rc)
        {
            this.rc = rc;
            //RedisHelperInstance = new RedisHelper();
            ////this.options = options;
            ////初始化redis对象的配置对象
            //RedisCacheOptions option = new RedisCacheOptions();
            ////配置连接的地址
            //option.Configuration = this.options.Value.Con;
            ////配置redis对象的别称
            //option.InstanceName = this.options.Value.Name;
            ////往redis对象传入配置对象
            //rc = new RedisCache(option);
        }
        //public static RedisHelper GetRedisHelper()
        //{
        //    if (RedisHelperInstance == null)
        //    {
        //        RedisHelperInstance = new RedisHelper();
        //        ////this.options = options;
        //        ////初始化redis对象的配置对象
        //        //RedisCacheOptions option = new RedisCacheOptions();
        //        ////配置连接的地址
        //        //option.Configuration = "127.0.0.1:6379,password=";
        //        ////配置redis对象的别称
        //        //option.InstanceName = "ERPDB";
        //        ////往redis对象传入配置对象
        //        //rc = new RedisCache(option);
        //        return RedisHelperInstance;
        //    }
        //    else
        //    {
        //        return RedisHelperInstance;
        //    }
        //}
        /// <summary>
        /// 存数据
        /// </summary>
        /// <param name="key">存入数据的标识</param>
        /// <param name="value">存入的数据</param>
        /// <param name="time">过期时间，时间戳</param>
        public async Task SetValueAsync(string key, string value, TimeSpan time)
        {
            await rc.SetAsync(key, Encoding.UTF8.GetBytes(value), new DistributedCacheEntryOptions().SetAbsoluteExpiration(time));
        }
        /// <summary>
        /// 取数据
        /// </summary>
        /// <param name="key">存入数据的键</param>
        public async Task<byte[]> GetValueAsync(string key)
        {
            return await rc.GetAsync(key);
        }
        /// <summary>
        /// 移除数据
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task RemoveAsync(string key)
        {
            await rc.RemoveAsync(key);
        }
    }
}
