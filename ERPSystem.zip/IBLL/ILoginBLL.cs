﻿using System;
using System.Collections.Generic;
using System.Text;
using Models;
using Common;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace IBLL
{
    public  interface ILoginBLL
    {

        Task<ApiResult> LoginByAccount(string account,string pwd);


        
    }
}
