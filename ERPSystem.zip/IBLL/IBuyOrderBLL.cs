﻿using Common;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IBuyOrderBLL
    {
        Task AddOrder(string cartId,decimal price,int userId);

        Task<ApiResult> GetAllOrder(BuyOrderDTO order);

        Task<ApiResult> GetProsByCatId(string catId);

        Task<ApiResult> UpdateStateById(OrderStateDTO order);

        Task<ApiResult> UpdateStateToNoById(OrderStateDTO order);

        Task<ApiResult> UndoOrder(OrderStateDTO order);


        Task<ApiResult> DelOrderById(OrderStateDTO order);
    }
}
