﻿using Common;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IRolesBLL
    {
        Task<ApiResult> GetRoleById(int userId);

        Task<ApiResult> GetRoles();

        Task<Roles> GetRoleByName(string roleName);

        Task<ApiResult> GetMenuByRoleId(int id);

        Task<ApiResult> UpdateRole(RoleDTO role);

        Task<ApiResult> AddRole(RoleDTO role);

        Task<ApiResult> DelRoleByid(int id);
    }
}
