﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Common;
using Microsoft.AspNetCore.Http;
using Models;
using Models.Dto;
using Models.models;

namespace IBLL
{
    public interface  INotifyBLL
    {
        ApiResult GetAllType();
        Task<ApiResult> GetAllContent(int userId);
        ApiResult GetContentById(int id);
        Task<ApiResult> AddNotify(Notice notice);
        Task<ApiResult> Upload(IFormFileCollection files);
        ApiResult GetMyNotifys(PageParams param);
        Task<ApiResult> GetNotifyNum(int id);
        ApiResult GetNotifyTypeByName(string typeName);
        ApiResult GetNotifyTypeByid(int id);
        Task<ApiResult> UpdateNotifyById(int id,Notice notice);
        Task<ApiResult> DeleteNotifyById(int id);
        Task<ApiResult> GetNotifyTypeById(int id);
        Task<ApiResult> GetCount(int id);
        Task<ApiResult> DelNotifyTypeById(int id);
        Task<ApiResult> DelMyNotifyBatch(int[] ids);
        Task<ApiResult> UpdateNotifyType(NoticeType type);
    }
}
