﻿using Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IWarehouseInfoBLL
    {
        Task<ApiResult> GetInfo();

        Task<ApiResult> GetCount();

        Task<ApiResult> GetWeekInfo();
    }
}
