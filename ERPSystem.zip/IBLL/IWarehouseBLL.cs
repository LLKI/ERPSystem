﻿using Common;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    //仓库管理
    public interface IWarehouseBLL
    {
        Task<ApiResult> GetAllWareHouse();

        Task<ApiResult> UpdateStateById(int id,int state);

        Task<ApiResult> GetAllReservorys(int state);

        Task<ApiResult> AddWarehouse(Warehouse warehouse);

        Task<ApiResult> GetWarehouseById(int id);

        Task<ApiResult> UpdateWarehouse(Warehouse warehouse);

        Task<ApiResult> DelWarehouseById(int id);

        Task<ApiResult> GetReservoirsById(int resId);

        Task<ApiResult> GetAllReservorys();
    }
}
