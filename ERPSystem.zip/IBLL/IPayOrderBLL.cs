﻿using Common;
using Models.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IPayOrderBLL
    {
        Task<ApiResult> GetAllOrder(PayOrderDTO order);


        bool UpdateState(string proNo, int userId);


        Task<ApiResult> GetProById(int orderId);

        Task<ApiResult> CancelOrder(PayOrderParamDTO pay);

        Task<ApiResult> DelOrderById(PayOrderParamDTO pay);

    }
}
