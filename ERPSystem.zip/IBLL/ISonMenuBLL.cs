﻿using Common;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface ISonMenuBLL
    {
        Task<ApiResult> GetSonMenuById(int id);

        Task<ApiResult> UpdateMenu(SonMenu menu);

        Task<ApiResult> AddSonMenu(SonMenu menu);

        Task<ApiResult> DelMenuById(int id);
    }
}
