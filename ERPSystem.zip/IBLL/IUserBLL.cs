﻿using Common;
using Microsoft.AspNetCore.Http;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    /// <summary>
    /// 用户操作接口
    /// </summary>
    public interface IUserBLL
    {
        Task<UserInfo> GetUserById(int id);

        Task<ApiResult> GetUserByKey(string key);

        Task<ApiResult> UpdateUserById(UserInfo user);

        Task<ApiResult> UpdateUserAccountImgById(string account, IFormFileCollection file);

        Task<ApiResult> UpdatePwd(int id,string oldPwd,string newPwd);



        Task<ApiResult> SendCodeByUpdatePhone(string phone, string oldPhone);

        Task<ApiResult> UpdatePhone(int id, string newPhone,string codeNum);


        Task<ApiResult> UplaodUserImg(int id,IFormFileCollection file);
    }
}
