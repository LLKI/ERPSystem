﻿using Common;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface ICartBLL
    {

        void AddCart(ProCat cat);
    }
}
