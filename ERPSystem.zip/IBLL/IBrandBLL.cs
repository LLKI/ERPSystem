﻿using Common;
using Microsoft.AspNetCore.Http;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IBrandBLL
    {
        Task<ApiResult> GetAllBrands(BrandDTO bra);

        Task<ApiResult> UploadBrandImg(Brand brand, IFormFileCollection file);

        Task<ApiResult> DeleteBrandById(int id);

        Task<ApiResult> GetBrandById(int id);

        Task<ApiResult> UpdateBrand(Brand brand);

        Task<ApiResult> UpdateState(int id, int state);

        Task<ApiResult> GetAllBrands();

        Task<int> GetBrandIdByName(string text);
    }
}
