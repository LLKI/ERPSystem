﻿using Common;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface ISupplierBLL
    {
        Task<ApiResult> GetAllSuppliers(SupplierDTO sup);

        Task<ApiResult> ExportSupplier(SupplierDTO sup);

        Task<ApiResult> DeleteSupplierById(int id);

        Task<ApiResult> AddSupplier(Supplier sup);

        Task<ApiResult> GetSupplierById(int id);

        Task<ApiResult> UpdateSupplier(Supplier sup);

        Task<ApiResult> UpdateState(int id, int state);

        Task<ApiResult> GetAllSuppliers();

        Task<int> GetSupplierIdByName(string name);
    }
}
