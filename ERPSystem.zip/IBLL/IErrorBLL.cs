﻿using Common;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IErrorBLL
    {
        Task<bool> AddErrorData();
        Task<ApiResult> GetErrorCount();
        Task<int> GetAllCount();
    }
}
