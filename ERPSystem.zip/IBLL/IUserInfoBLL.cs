﻿using Common;
using Microsoft.AspNetCore.Http;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IUserInfoBLL
    {
        Task<ApiResult> ResetPwd(int id);

        Task<ApiResult> GetUserInfoById(int id);

        Task<ApiResult> DelUserById(int id);

        Task<ApiResult> ExportExcel(UserSearchDTO user);

        Task<ApiResult> ImportExcel(UserDTO user,IFormFileCollection file);
	Task<ApiResult> GetAllUserInfo(UserSearchDTO user);
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        Task<ApiResult> Add(UserInfo userInfo);
    }
}
