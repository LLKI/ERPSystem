﻿using Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface ILogBLL
    {
        ApiResult GetAllLogFile();

        ApiResult GetChildernFile(string name);
    }
}
