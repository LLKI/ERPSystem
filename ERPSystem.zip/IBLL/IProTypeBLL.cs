﻿using Common;
using Models.models;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IProTypeBLL
    {
        Task<ApiResult> GetAllProTypes();

        Task<ApiResult> AddProType(ProType pro);

        Task<ApiResult> UpdateProTypeState(int id, int state);

        Task<ApiResult> DelProType(int id);

        Task<ApiResult> GetProTypeById(int id);

        Task<ApiResult> UpdateProType(int id, ProType pro);
    }
}
