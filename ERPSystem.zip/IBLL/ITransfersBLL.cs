﻿using Common;
using Models.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface ITransfersBLL
    {
        Task<ApiResult> GetAllOrder(TransfersOrderDTO order);

        Task<ApiResult> LookDetail(string proNo);

        Task<ApiResult> AuditOrder(AuditOrderDTO audit);

        Task<ApiResult> DelOrderById(int id, int userId);
    }
}
