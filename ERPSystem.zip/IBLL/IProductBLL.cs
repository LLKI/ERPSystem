﻿using Common;
using Microsoft.AspNetCore.Http;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IProductBLL
    {
        Task<ApiResult> GetAllProducts(ProductDTO pro);

        Task<ApiResult> GetProductById(int id);

        Task<ApiResult> AddProduct(Product pro);

        Task<ApiResult> UpdateState(int id, int state);

        Task<ApiResult> ExportData(ProductDTO pro);
        Task<ApiResult> GetProducts(int isAudio);

        Task<ApiResult> ImportData(IFormFileCollection file,UserDTO userId);

        Task<ApiResult> AddProduct(Product pro, IFormFileCollection file);

        Task<ApiResult> BackPro(BackProDTO back);

        Task<ApiResult> UpdateProNoImg(Product pro);

        Task<ApiResult> UpdateProHasImg(Temp pro,IFormFileCollection file);

        Task<ApiResult> DelProById(int id);

        Task<ApiResult> GetProByIds(ProDTO ids);

        Task<ApiResult> TransfersPro(TransfersDTO tra);
        Task<ApiResult> OutPro(OutProDTO pro);
    }
}
