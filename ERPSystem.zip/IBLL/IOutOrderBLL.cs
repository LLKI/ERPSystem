﻿using Common;
using Models.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IOutOrderBLL
    {
        Task<ApiResult> GetAllOrder(OutOrderDTO order);

        Task<ApiResult> LookDetail(string proNo);

        Task<ApiResult> AuditOrder(AuditOrderDTO audit);

        Task<ApiResult> DelOrderById(int id, int userId);
    }
}
