﻿using Common;
using Models.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IFeedback
    {

        Task<ApiResult> GetAllData(FeedbackDTO feed);

        Task<ApiResult> UpdateState(int id, int isSolve);

        Task<ApiResult> DelData(int id);

    }
}
