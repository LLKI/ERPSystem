﻿using Common;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IReservoirBLL
    {
         Task<ApiResult> GetAllReservoirs();

        Task<ApiResult> UpdateStateById(int id,int state);

        Task<ApiResult> AddReservoir(Reservoir res);


        Task<ApiResult> DeleteReservoir(int id);


        Task<ApiResult> UpdateReservoir(Reservoir res);

        Task<ApiResult> GetDataById(int id);
    }
}
