﻿using Common;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IBLL
{
    public interface IMenuBLL
    {
        Task<ApiResult> GetMenu(int userId);

        Task<ApiResult> GetMenus();

        Task<ApiResult> GetMenuById(int id);

        Task<ApiResult> UpdateMenu(Menu menu);

        Task<ApiResult> GetSonMenuById(int id);

        Task<ApiResult> AddMenu(MenuDTO menu);
	Task<ApiResult> DeleteMenu(int id);
    }
}
