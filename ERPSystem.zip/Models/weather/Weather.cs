﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.weather
{
    public class Weather
    {
        public Info Info { get; set; }
        public string city { get; set; }
    }
}
