﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.weather
{
    public class Info
    {
        public string Type { get; set; }
        public string High { get; set; }
        public string tip { get; set; }
    }
}
