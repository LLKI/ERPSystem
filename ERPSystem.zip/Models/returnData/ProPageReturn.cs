﻿using Models.models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.returnData
{
    public class ProPageReturn
    {
        public int Total { get; set; }
        public List<Product> Products { get; set; }
    }
}
