﻿using Models.models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.returnData
{
    public class UserInfoReturn
    {
        public List<UserInfo> MyList { get; set; }
        public int Total { get; set; }
    }
}
