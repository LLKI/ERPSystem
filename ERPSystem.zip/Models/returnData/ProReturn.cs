﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.returnData
{
    public class ProReturn
    {
        public string ProName { get; set; }
        public decimal CostPrice { get; set; }
        public decimal Price { get; set; }
        public string Stock { get; set; }
        public string Address { get; set; }
        public string ProType { get; set; }
        public int IsAudio { get; set; }
        public string AddPerson { get; set; }
        public DateTime AddTime { get; set; }
    }
}
