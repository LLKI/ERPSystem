﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class MenuDTO
    {
        public int[] Ids { get; set; }
        public string Icon { get; set; }
        public string? Remark { get; set; }
        public string MenuName { get; set; }
    }
}
