﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class BuyOrderDTO
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int Total { get; set; }
        public string Audio { get; set; }
        public string OrderNo { get; set; }
        public string IsBack { get; set; }//是否撤销 
        public int UserId { get; set; }
    }
}
