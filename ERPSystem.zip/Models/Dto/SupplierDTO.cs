﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class SupplierDTO
    {
        public string SupplierName { get; set; }
        public string Phone { get; set; }
        public string IsEnable { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int Total { get; set; }
    }
}
