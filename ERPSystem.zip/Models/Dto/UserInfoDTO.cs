﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class UserInfoDTO
    {
        public int Id { get; set; }
        public string Account { get; set; }
        public string Img { get; set; }
        public string Phone { get; set; }
        public string NickName { get; set; }
    }
}
