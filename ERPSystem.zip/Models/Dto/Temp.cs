﻿using Models.models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class Temp
    {
        public int Id { get; set; }
        public string ProName { get; set; }
        public string Color { get; set; }
        public int BrandId { get; set; }
        public decimal CostPrice { get; set; }
        public decimal Price { get; set; }
        public decimal ProWeight { get; set; }
        public decimal Size { get; set; }
        public string Material { get; set; }
        public string Stock { get; set; }
        public string ProImg { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public string Remark { get; set; }
        public int IsEnough { get; set; }
        public int SupplierId { get; set; }
        public int ReservoirId { get; set; }
        public string AddPerson { get; set; }
        public int IsBackPro { get; set; }
        public int IsAudio { get; set; }
        public string CatId { get; set; }
        public string Address { get; set; }
        public string ProType { get; set; }
        public string BackOrderId { get; set; }
    }
}
