﻿using Models.returnData;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class AuditOrderDTO
    {
        public int Id { get; set; }
        public int[] Ids { get; set; }
        public int UserId { get; set; }
        //public int MyProperty { get; set; }
        public string Remark { get; set; }
        public int State { get; set; }
    }
}
