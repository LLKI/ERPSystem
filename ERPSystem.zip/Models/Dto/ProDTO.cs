﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class ProDTO
    {
        public int[] Ids { get; set; }
    }
}
