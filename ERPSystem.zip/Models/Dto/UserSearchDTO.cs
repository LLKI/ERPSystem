﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Models.Dto
{
    public class UserSearchDTO
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int Total { get; set; }
        public string UserName { get; set; }
        public string UserAccount { get; set; }

        public string Phone { get; set; }
        [DefaultValue(0)]
        public int DepartmentId { get; set; }
        [DefaultValue(0)]
        public int RoleId { get; set; }
    }
}
