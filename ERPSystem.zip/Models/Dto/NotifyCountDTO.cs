﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class NotifyCountDTO
    {
        public int DayCount { get; set; }
        public int WeekCount { get; set; }
        public int userCount { get; set; }
        public int TotalCount { get; set; }
    }
}
