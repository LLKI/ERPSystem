﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class PayOrderParamDTO
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Remark { get; set; }
        public int[] Ids { get; set; }
    }
}
