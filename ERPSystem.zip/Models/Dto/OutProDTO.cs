﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class OutProDTO
    {
        public int[] Ids { get; set; }
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Remark { get; set; }
        public int BackNum { get; set; }
        public int[] BackNums { get; set; }
        public string[] GotoAddresses { get; set; }
        public string GotoAddress { get; set; }
    }
}
