﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class ProductDTO
    {

        public int Id { get; set; }
        public int PageIndex { get; set; }
        public int Total { get; set; }
        public string ProName { get; set; }
        public int PageSize { get; set; }
        public string IsAudio { get; set; }
        public string IsEnable { get; set; }
        public string AddPerson { get; set; }
    }
}
