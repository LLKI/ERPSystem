﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class UserAccountImg
    {
        public int Id { get; set; }
    }
}
