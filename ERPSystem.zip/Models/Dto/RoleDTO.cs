﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class RoleDTO
    {
        public int Id { get; set; }
        public int[] MenuIds { get; set; }
        public string RoleName { get; set; }
        public string Sign { get; set; }
    }
}
