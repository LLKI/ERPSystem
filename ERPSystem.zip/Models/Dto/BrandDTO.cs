﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class BrandDTO
    {
        public string BrandName { get; set; }
        public string Type { get; set; }
        public string IsEnable { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int Total { get; set; }
    }
}
