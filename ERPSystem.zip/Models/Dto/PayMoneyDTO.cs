﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class PayMoneyDTO
    {
        public string ProNo { get; set; }
        public string Money { get; set; }
        public int UserId { get; set; }
    }
}
