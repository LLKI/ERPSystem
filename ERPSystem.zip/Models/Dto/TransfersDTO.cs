﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dto
{
    public class TransfersDTO
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Remark { get; set; }
        public string[] OutAddress { get; set; }
        public int BackNum { get; set; }
    }
}
