﻿using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.redis
{
    public class UserInfo_redis
    {
        public int Id { get; set; }
        public string TrueName { get; set; }
        public string CodeNum { get; set; }
        public string Phone { get; set; }
        public UserInfoDTO UserInfo { get; set; }
    }
}
