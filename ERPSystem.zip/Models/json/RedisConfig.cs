﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.json
{
    public class RedisConfig
    {
        public string Con { get; set; }
        public string Name { get; set; }
    }
}
