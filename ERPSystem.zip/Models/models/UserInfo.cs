﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class UserInfo
    {
        public UserInfo()
        {
            Notice = new HashSet<Notice>();
        }

        public int Id { get; set; }
        public string Account { get; set; }
        public string Pwd { get; set; }
        public int? RoleId { get; set; }
        public string Sex { get; set; }
        public int Age { get; set; }
        public string UserImg { get; set; }
        public int? DepartmentId { get; set; }
        public string AccountImg { get; set; }
        public string NickName { get; set; }
        public string TrueName { get; set; }
        public string Remark { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Qq { get; set; }
        public string Md5 { get; set; }
        public string Address { get; set; }
        public DateTime? Birthday { get; set; }
        public int? IsDelete { get; set; }
        public DateTime? AddTime { get; set; }
        public string Addperson { get; set; }

        public virtual Department Department { get; set; }
        public virtual Roles Role { get; set; }
        public virtual ICollection<Notice> Notice { get; set; }
    }
}
