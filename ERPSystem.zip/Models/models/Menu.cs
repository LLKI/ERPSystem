﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Menu
    {
        public Menu()
        {
            MenuRelaRoles = new HashSet<MenuRelaRoles>();
            SonMenu = new HashSet<SonMenu>();
        }

        public int Id { get; set; }
        public string MenuName { get; set; }
        public string Icon { get; set; }
        public string Remark { get; set; }
        public int? IsDelete { get; set; }
        public string Url { get; set; }
        public DateTime? AddTime { get; set; }
        public int? IsEnable { get; set; }

        public virtual ICollection<MenuRelaRoles> MenuRelaRoles { get; set; }
        public virtual ICollection<SonMenu> SonMenu { get; set; }
    }
}
