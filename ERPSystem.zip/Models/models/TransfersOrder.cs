﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class TransfersOrder
    {
        public TransfersOrder()
        {
            TransfersPro = new HashSet<TransfersPro>();
        }

        public int Id { get; set; }
        public string ProNo { get; set; }
        public string AddPerson { get; set; }
        public string Remark { get; set; }
        public string OutAddress { get; set; }
        public int AuditState { get; set; }
        public string AuditPersion { get; set; }
        public int? IsUserDelete { get; set; }
        public int? IsAdminDelete { get; set; }
        public int IsBack { get; set; }
        public int Count { get; set; }
        public DateTime AddTime { get; set; }
        public DateTime? AuditTime { get; set; }
        public decimal TotalMoney { get; set; }
        public int UserId { get; set; }
        public virtual ICollection<TransfersPro> TransfersPro { get; set; }
    }
}
