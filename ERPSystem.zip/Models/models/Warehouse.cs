﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Warehouse
    {
        public Warehouse()
        {
            StockProfile = new HashSet<StockProfile>();
        }

        public int Id { get; set; }
        public string HouseName { get; set; }
        public string Remark { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public DateTime AddTime { get; set; }
        public int ReservoirId { get; set; }

        public virtual Reservoir Reservoir { get; set; }
        public virtual ICollection<StockProfile> StockProfile { get; set; }
    }
}
