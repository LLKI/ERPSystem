﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class BuyProductOrder
    {
        public BuyProductOrder()
        {
            PaymentOrder = new HashSet<PaymentOrder>();
        }

        public int Id { get; set; }
        public string ProNo { get; set; }
        public int AuditState { get; set; }
        public decimal TotalPrice { get; set; }
        public DateTime AddTime { get; set; }
        public int IsUserDel { get; set; }
        public int IsAdminDel { get; set; }
        public string AuditPersion { get; set; }
        public string CatId { get; set; }
        public DateTime? AuditTime { get; set; }
        public int IsBack { get; set; }
        public string Remark { get; set; }
        public int? UserId { get; set; }
        public int? IsPay { get; set; }
        public string AddPerson { get; set; }

        public virtual ICollection<PaymentOrder> PaymentOrder { get; set; }
    }
}
