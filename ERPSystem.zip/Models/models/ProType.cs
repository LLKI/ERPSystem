﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class ProType
    {
        public ProType()
        {
            Brand = new HashSet<Brand>();
        }

        public int Id { get; set; }
        public string TypeName { get; set; }
        public string Remark { get; set; }
        public DateTime AddTime { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }

        public virtual ICollection<Brand> Brand { get; set; }
    }
}
