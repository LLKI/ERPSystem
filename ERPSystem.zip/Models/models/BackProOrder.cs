﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class BackProOrder
    {
        public BackProOrder()
        {
            BackPro = new HashSet<BackPro>();
            Product = new HashSet<Product>();
        }

        public int Id { get; set; }
        public string BackPerson { get; set; }
        public int AuditState { get; set; }
        public string AuditPersion { get; set; }
        public decimal TotalMoney { get; set; }
        public int IsUserDelete { get; set; }
        public int IsAdminDelete { get; set; }
        public string Remark { get; set; }
        public DateTime? AuditTime { get; set; }
        public int? IsBack { get; set; }
        public string ProNo { get; set; }
        public string GotoAddress { get; set; }
        public DateTime? AddTime { get; set; }
        public int? BackNum { get; set; }
        public int? UserId { get; set; }

        public virtual ICollection<BackPro> BackPro { get; set; }
        public virtual ICollection<Product> Product { get; set; }
    }
}
