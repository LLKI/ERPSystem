﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class ERPContext : DbContext
    {
        public ERPContext()
        {
        }

        public ERPContext(DbContextOptions<ERPContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BackPro> BackPro { get; set; }
        public virtual DbSet<BackProOrder> BackProOrder { get; set; }
        public virtual DbSet<Brand> Brand { get; set; }
        public virtual DbSet<BuyProductOrder> BuyProductOrder { get; set; }
        public virtual DbSet<City> City { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<ErrorData> ErrorData { get; set; }
        public virtual DbSet<Feedback> Feedback { get; set; }
        public virtual DbSet<Icon> Icon { get; set; }
        public virtual DbSet<Menu> Menu { get; set; }
        public virtual DbSet<MenuRelaRoles> MenuRelaRoles { get; set; }
        public virtual DbSet<Notice> Notice { get; set; }
        public virtual DbSet<NoticeType> NoticeType { get; set; }
        public virtual DbSet<OutPro> OutPro { get; set; }
        public virtual DbSet<OutProOrder> OutProOrder { get; set; }
        public virtual DbSet<PaymentOrder> PaymentOrder { get; set; }
        public virtual DbSet<ProCat> ProCat { get; set; }
        public virtual DbSet<ProType> ProType { get; set; }
        public virtual DbSet<Product> Product { get; set; }
        public virtual DbSet<Reservoir> Reservoir { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<SonMenu> SonMenu { get; set; }
        public virtual DbSet<StockProfile> StockProfile { get; set; }
        public virtual DbSet<Supplier> Supplier { get; set; }
        public virtual DbSet<TransfersOrder> TransfersOrder { get; set; }
        public virtual DbSet<TransfersPro> TransfersPro { get; set; }
        public virtual DbSet<UserInfo> UserInfo { get; set; }
        public virtual DbSet<Warehouse> Warehouse { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=LAPTOP-T78OH597\\MSSQLSERVERS;Initial Catalog=ERPDB;uid=sa;pwd=pwh781226;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BackPro>(entity =>
            {
                entity.ToTable("backPro");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.BackPerson)
                    .HasColumnName("backPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.GotoAddress)
                    .HasColumnName("gotoAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.Number).HasColumnName("number");

                entity.Property(e => e.ProId).HasColumnName("proId");

                entity.Property(e => e.ProNo)
                    .HasColumnName("proNo")
                    .HasMaxLength(50);

                entity.HasOne(d => d.Pro)
                    .WithMany(p => p.BackPro)
                    .HasForeignKey(d => d.ProId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_backPro_product");

                entity.HasOne(d => d.ProNoNavigation)
                    .WithMany(p => p.BackPro)
                    .HasPrincipalKey(p => p.ProNo)
                    .HasForeignKey(d => d.ProNo)
                    .HasConstraintName("FK_backPro_backProOrder");
            });

            modelBuilder.Entity<BackProOrder>(entity =>
            {
                entity.ToTable("backProOrder");

                entity.HasIndex(e => e.ProNo)
                    .HasName("IX_backProOrder")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AuditPersion)
                    .HasColumnName("auditPersion")
                    .HasMaxLength(100);

                entity.Property(e => e.AuditState).HasColumnName("auditState");

                entity.Property(e => e.AuditTime)
                    .HasColumnName("auditTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.BackNum).HasColumnName("backNum");

                entity.Property(e => e.BackPerson)
                    .IsRequired()
                    .HasColumnName("backPerson")
                    .HasMaxLength(100);

                entity.Property(e => e.GotoAddress)
                    .HasColumnName("gotoAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.IsAdminDelete).HasColumnName("isAdminDelete");

                entity.Property(e => e.IsBack).HasColumnName("isBack");

                entity.Property(e => e.IsUserDelete).HasColumnName("isUserDelete");

                entity.Property(e => e.ProNo)
                    .IsRequired()
                    .HasColumnName("proNo")
                    .HasMaxLength(50);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.TotalMoney)
                    .HasColumnName("totalMoney")
                    .HasColumnType("decimal(18, 0)");

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<Brand>(entity =>
            {
                entity.ToTable("brand");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.BrandName)
                    .IsRequired()
                    .HasColumnName("brandName")
                    .HasMaxLength(100);

                entity.Property(e => e.Img)
                    .IsRequired()
                    .HasColumnName("img")
                    .HasMaxLength(100);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.Md5)
                    .HasColumnName("md5")
                    .HasMaxLength(100);

                entity.Property(e => e.ProTypeId).HasColumnName("proTypeId");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.HasOne(d => d.ProType)
                    .WithMany(p => p.Brand)
                    .HasForeignKey(d => d.ProTypeId)
                    .HasConstraintName("FK__brand__proTypeId__3E52440B");
            });

            modelBuilder.Entity<BuyProductOrder>(entity =>
            {
                entity.ToTable("buyProductOrder");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddPerson)
                    .HasColumnName("addPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AuditPersion)
                    .HasColumnName("auditPersion")
                    .HasMaxLength(100);

                entity.Property(e => e.AuditState).HasColumnName("auditState");

                entity.Property(e => e.AuditTime)
                    .HasColumnName("auditTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.CatId).HasColumnName("catId");

                entity.Property(e => e.IsAdminDel).HasColumnName("isAdminDel");

                entity.Property(e => e.IsBack).HasColumnName("isBack");

                entity.Property(e => e.IsPay).HasColumnName("isPay");

                entity.Property(e => e.IsUserDel).HasColumnName("isUserDel");

                entity.Property(e => e.ProNo)
                    .IsRequired()
                    .HasColumnName("proNo")
                    .HasMaxLength(100);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(50);

                entity.Property(e => e.TotalPrice)
                    .HasColumnName("totalPrice")
                    .HasColumnType("decimal(20, 2)");

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<City>(entity =>
            {
                entity.ToTable("city");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AreaCode)
                    .IsRequired()
                    .HasColumnName("area_code")
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.CityId).HasColumnName("city_id");

                entity.Property(e => e.IsShow)
                    .HasColumnName("is_show")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Lat)
                    .IsRequired()
                    .HasColumnName("lat")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Level).HasColumnName("level");

                entity.Property(e => e.Lng)
                    .IsRequired()
                    .HasColumnName("lng")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.MergerName)
                    .IsRequired()
                    .HasColumnName("merger_name")
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.ParentId).HasColumnName("parent_id");
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("department");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DepaName)
                    .IsRequired()
                    .HasColumnName("depaName")
                    .HasMaxLength(50);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");
            });

            modelBuilder.Entity<ErrorData>(entity =>
            {
                entity.ToTable("errorData");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("date");

                entity.Property(e => e.Count).HasColumnName("count");
            });

            modelBuilder.Entity<Feedback>(entity =>
            {
                entity.ToTable("feedback");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddPerson)
                    .IsRequired()
                    .HasColumnName("addPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Contact)
                    .IsRequired()
                    .HasColumnName("contact")
                    .HasMaxLength(50);

                entity.Property(e => e.Content)
                    .IsRequired()
                    .HasColumnName("content")
                    .HasMaxLength(50);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsSolve).HasColumnName("isSolve");
            });

            modelBuilder.Entity<Icon>(entity =>
            {
                entity.ToTable("icon");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Menu>(entity =>
            {
                entity.ToTable("menu");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Icon)
                    .IsRequired()
                    .HasColumnName("icon")
                    .HasMaxLength(100);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.MenuName)
                    .IsRequired()
                    .HasColumnName("menuName")
                    .HasMaxLength(100);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.Url)
                    .HasColumnName("url")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<MenuRelaRoles>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.MenuId).HasColumnName("menuId");

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.MenuRelaRoles)
                    .HasForeignKey(d => d.MenuId)
                    .HasConstraintName("FK_MenuRelaRoles_menu");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.MenuRelaRoles)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_MenuRelaRoles_roles");
            });

            modelBuilder.Entity<Notice>(entity =>
            {
                entity.ToTable("notice");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Content)
                    .IsRequired()
                    .HasColumnName("content");

                entity.Property(e => e.Img)
                    .HasColumnName("img")
                    .HasMaxLength(100);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.Md5)
                    .HasColumnName("md5")
                    .HasMaxLength(100);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasColumnName("title")
                    .HasMaxLength(100);

                entity.Property(e => e.TypeId).HasColumnName("typeId");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.Notice)
                    .HasForeignKey(d => d.TypeId)
                    .HasConstraintName("FK__notice__typeId__34C8D9D1");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Notice)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__notice__userId__33D4B598");
            });

            modelBuilder.Entity<NoticeType>(entity =>
            {
                entity.ToTable("noticeType");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Icon)
                    .HasColumnName("icon")
                    .HasMaxLength(50);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.Sign)
                    .HasColumnName("sign")
                    .HasMaxLength(50);

                entity.Property(e => e.TabColor)
                    .HasColumnName("tabColor")
                    .HasMaxLength(50);

                entity.Property(e => e.TypeName)
                    .IsRequired()
                    .HasColumnName("typeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<OutPro>(entity =>
            {
                entity.ToTable("outPro");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.BackPerson)
                    .IsRequired()
                    .HasColumnName("backPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.GotoAddress)
                    .IsRequired()
                    .HasColumnName("gotoAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.Number).HasColumnName("number");

                entity.Property(e => e.ProId).HasColumnName("proId");

                entity.Property(e => e.ProNo)
                    .IsRequired()
                    .HasColumnName("proNo")
                    .HasMaxLength(100);

                entity.HasOne(d => d.Pro)
                    .WithMany(p => p.OutPro)
                    .HasForeignKey(d => d.ProId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_outPro_product");

                entity.HasOne(d => d.ProNoNavigation)
                    .WithMany(p => p.OutPro)
                    .HasPrincipalKey(p => p.ProNo)
                    .HasForeignKey(d => d.ProNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_outPro_outPro");
            });

            modelBuilder.Entity<OutProOrder>(entity =>
            {
                entity.ToTable("outProOrder");

                entity.HasIndex(e => e.ProNo)
                    .HasName("IX_outProOrder")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AuditPerson)
                    .HasColumnName("auditPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.AuditState).HasColumnName("auditState");

                entity.Property(e => e.AuditTime)
                    .HasColumnName("auditTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.BackNum).HasColumnName("backNum");

                entity.Property(e => e.GotoAddress)
                    .HasColumnName("gotoAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.IsAdminDelete).HasColumnName("isAdminDelete");

                entity.Property(e => e.IsUserDelete).HasColumnName("isUserDelete");

                entity.Property(e => e.OutPerson)
                    .IsRequired()
                    .HasColumnName("outPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.ProNo)
                    .IsRequired()
                    .HasColumnName("proNo")
                    .HasMaxLength(100);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(50);

                entity.Property(e => e.TotalMoney)
                    .HasColumnName("totalMoney")
                    .HasMaxLength(50);

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<PaymentOrder>(entity =>
            {
                entity.ToTable("paymentOrder");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AuditTime)
                    .HasColumnName("auditTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.ButType).HasColumnName("butType");

                entity.Property(e => e.BuyProductId).HasColumnName("buyProductId");

                entity.Property(e => e.CancelPerson)
                    .HasColumnName("cancelPerson")
                    .HasMaxLength(50);

                entity.Property(e => e.IsAdminDelete).HasColumnName("isAdminDelete");

                entity.Property(e => e.IsAudit).HasColumnName("isAudit");

                entity.Property(e => e.IsUserDelete).HasColumnName("isUserDelete");

                entity.Property(e => e.PayPerson)
                    .HasColumnName("payPerson")
                    .HasMaxLength(100);

                entity.Property(e => e.PayTime)
                    .HasColumnName("payTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProNo)
                    .HasColumnName("proNo")
                    .HasMaxLength(50);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.TotalMoney)
                    .HasColumnName("totalMoney")
                    .HasColumnType("decimal(18, 0)");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.BuyProduct)
                    .WithMany(p => p.PaymentOrder)
                    .HasForeignKey(d => d.BuyProductId)
                    .HasConstraintName("FK__paymentOr__buyPr__4D94879B");
            });

            modelBuilder.Entity<ProCat>(entity =>
            {
                entity.ToTable("proCat");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .IsUnicode(false);

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");
            });

            modelBuilder.Entity<ProType>(entity =>
            {
                entity.ToTable("proType");

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.TypeName)
                    .IsRequired()
                    .HasColumnName("typeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("product");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AckTime)
                    .HasColumnName("ackTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AddPerson)
                    .IsRequired()
                    .HasColumnName("addPerson")
                    .HasMaxLength(100);

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(50);

                entity.Property(e => e.BackNum)
                    .HasColumnName("backNum")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.BackOrderId)
                    .HasColumnName("backOrderId")
                    .HasMaxLength(50);

                entity.Property(e => e.BrandId).HasColumnName("brandId");

                entity.Property(e => e.CatId)
                    .HasColumnName("catId")
                    .HasMaxLength(50);

                entity.Property(e => e.Color)
                    .HasColumnName("color")
                    .HasMaxLength(100);

                entity.Property(e => e.CostPrice)
                    .HasColumnName("costPrice")
                    .HasColumnType("decimal(20, 2)");

                entity.Property(e => e.GotoAddress)
                    .HasColumnName("gotoAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.IsAudio).HasColumnName("isAudio");

                entity.Property(e => e.IsBack).HasColumnName("isBack");

                entity.Property(e => e.IsBackPro).HasColumnName("isBackPro");

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.IsEnough).HasColumnName("isEnough");

                entity.Property(e => e.Material)
                    .HasColumnName("material")
                    .HasMaxLength(100);

                entity.Property(e => e.Md5)
                    .HasColumnName("md5")
                    .HasMaxLength(100);

                entity.Property(e => e.MoveTime)
                    .HasColumnName("moveTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.PayTime)
                    .HasColumnName("payTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Price)
                    .HasColumnName("price")
                    .HasColumnType("decimal(20, 2)");

                entity.Property(e => e.ProImg)
                    .IsRequired()
                    .HasColumnName("proImg")
                    .HasMaxLength(100);

                entity.Property(e => e.ProName)
                    .IsRequired()
                    .HasColumnName("proName")
                    .HasMaxLength(100);

                entity.Property(e => e.ProType)
                    .HasColumnName("proType")
                    .HasMaxLength(50);

                entity.Property(e => e.ProWeight)
                    .HasColumnName("proWeight")
                    .HasColumnType("decimal(20, 2)");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.ReservoirId).HasColumnName("reservoirId");

                entity.Property(e => e.Size)
                    .HasColumnName("size")
                    .HasColumnType("decimal(20, 2)");

                entity.Property(e => e.Stock)
                    .IsRequired()
                    .HasColumnName("stock")
                    .HasMaxLength(50);

                entity.Property(e => e.SupplierId).HasColumnName("supplierId");

                entity.Property(e => e.TakeDown)
                    .HasColumnName("takeDown")
                    .HasColumnType("datetime");

                entity.Property(e => e.TransfersTime)
                    .HasColumnName("transfersTime")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.BackOrder)
                    .WithMany(p => p.Product)
                    .HasPrincipalKey(p => p.ProNo)
                    .HasForeignKey(d => d.BackOrderId)
                    .HasConstraintName("FK_product_backProOrder");

                entity.HasOne(d => d.Brand)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.BrandId)
                    .HasConstraintName("FK__product__brandId__44FF419A");

                entity.HasOne(d => d.Reservoir)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.ReservoirId)
                    .HasConstraintName("FK_product_reservoir");

                entity.HasOne(d => d.Supplier)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.SupplierId)
                    .HasConstraintName("FK__product__supplie__45F365D3");
            });

            modelBuilder.Entity<Reservoir>(entity =>
            {
                entity.ToTable("reservoir");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.ReservoirName)
                    .IsRequired()
                    .HasColumnName("reservoirName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.ToTable("roles");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasColumnName("roleName")
                    .HasMaxLength(100);

                entity.Property(e => e.Sign)
                    .HasColumnName("sign")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SonMenu>(entity =>
            {
                entity.ToTable("sonMenu");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Icon)
                    .HasColumnName("icon")
                    .HasMaxLength(50);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.MenuName)
                    .HasColumnName("menuName")
                    .HasMaxLength(50);

                entity.Property(e => e.ParentId).HasColumnName("parentId");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.Url)
                    .HasColumnName("url")
                    .HasMaxLength(100);

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.SonMenu)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK__sonMenu__parentI__267ABA7A");
            });

            modelBuilder.Entity<StockProfile>(entity =>
            {
                entity.ToTable("stockProfile");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.WarehouseId).HasColumnName("warehouseId");

                entity.HasOne(d => d.Warehouse)
                    .WithMany(p => p.StockProfile)
                    .HasForeignKey(d => d.WarehouseId)
                    .HasConstraintName("FK__stockProf__wareh__59063A47");
            });

            modelBuilder.Entity<Supplier>(entity =>
            {
                entity.ToTable("supplier");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasColumnName("address")
                    .HasMaxLength(100);

                entity.Property(e => e.Contactperson)
                    .HasColumnName("contactperson")
                    .HasMaxLength(100);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(100);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.MailingAddress)
                    .HasColumnName("mailingAddress")
                    .HasMaxLength(100);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasColumnName("phone")
                    .HasMaxLength(20);

                entity.Property(e => e.PostalCode).HasColumnName("postalCode");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.SupplierName)
                    .IsRequired()
                    .HasColumnName("supplierName")
                    .HasMaxLength(100);

                entity.Property(e => e.Website)
                    .HasColumnName("website")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TransfersOrder>(entity =>
            {
                entity.ToTable("transfersOrder");

                entity.HasIndex(e => e.ProNo)
                    .HasName("IX_transfersOrder")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.TotalMoney).HasColumnName("totalMoney");
                entity.Property(e => e.UserId).HasColumnName("userId");
                entity.Property(e => e.AddPerson)
                    .IsRequired()
                    .HasColumnName("addPerson")
                    .HasMaxLength(100);

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.AuditPersion)
                    .HasColumnName("auditPersion")
                    .HasMaxLength(100);

                entity.Property(e => e.AuditState).HasColumnName("auditState");

                entity.Property(e => e.AuditTime)
                    .HasColumnName("auditTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Count).HasColumnName("count");

                entity.Property(e => e.IsAdminDelete).HasColumnName("isAdminDelete");

                entity.Property(e => e.IsBack).HasColumnName("isBack");

                entity.Property(e => e.IsUserDelete).HasColumnName("isUserDelete");

                entity.Property(e => e.OutAddress)
                    .IsRequired()
                    .HasColumnName("outAddress")
                    .HasMaxLength(100);

                entity.Property(e => e.ProNo)
                    .IsRequired()
                    .HasColumnName("proNo")
                    .HasMaxLength(100);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TransfersPro>(entity =>
            {
                entity.ToTable("transfersPro");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.InAddress)
                    .IsRequired()
                    .HasColumnName("inAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.Number).HasColumnName("number");

                entity.Property(e => e.OutAddress)
                    .IsRequired()
                    .HasColumnName("outAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.ProId).HasColumnName("proId");

                entity.Property(e => e.ProNo)
                    .IsRequired()
                    .HasColumnName("proNo")
                    .HasMaxLength(100);

                entity.Property(e => e.TransfersPerson)
                    .IsRequired()
                    .HasColumnName("transfersPerson")
                    .HasMaxLength(50);

                entity.HasOne(d => d.Pro)
                    .WithMany(p => p.TransfersPro)
                    .HasForeignKey(d => d.ProId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_transfersPro_product");

                entity.HasOne(d => d.ProNoNavigation)
                    .WithMany(p => p.TransfersPro)
                    .HasPrincipalKey(p => p.ProNo)
                    .HasForeignKey(d => d.ProNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_transfersPro_transfersPro");
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.ToTable("userInfo");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Account)
                    .IsRequired()
                    .HasColumnName("account")
                    .HasMaxLength(100);

                entity.Property(e => e.AccountImg)
                    .HasColumnName("accountImg")
                    .HasMaxLength(100);

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Addperson)
                    .HasColumnName("addperson")
                    .HasMaxLength(100);

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(100);

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.Birthday)
                    .HasColumnName("birthday")
                    .HasColumnType("date");

                entity.Property(e => e.DepartmentId).HasColumnName("departmentId");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(50);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.Md5)
                    .HasColumnName("md5")
                    .HasMaxLength(100);

                entity.Property(e => e.NickName)
                    .HasColumnName("nickName")
                    .HasMaxLength(100);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasColumnName("phone")
                    .HasMaxLength(50);

                entity.Property(e => e.Pwd)
                    .IsRequired()
                    .HasColumnName("pwd")
                    .HasMaxLength(100);

                entity.Property(e => e.Qq)
                    .HasColumnName("QQ")
                    .HasMaxLength(50);

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.Sex)
                    .IsRequired()
                    .HasColumnName("sex")
                    .HasMaxLength(10);

                entity.Property(e => e.TrueName)
                    .IsRequired()
                    .HasColumnName("trueName")
                    .HasMaxLength(100);

                entity.Property(e => e.UserImg)
                    .HasColumnName("userImg")
                    .HasMaxLength(100);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.UserInfo)
                    .HasForeignKey(d => d.DepartmentId)
                    .HasConstraintName("FK__userInfo__depart__2F10007B");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.UserInfo)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK__userInfo__roleId__2E1BDC42");
            });

            modelBuilder.Entity<Warehouse>(entity =>
            {
                entity.ToTable("warehouse");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.HouseName)
                    .IsRequired()
                    .HasColumnName("houseName")
                    .HasMaxLength(100);

                entity.Property(e => e.IsDelete).HasColumnName("isDelete");

                entity.Property(e => e.IsEnable).HasColumnName("isEnable");

                entity.Property(e => e.Remark)
                    .HasColumnName("remark")
                    .HasMaxLength(100);

                entity.Property(e => e.ReservoirId).HasColumnName("reservoirId");

                entity.HasOne(d => d.Reservoir)
                    .WithMany(p => p.Warehouse)
                    .HasForeignKey(d => d.ReservoirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_warehouse_reservoir");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
