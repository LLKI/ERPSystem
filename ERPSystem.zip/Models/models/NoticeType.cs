﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class NoticeType
    {
        public NoticeType()
        {
            Notice = new HashSet<Notice>();
        }

        public int Id { get; set; }
        public string TypeName { get; set; }
        public int IsDelete { get; set; }
        public DateTime AddTime { get; set; }
        public string Icon { get; set; }
        public string TabColor { get; set; }
        public string Sign { get; set; }

        public virtual ICollection<Notice> Notice { get; set; }
    }
}
