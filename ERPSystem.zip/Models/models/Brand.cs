﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Brand
    {
        public Brand()
        {
            Product = new HashSet<Product>();
        }

        public int Id { get; set; }
        public string BrandName { get; set; }
        public string Img { get; set; }
        public string Md5 { get; set; }
        public string Remark { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public int? ProTypeId { get; set; }
        public DateTime AddTime { get; set; }

        public virtual ProType ProType { get; set; }
        public virtual ICollection<Product> Product { get; set; }
    }
}
