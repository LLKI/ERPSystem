﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Notice
    {
        public int Id { get; set; }
        public string Content { get; set; }
        public string Title { get; set; }
        public int IsDelete { get; set; }
        public int? UserId { get; set; }
        public string Img { get; set; }
        public string Md5 { get; set; }
        public int? TypeId { get; set; }
        public DateTime AddTime { get; set; }

        public virtual NoticeType Type { get; set; }
        public virtual UserInfo User { get; set; }
    }
}
