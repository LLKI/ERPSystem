﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Supplier
    {
        public Supplier()
        {
            Product = new HashSet<Product>();
        }

        public int Id { get; set; }
        public string SupplierName { get; set; }
        public string Address { get; set; }
        public int? PostalCode { get; set; }
        public string MailingAddress { get; set; }
        public string Contactperson { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string Email { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public string Remark { get; set; }
        public DateTime AddTime { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
