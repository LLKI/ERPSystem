﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Roles
    {
        public Roles()
        {
            MenuRelaRoles = new HashSet<MenuRelaRoles>();
            UserInfo = new HashSet<UserInfo>();
        }

        public int Id { get; set; }
        public string RoleName { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public DateTime AddTime { get; set; }
        public string Sign { get; set; }

        public virtual ICollection<MenuRelaRoles> MenuRelaRoles { get; set; }
        [JsonIgnore]
        public virtual ICollection<UserInfo> UserInfo { get; set; }
    }
}
