﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Product
    {
        public Product()
        {
            BackPro = new HashSet<BackPro>();
            OutPro = new HashSet<OutPro>();
            TransfersPro = new HashSet<TransfersPro>();
        }

        public int Id { get; set; }
        public string ProName { get; set; }
        public string Color { get; set; }
        public int? BrandId { get; set; }
        public decimal CostPrice { get; set; }
        public decimal Price { get; set; }
        public decimal? ProWeight { get; set; }
        public decimal? Size { get; set; }
        public string Material { get; set; }
        public string Stock { get; set; }
        public string ProImg { get; set; }
        public string Md5 { get; set; }
        public DateTime AddTime { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public DateTime? TakeDown { get; set; }
        public string Remark { get; set; }
        public int? IsEnough { get; set; }
        public DateTime? AckTime { get; set; }
        public int? SupplierId { get; set; }
        public int? ReservoirId { get; set; }
        public string AddPerson { get; set; }
        public int IsBackPro { get; set; }
        public int IsAudio { get; set; }
        public string CatId { get; set; }
        public string Address { get; set; }
        public string ProType { get; set; }
        public int? IsBack { get; set; }
        public string BackOrderId { get; set; }
        public decimal? BackNum { get; set; }
        public DateTime? MoveTime { get; set; }
        public DateTime? TransfersTime { get; set; }
        public DateTime? PayTime { get; set; }
        public string GotoAddress { get; set; }

        public virtual BackProOrder BackOrder { get; set; }
        public virtual Brand Brand { get; set; }
        public virtual Reservoir Reservoir { get; set; }
        public virtual Supplier Supplier { get; set; }
        public virtual ICollection<BackPro> BackPro { get; set; }
        public virtual ICollection<OutPro> OutPro { get; set; }
        public virtual ICollection<TransfersPro> TransfersPro { get; set; }
    }
}
