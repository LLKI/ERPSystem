﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class PaymentOrder
    {
        public int Id { get; set; }
        public int? BuyProductId { get; set; }
        public int ButType { get; set; }
        public string Remark { get; set; }
        public DateTime? PayTime { get; set; }
        public string PayPerson { get; set; }
        public int IsUserDelete { get; set; }
        public int IsAdminDelete { get; set; }
        public decimal TotalMoney { get; set; }
        public DateTime? AddTime { get; set; }
        public int? IsAudit { get; set; }
        public string ProNo { get; set; }
        public int? UserId { get; set; }
        public DateTime? AuditTime { get; set; }
        public string CancelPerson { get; set; }

        public virtual BuyProductOrder BuyProduct { get; set; }
    }
}
