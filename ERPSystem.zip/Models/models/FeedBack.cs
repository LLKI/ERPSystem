﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Feedback
    {
        public int Id { get; set; }
        public string Content { get; set; }
        public string AddPerson { get; set; }
        public DateTime? AddTime { get; set; }
        public string Contact { get; set; }
        public int IsDelete { get; set; }
        public int IsSolve { get; set; }
    }
}
