﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Transfers
    {
        public int Id { get; set; }
        public string TransfersNo { get; set; }
        public string CreatePerson { get; set; }
        public int? ProId { get; set; }
        public string Remark { get; set; }
        public string OutAddress { get; set; }
        public string InAddress { get; set; }
        public int AuditState { get; set; }
        public string AuditPersion { get; set; }
        public int? IsUserDelete { get; set; }
        public int? IsAdminDelete { get; set; }
        public int IsBack { get; set; }
        public int Count { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? AuditTime { get; set; }

        public virtual Product Pro { get; set; }
    }
}
