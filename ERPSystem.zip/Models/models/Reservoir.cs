﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Models.models
{
    public partial class Reservoir
    {
        public Reservoir()
        {
            Product = new HashSet<Product>();
            Warehouse = new HashSet<Warehouse>();
        }

        public int Id { get; set; }
        public string ReservoirName { get; set; }
        public int IsEnable { get; set; }
        public int IsDelete { get; set; }
        public DateTime AddTime { get; set; }
        public string Remark { get; set; }

        public virtual ICollection<Product> Product { get; set; }
        public virtual ICollection<Warehouse> Warehouse { get; set; }
    }
}
