﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.email
{
    public class Email
    {
        public string Title1 { get; set; }
        public string Title2 { get; set; }
        public string From { get; set; }
        public string phone { get; set; }
        public string To { get; set; }
        public string Content { get; set; }
        public int UserId { get; set; }
    }
}
