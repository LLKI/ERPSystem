using BLL;
using Common;
using IBLL;
using log4net.Repository; // ��־��
using Microsoft.AspNetCore.Builder;//������
using Microsoft.AspNetCore.Hosting; // ����
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;// ����
using Microsoft.Extensions.DependencyInjection;//����ע��
using Microsoft.Extensions.FileProviders;// �ļ��ṩ
using Microsoft.Extensions.Hosting;// ����
using Models.json; // JSONģ��
using Models.models; // ģ��
using Newtonsoft.Json; // JSON���л�

namespace ERPWeb
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        //log4net
        public static ILoggerRepository loggerRepository { get; set; }
        private readonly string myCors = "myCors";
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.Configure<RedisConfig>(Configuration.GetSection("RedisConfig"));
            //ע�� ʵ���� start
            services.AddScoped<ILoginBLL, LoginBLL>();
            services.AddScoped<INotifyBLL,NotifyBLL>();
            services.AddScoped<IWarehouseBLL, WarehouseBLL>();
            services.AddScoped<IUserBLL, UserBLL>();
            services.AddScoped<RedisHelper>();
            services.AddScoped<IReservoirBLL, ReservoirBLL>();
            services.AddScoped<IProTypeBLL, ProTypeBLL>();
            services.AddScoped<IBrandBLL, BrandBLL>();
            services.AddScoped<ISupplierBLL, SupplierBLL>();
            services.AddScoped<IProductBLL, ProductBLL>();
            services.AddScoped<ICartBLL, CartBLL>();
            services.AddScoped<IBuyOrderBLL, BuyOrderBLL>();
            services.AddScoped<IRolesBLL, RoleBLL>();
            services.AddScoped<IPayOrderBLL, PayOrderBLL>();
            services.AddScoped<IUserInfoBLL, UserInfoBLL>();
            services.AddScoped<IDepartmentBLL, DepartmentBLL>();
            services.AddScoped<IMenuBLL, MenuBLL>();
            services.AddScoped<IIconBLL, IconBLL>();
            services.AddScoped<ILogBLL, LogBLL>();
            services.AddScoped<IErrorBLL, ErrorBLL>();
            services.AddScoped<IWarehouseInfoBLL,WarehouseInfoBLL>();
            services.AddScoped<ISonMenuBLL, SonMenuBLL>();
            services.AddScoped<IBackBLL, BackBLL>();
            services.AddScoped<IFeedback, FeedbackBLL>();
            services.AddScoped<IproProfileBLL, proProfileBLL>();
            services.AddScoped<IOutOrderBLL, OutOrderBLL>();
            services.AddScoped<ITransfersBLL, TransfersBLL>();
            //ע�� ʵ���� end
            //�������
            services.AddCors(option =>
            {
                option.AddPolicy(myCors, build =>
                {
                    build.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
                });
            });
            //������� end
            //ע�� ���������� start
            services.AddDbContext<ERPContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("con"));
            });

            //ע�� ���������� end
            services.AddHttpClient();
            services.AddControllers();

            //ע��redis
            services.AddDistributedRedisCache(op =>
            {
                op.ConfigurationOptions = new StackExchange.Redis.ConfigurationOptions
                {
                    EndPoints = { { "127.0.0.1", 6379 } },
                    ConnectTimeout = 80000,
                    ClientName="ERPDB",
                    ServiceName="ERPDB",
                };
            });
            // �ر�Ĭ��ģ����֤
            services.Configure<ApiBehaviorOptions>(opt => opt.SuppressModelStateInvalidFilter = true);
            services.AddControllers(options =>
            {
                options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
            }).AddNewtonsoftJson(option =>
               //����ѭ������ ���ӻᱨ��
               option.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore

           );
            // services.AddControllers().AddNewtonsoftJson(option =>
            //    //����ѭ������ ���ӻᱨ��
            //    option.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore

            //);

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        // Configure������������HTTP�������ܵ�
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            app.UseCors();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers().RequireCors(myCors);
            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.NotifyImgUrl),
                RequestPath = new PathString("/files/notify")

            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.AccountImgPath),
                RequestPath = new PathString("/files/accountImg")
            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.BrandImgPath),
                RequestPath = new PathString("/files/brandImg")
            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.SupplierExcelPath),
                RequestPath = new PathString("/files/supplier")
            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.ProductImgPath),
                RequestPath = new PathString("/files/productImg")
            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.LogPdfErrorPath),
                RequestPath = new PathString("/files/logPdf/error")
            });
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Common.BaseUrl.LogPdfDebugPath),
                RequestPath = new PathString("/files/logPdf/debug")
            });
        }
    }
}
