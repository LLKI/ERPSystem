﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.warehouse
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class ReservoirController : ControllerBase
    {
        private IReservoirBLL reservoirBLL;
        public ReservoirController(IReservoirBLL reservoirBLL)
        {
            this.reservoirBLL = reservoirBLL;
        }
        //获取所有的库区信息
        [HttpGet]
        public async Task<ApiResult> Get()
        {
            return await reservoirBLL.GetAllReservoirs();
        }

        //修改库区的状态
        [HttpGet("{id}/{state}")]
        public async Task<ApiResult> Get(int id,int state)
        {
            return await reservoirBLL.UpdateStateById(id,state);
        }

        //添加库区
        [HttpPost]
        public async Task<ApiResult> Post([FromBody] Reservoir res)
        {
            return await reservoirBLL.AddReservoir(res);
        }

         // PUT api/<ReservoirController>/5
        [HttpPut]
        public async Task<ApiResult> Put([FromBody] Reservoir res)
        {
            return await reservoirBLL.UpdateReservoir(res);
        }

        // DELETE api/<ReservoirController>/5
        [HttpDelete("{id}")]
        public async Task<ApiResult> Delete(int id)
        {
            return await reservoirBLL.DeleteReservoir(id);
        }


        [HttpGet("{id}")]
        public async Task<ApiResult> GetDataById(int id)
        {

            return await reservoirBLL.GetDataById(id);
        }
    }
}
