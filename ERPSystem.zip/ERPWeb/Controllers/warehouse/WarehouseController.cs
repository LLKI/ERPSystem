﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.warehouse
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class WarehouseController : ControllerBase
    {
        private IWarehouseBLL warehouseBLL;
        public WarehouseController(IWarehouseBLL warehouseBLL)
        {
            this.warehouseBLL = warehouseBLL;
        }
        //获取所有的库房信息
        [HttpGet]
        public async Task<ApiResult> Get()
        {
            return await warehouseBLL.GetAllWareHouse();
        }
        //获取所有的库区信息
        [HttpGet]
        [Route("reservory")]
        public async Task<ApiResult> GetReservory()
        {
            return await warehouseBLL.GetAllReservorys();
        }
        //通过id获取库房的信息
        [HttpGet("{id}")]
        public async Task<ApiResult> Get(int id)
        {
            return await warehouseBLL.GetWarehouseById(id);
        }
        //通过库区id获取库房
        [HttpGet]
        [Route("reservory/{id}")]
        public async Task<ApiResult> GetRes(int id)
        {
            return await warehouseBLL.GetReservoirsById(id);
        }
        //获取所有的库区信息
        [HttpGet]
        [Route("reservory/state/{state}")]
        public async Task<ApiResult> GetAllReservorys(int state)
        {
            return await warehouseBLL.GetAllReservorys(state);
        }

        // GET api/<WarehouseController>/5
        [HttpGet("{id}/{state}")]
        public async Task<ApiResult> Get(int id,int state)
        {
            return await warehouseBLL.UpdateStateById(id, state);
        }

        //添加库房信息
        [HttpPost]
        public async Task<ApiResult> Post([FromBody] Warehouse warehouse)
        {
            return await warehouseBLL.AddWarehouse(warehouse);
        }

        //修改库房信息
        [HttpPut]
        public async Task<ApiResult> Put([FromBody] Warehouse warehouse)
        {
             return await warehouseBLL.UpdateWarehouse(warehouse);
        }

        //通过id删除库房
        [HttpDelete("{id}")]
        public async Task<ApiResult> Delete(int id)
        {
             return await warehouseBLL.DelWarehouseById(id);
        }
    }
}
