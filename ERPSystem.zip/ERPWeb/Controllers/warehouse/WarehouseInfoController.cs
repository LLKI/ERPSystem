﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.warehouse
{
    [Route("api/[controller]")]
    [ApiController]
    public class WarehouseInfoController : ControllerBase
    {

        private IWarehouseInfoBLL wareBLL;
        public WarehouseInfoController(IWarehouseInfoBLL wareBLL)
        {
            this.wareBLL = wareBLL;
        }
        [HttpGet]
        public async Task<ApiResult> GetInfo()
        {
            return await wareBLL.GetInfo();
        }

        [HttpGet]
        [Route("count")]
        public async Task<ApiResult> GetCount()
        {
            return await wareBLL.GetCount();
        }

        [HttpGet]
        [Route("week")]
        public async Task<ApiResult> GetWeekInfo()
        {
            return await wareBLL.GetWeekInfo();
        }
    }
}
