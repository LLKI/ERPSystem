﻿using Aop.Api.Domain;
using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.proProfileBLL
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProProfileController : ControllerBase
    {


        private IproProfileBLL proBLL;
        public ProProfileController(IproProfileBLL proBLL)
        {
            this.proBLL = proBLL;
        }
        [HttpGet]
        public async Task<ApiResult> GetProTypeCount()
        {
            return await proBLL.GetProTypeCount();
        }
    }
}
