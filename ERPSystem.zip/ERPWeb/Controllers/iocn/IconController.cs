﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.iocn
{
    [Route("api/[controller]")]
    [ApiController]
    public class IconController : ControllerBase
    {

        private IIconBLL iconBLL;
        public IconController(IIconBLL iconBLL)
        {
            this.iconBLL = iconBLL;
        }
        /// <summary>
        /// 获取所有的icon
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ApiResult> GetAllIcons()
        {
            return await iconBLL.GetAllIcon();
        }
    }
}
