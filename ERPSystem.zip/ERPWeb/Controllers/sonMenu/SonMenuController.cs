﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.models;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.sonMenu
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class SonMenuController : ControllerBase
    {
        private ISonMenuBLL menuBLL;

        public SonMenuController(ISonMenuBLL menuBLL)
        {
            this.menuBLL = menuBLL;
        }

        [HttpGet("{id}")]
        public async Task<ApiResult> GetSonMenuById(int id)
        {
            return await menuBLL.GetSonMenuById(id);
        }
        /// <summary>
        /// 修改菜单
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<ApiResult> UpdateSonMenu([FromBody] SonMenu menu)
        {
            return await menuBLL.UpdateMenu(menu);
        }
        [HttpPost]
        public async Task<ApiResult> AddSonMenu([FromBody] SonMenu menu)
        {
            return await menuBLL.AddSonMenu(menu);
        }
        /// <summary>
        /// 删除菜单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ApiResult> DelMenuById(int id)
        {
            return await menuBLL.DelMenuById(id);
        }
    }
}
