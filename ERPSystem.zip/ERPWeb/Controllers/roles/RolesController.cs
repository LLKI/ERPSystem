﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.roles
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class RolesController : ControllerBase
    {

        private IRolesBLL roleBll;
        public RolesController(IRolesBLL roleBll)
        {
            this.roleBll = roleBll;
        }
        /// <summary>
        /// 通过用户id获取角色信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ApiResult> GetRoleById(int id)
        {
            return await roleBll.GetRoleById(id);
        }
        /// <summary>
        /// 获取所有的角色
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ApiResult> GetRoles()
        {
            return await roleBll.GetRoles();
        }

        [HttpGet]
        [Route("menu/{id}")]
        public async Task<ApiResult> GetMenuByRoleId(int id)
        {
            return await roleBll.GetMenuByRoleId(id);
        }
        /// <summary>
        /// 修改角色信息
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> UpdateRole(RoleDTO role)
        {
            return await roleBll.UpdateRole(role);
        }
        [HttpPost]
        [Route("add")]
        public async Task<ApiResult> AddRole(RoleDTO role)
        {
            return await roleBll.AddRole(role);
        }
        /// <summary>
        /// 删除角色
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ApiResult> DelRole(int id)
        {
            return await roleBll.DelRoleByid(id);
        }
    }
}
