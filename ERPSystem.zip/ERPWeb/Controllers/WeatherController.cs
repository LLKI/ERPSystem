﻿using Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Models.weather;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ERPWeb.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherController : ControllerBase
    {
        private IHttpClientFactory _httpClientFactory;
        private RedisHelper _redisHelper;
        public WeatherController(IHttpClientFactory httpClientFactory,RedisHelper redisHelper)
        {
            this._httpClientFactory = httpClientFactory;
            this._redisHelper = redisHelper;    
        }
        /// <summary>
        /// 获取天气
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ApiResult> Get()
        {
            Weather weather;
            using (HttpClient client= _httpClientFactory.CreateClient())
            {
                if (await _redisHelper.GetValueAsync("weather") == null)
                {//https://api.vvhan.com/api/ipCard?tip=欢迎使用ERP
                    string str = await client.GetStringAsync("https://api.vvhan.com/api/weather");
                    weather = JsonConvert.DeserializeObject<Weather>(str);
                    await _redisHelper.SetValueAsync("weather", str, TimeSpan.FromHours(6));


                    return ApiResult.Success(weather);
                }
                else
                {
                    byte[] bytes = await _redisHelper.GetValueAsync("weather");
                    string obj = Encoding.UTF8.GetString(bytes, 0, bytes.Length);
                    weather = JsonConvert.DeserializeObject<Weather>(obj);
                    return ApiResult.Success(weather);
                }
            }
        }
    }
}
