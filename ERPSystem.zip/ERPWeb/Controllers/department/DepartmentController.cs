﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.department
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private IDepartmentBLL depaBLL;
        public DepartmentController(IDepartmentBLL depaBLL)
        {
            this.depaBLL = depaBLL;
        }
        /// <summary>
        /// 获取所有的部门信息
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResult> GetAllDepartmetns()
        {
            return await depaBLL.GetAllDepartmetns();
        }
    }
}
