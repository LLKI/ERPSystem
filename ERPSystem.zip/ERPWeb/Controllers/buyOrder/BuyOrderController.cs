﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.buyOrder
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class BuyOrderController : ControllerBase
    {
        private IBuyOrderBLL orderBLL;

        public BuyOrderController(IBuyOrderBLL orderBLL)
        {
            this.orderBLL = orderBLL;
        }
        /// <summary>
        /// 获取所有的订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> GetAllOrders(BuyOrderDTO order)
        {
            return await orderBLL.GetAllOrder(order);
        }

       

        /// <summary>
        /// 通过购物车id获取商品信息
        /// </summary>
        /// <param name="catId"></param>
        /// <returns></returns>
        [HttpGet("{catId}")]
        public async Task<ApiResult> GetProsByCatId(string catId)
        {
            return await orderBLL.GetProsByCatId(catId);
        }
        /// <summary>
        /// 通过id修改订单的状态 通过
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("allow")]
        public async Task<ApiResult> UpdateStateAllowById([FromBody] OrderStateDTO order)
        {
            return await orderBLL.UpdateStateById(order);
        }
        /// <summary>
        /// 通过id修改订单的状态 驳回
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("back")]
        public async Task<ApiResult> UpdateStateBackById([FromBody] OrderStateDTO order)
        {
            return await orderBLL.UpdateStateToNoById(order);
        }
        /// <summary>
        /// 通过id修改订单的状态 撤销
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("undo")]
        public async Task<ApiResult> UndoOrder([FromBody] OrderStateDTO order)
        {
            return await orderBLL.UndoOrder(order);
        }
        /// <summary>
        /// 删除订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("del")]
        public async Task<ApiResult> DelOrderById([FromBody] OrderStateDTO order)
        {
            return await orderBLL.DelOrderById(order);
        }
    }
}
