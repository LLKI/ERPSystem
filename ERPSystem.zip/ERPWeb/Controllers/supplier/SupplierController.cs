﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.supplier
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class SupplierController : ControllerBase
    {
        private ISupplierBLL supplierBLL;
        public SupplierController(ISupplierBLL supplierBLL)
        {
            this.supplierBLL = supplierBLL;
        }
        //获取所有的供应商
        [HttpPost]
        public async Task<ApiResult> GetAllSuppliers([FromBody] SupplierDTO sup)
        {
            return await supplierBLL.GetAllSuppliers(sup);
        }

        //通过id获取供应商信息
        [HttpGet("{id}")]
        public async Task<ApiResult> GetSupplierById(int id)
        {
            return await supplierBLL.GetSupplierById(id);
        }
        //通过id获取供应商信息
        [HttpGet]
        public async Task<ApiResult> GetAllSuppliers()
        {
            return await supplierBLL.GetAllSuppliers();
        }
        //导出excel
        [HttpPost]
        [Route("export")]
        public async Task<ApiResult> Post([FromBody] SupplierDTO sup)
        {
            return await supplierBLL.ExportSupplier(sup);
        }
        //添加供应商
        [HttpPost]
        [Route("add")]
        public async Task<ApiResult> Post([FromBody] Supplier sup)
        {
            return await supplierBLL.AddSupplier(sup);
        }

        //修改供应商信息
        [HttpPut]
        public async Task<ApiResult> Put( [FromBody] Supplier sup)
        {
            return await supplierBLL.UpdateSupplier(sup);
        }

        //修改供应商状态
        [HttpPut("{id}/{state}")]
        public async Task<ApiResult> Put(int id,int state)
        {
            return await supplierBLL.UpdateState(id,state);
        }

        //删除供应商
        [HttpDelete("{id}")]
        public async Task<ApiResult> Delete(int id)
        {
            return await supplierBLL.DeleteSupplierById(id);
        }
    }
}
