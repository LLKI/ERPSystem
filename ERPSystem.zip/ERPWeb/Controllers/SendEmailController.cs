﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Mail;
using System;
using MimeKit;
using MailKit.Net.Smtp;
using Models.email;
using Microsoft.AspNetCore.Cors;
using Common;
using common;
using System.Threading.Tasks;
using Models.models;
using Microsoft.EntityFrameworkCore;

namespace ERPWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class SendEmailController : ControllerBase
    {

        private ERPContext db;
        public SendEmailController(ERPContext db)
        {
            this.db = db;
        }

        [HttpPost]
        public async Task<ApiResult> SendEmail(Email email)
        {
            email.Title1 = "系统问题";
            email.Title2 = "系统问题";
            //string validateCode = "";
            //Random ran = new Random();
            //for (int i = 0; i < 6; i++)
            //{
            //    validateCode += ran.Next(1, 9);
            //}
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(email.Title1, "2383477292@qq.com"));//发送方的邮箱地址
            message.To.Add(new MailboxAddress(email.phone, "2383477292@qq.com"));//需要发送给谁的邮箱地址
            message.Subject = email.Title2;//邮箱标题
            //html or plain
            var bodyBuilder = new BodyBuilder();
            bodyBuilder.HtmlBody = $"<h4>内容：{email.Content}<br><br><br>联系方式：{email.phone}</h4>";//正文
           // bodyBuilder.TextBody = "您的验证码为：" + validateCode;
            message.Body = bodyBuilder.ToMessageBody();
            try
            {
                using (var client = new MailKit.Net.Smtp.SmtpClient())
                {

                    client.ServerCertificateValidationCallback = (s, c, h, e) => true;
                    //smtp服务器，端口，是否开启ssl
                    client.Connect("smtp.qq.com", 465, true);
                    client.Authenticate("2383477292@qq.com", "uhdrnveoqqqrdhib");
                    client.Send(message);
                    client.Disconnect(true);
                }
                //添加反馈
                UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(s => s.Id == email.UserId);
                db.Feedback.Add(new Feedback { AddPerson = userInfo.TrueName, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), Contact = email.phone, Content = email.Content, IsDelete = 0, IsSolve = 0 });
                await db.SaveChangesAsync();

            }catch(Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("发送邮件失败,错误消息:" + e.Message + ",在哪里：" + e.StackTrace);
                return ApiResult.Error("发送失败");
            }
            return ApiResult.Success("发送成功");
        }

        //void Temp()
        //{
        //    var strHost = "邮件发送服务地址";
        //    var strPort ="邮箱发送端口";
        //    var sendEmail = "邮箱账号";
        //    var sendPwd = "密码/授权码";

        //    MimeMessage mailMessage = new MimeMessage();
        //    mailMessage.From.Add(new MailboxAddress(sendEmail));
        //    mailMessage.To.Add(new MailboxAddress(email));
        //    mailMessage.Subject = emaiTitle;

        //    BodyBuilder bodyBuilder = new BodyBuilder();
        //    bodyBuilder.HtmlBody = emailbody;
        //    //邮件主体内容
        //    mailMessage.Body = bodyBuilder.ToMessageBody();
        //    //指定smtp服务地址（根据发件人邮箱指定对应SMTP服务器地址）
        //    using (var smtpClient = new SmtpClient())
        //    {
        //        smtpClient.Connect(strHost, strPort, true);
        //        smtpClient.Authenticate(sendEmail, sendPwd);
        //        try
        //        {
        //            smtpClient.Send(mailMessage); //同步邮件发送
        //        }
        //        catch (Exception ex)
        //        {
        //            var error = _kitServices.IGetErrorMsg(ex, "邮件发送异常");
        //        }
        //        smtpClient.Disconnect(true);
        //        /* 异步执行
        //        await smtpClient.ConnectAsync(strHost, strPort, true);
        //        await smtpClient.AuthenticateAsync(sendEmail, sendPwd);
        //        try
        //           {
        //             await smtpClient.SendAsync(mailMessage); //同步邮件发送
        //          }
        //        catch (Exception ex)
        //        {
        //            var error = _kitServices.IGetErrorMsg(ex, "邮件发送异常");
        //        }
        //        await smtpClient.DisconnectAsync(true);
        //        */
        //    }

        //}
    }
}
