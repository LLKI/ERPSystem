﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using Models.models;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.userInfo
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class UserInfoController : ControllerBase
    {

        private IUserInfoBLL userBLL;
        public UserInfoController(IUserInfoBLL userBLL)
        {
            this.userBLL = userBLL;
        }
        /// <summary>
        /// 获取所有的用户信息
        /// </summary>
        /// <param name="usre"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> GetAllUsers([FromBody] UserSearchDTO search_user)
        {
            return await userBLL.GetAllUserInfo(search_user);
        }
        /// <summary>
        /// 重置密码
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ApiResult> ResertPwd(int id)
        {
            return await userBLL.ResetPwd(id);
        }

        /// <summary>
        /// 通过id获取用户的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("getUser/{id}")]
        public async Task<ApiResult> GetUserInfoById(int id)
        {
            return await userBLL.GetUserInfoById(id);
        }
        /// <summary>
        /// 删除用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ApiResult> DelUserById(int id)
        {
            return await userBLL.DelUserById(id);
        }
        /// <summary>
        /// 导出excel
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("export")]
        public async Task<ApiResult> ExportExcel(UserSearchDTO user)
        {
            return await userBLL.ExportExcel(user);
        }
        /// <summary>
        /// 导入excel
        /// </summary>
        /// <param name="user"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("import")]
        public async Task<ApiResult> ImportExcel([FromForm] UserDTO user,IFormFileCollection file)
        {
            return await userBLL.ImportExcel(user,file);
        }
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Add")]
        public async Task<ApiResult> Add(UserInfo user)
        {
            return await userBLL.Add(user);
        }
    }
}
