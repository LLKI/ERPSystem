﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using Models.models;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.menu
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class MenuController : ControllerBase
    {
        private IMenuBLL menuBLL;
        public MenuController(IMenuBLL menuBLL)
        {
            this.menuBLL = menuBLL;
        }
        /// <summary>
        /// 获取菜单
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet("{userId}")]
        public async Task<ApiResult> GetMenu(int userId)
        {
            return await menuBLL.GetMenu(userId);
        }
        /// <summary>
        /// 获取所有的菜单
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ApiResult> GetMenus()
        {
            return await menuBLL.GetMenus();
        }
        /// <summary>
        /// 通过id获取菜单的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("icon/{id}")]
        public async Task<ApiResult> GetMenuById(int id)
        {
            return await menuBLL.GetMenuById(id);
        }
        /// <summary>
        /// 修改菜单的信息
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> UpdateMenu([FromBody] Menu menu)
        {
            return await menuBLL.UpdateMenu(menu);
        }
        [HttpGet]
        [Route("son/{id}")]
        public async Task<ApiResult> GetSonMenuById(int id)
        {
            return await menuBLL.GetSonMenuById(id);
        }
        [HttpPost]
        [Route("add")]
        public async Task<ApiResult> AddMenu([FromBody] MenuDTO menu)
        {
            return await menuBLL.AddMenu(menu);
        }

	 [HttpDelete("{id}")]
        public async Task<ApiResult> Delete(int id)
        {
            return await menuBLL.DeleteMenu(id);
        }
    }
}
