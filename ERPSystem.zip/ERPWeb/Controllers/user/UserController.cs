﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.user
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class UserController : ControllerBase
    {
        private IUserBLL userBLL;
        public UserController(IUserBLL userBLL)
        {
            this.userBLL = userBLL;
        }
        /// <summary>
        /// 下载模板
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public  ApiResult Download()
        {
            return ApiResult.Success("下载成功",BaseUrl.SupplierExcelUrl + "用户信息表格(模板).xlsx");
        }
        // GET: api/<UserController>
        [HttpGet("{id}/{oldPwd}/{newPwd}")]
        public async Task<ApiResult> UpdatePwd(int id, string oldPwd, string newPwd)
        {
            return await userBLL.UpdatePwd(id, oldPwd, newPwd);
        }
        /// <summary>
        /// 发送验证码
        /// </summary>
        /// <param name="phone">旧手机</param>
        /// <param name="oldPhone">新手机</param>
        /// <returns></returns>
        [HttpGet("{phone}/{oldPhone}")]
        public async Task<ApiResult> SendCode(string phone,string oldPhone)
        {
            return await userBLL.SendCodeByUpdatePhone(phone,oldPhone);
        }
        // GET api/<UserController>/5
        [HttpGet("{key}")]
        public async Task<ApiResult> Get(string key)
        {
            return await userBLL.GetUserByKey(key);
        }
        /// <summary>
        /// 修改手机号
        /// </summary>
        /// <param name="id"></param>
        /// <param name="newPhone"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("setPhone/{id}/{newPhone}/{codeNum}")]
        public async Task<ApiResult> UpdatePhone(int id,string newPhone,string codeNum)
        {
            return await userBLL.UpdatePhone(id,newPhone,codeNum);
        }
        //修改用户的信息
        [HttpPost]
        public async Task<ApiResult> Post([FromBody] UserInfo user)
        {
            return await userBLL.UpdateUserById(user);
        }
        //修改用户头像
        [HttpPost]
        [Route("upload")]
        public async Task<ApiResult> UploadImg([FromForm] string account,IFormFileCollection file)
        {
             return await userBLL.UpdateUserAccountImgById(account, file);
        }

        //修改用户个人照片
        [HttpPost]
        [Route("upload/userImg")]
        public async Task<ApiResult> UploadImg([FromForm] int id, IFormFileCollection file)
        {
            return await userBLL.UplaodUserImg(id, file);
        }
        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
