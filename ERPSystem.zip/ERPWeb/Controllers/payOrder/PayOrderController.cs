﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.payOrder
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class PayOrderController : ControllerBase
    {
        private IPayOrderBLL payOrderBLL;
        public PayOrderController(IPayOrderBLL payOrderBLL)
        {
            this.payOrderBLL = payOrderBLL;
        }
        /// <summary>
        /// 获取所有的订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> GetAllOrders([FromBody] PayOrderDTO order)
        {
            return await payOrderBLL.GetAllOrder(order);
        }
        /// <summary>
        /// 通过id获取商品信息
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        [HttpGet("{orderId}")]
        public async Task<ApiResult> GetProById(int orderId)
        {
            return await payOrderBLL.GetProById(orderId);
        }
        /// <summary>
        /// 取消支付
        /// </summary>
        /// <param name="pay"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<ApiResult> CancelOrder([FromBody] PayOrderParamDTO pay)
        {
            return await payOrderBLL.CancelOrder(pay);
        }
        /// <summary>
        /// 删除订单
        /// </summary>
        /// <param name="pay"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("del")]
        public async Task<ApiResult> DelOrderById([FromBody] PayOrderParamDTO pay)
        {
            return await payOrderBLL.DelOrderById(pay);
        }
    }
}
