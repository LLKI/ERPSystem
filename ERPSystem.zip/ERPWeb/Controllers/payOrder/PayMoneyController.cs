﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using Alipay.AopSdk.AspnetCore;
using Aop.Api;
using Aop.Api.Domain;
using Aop.Api.Request;
using Aop.Api.Response;
using Models.Dto;
using System.Data;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Common;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Text;

namespace ERPWeb.Controllers.payOrder
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class PayMoneyController : ControllerBase
    {
        private IConfiguration Con;
        private IPayOrderBLL payOrderBLL;
        public PayMoneyController(IConfiguration Configuration, IPayOrderBLL payOrderBLL)
        {
            this.Con = Configuration;
            this.payOrderBLL = payOrderBLL;
        }
        /// <summary>
        /// 支付接口
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ApiResult SendAilPay([FromBody] PayMoneyDTO pay)
        {
            string privateKey = "MIIEpAIBAAKCAQEAlhlMBCPt9Be2J1z5GhFgHr5kgS3HQmvZ17lEgxucE6rNAXroTpIuEGWntcixZc0LpgWbbsmyEg71fA4ei1Tffr/5/U+nTsrSS/PYiu/7DWfMx2GJ1tiH43BPkFZlNndTghgZVBTjxKUpAUkjFZv+8WhnB4fWCxO07wmdUr0qTpv/IlKyHnkG1eAkRFDVi5M1yIB+ksa5n70VC8uouYwFWocnzGQGuRCHHwbMCqVRKe5yFT8Hi89IMeT3IlM4ZZiahu/ttDEiyUaSwjxUC8Qppmz97PtkWyu5HqIeZ/wPFZaNzpC0yulg86FGZKkhMUKwUoIRlRO2FjzE3/GB6OHHcwIDAQABAoIBAEY04ud03tIzXRIgXKuiwPDgYSZDAVbCF4zdrXwdp+1TELzGfm5x1XX59m4Cx2c0d2Rabw9s7AuiT5SNDiBhvIAOz6F6ZmlmWOMJ1Zl3Elh82r3Pk6eYdEcfuzdqEcFeIwNQvlgjxT2vevSM/woWgzLrgHV3Rdi8iP7d4mZW8Lj/ZmqJSILSm0+ifLvWqd7nqq00/MYcYgFVleb5+2xAR66Y86//VzuPh7u1RTIHLzQKexTMu7Xoc9hULXmtqSlmHZZ2BOXIquh3gVhLjoXhhgf3ztyyXCkvVxCRnyh4BsgKe0+vD9DXrXyFj9HEtZctMjgZtjK7Uy092Za2KVipF5ECgYEA9Qhw5FgkCA5poEDCK50xzOBNzA1Nxl1CGHfh/N9fcGVgLk1bKI1x4dNpE0q3ehFR8EsGsEwgLzhnXv+T2J60L34n/15fVrZVV+7XdJBa8YjOGKylI6t8xr8SBcW6vpvrogIuIiBqLJLRZFjnAJsDgDBR2u3Ougg0iQbh86NeQjUCgYEAnNEcjfyfZ2sqlTK2r38pfj7e0TprEccRlU0ck8xyd0UV2iM6lMFRfF0g8jIWe+PVfJn3zELwikt7tWIS+ubAA9dT+HVoXWj9iogxDglqbCpED2M8LD8DG9z6AmbmrQYGfWjrEgHOK+iHOVsTBen0FOoNOBpSFITyHNfggRHVGAcCgYEA7ZEFgx5BsN3oYsrmdsqtYemHA/NSGKSKVJbGsBkRuzNOkRXG8AZTB5OlKGMkiGEKhGL5VSw5eA7DikNY4IjeQb2aoeipnrShAeQ7WHQs+EifKSUZ5v94tmjB3H7ck7kwN57Ng6DRz+14vkXDkb65Iiu28P/nkk4qQUA/Cay20pECgYBrdejpa8oYZpnBsAT8clmOx6qNGkkw34evFi6VIa73CIKW/zkvouIiJPdkwOojb9dmEWR7twt62YsmmtSC1wmSGEbUpjAkgsPr4LQs+ErTYItPOCON9og82csBRl6hBtX/rpwXtOEBudCgf0aj8NRwWItCfNbudMQs+8o+6GdslQKBgQDUmVDeocZxpXKHl3vfwzmm6fmAnSX6ZuPCHRo2MDJwpuznnuF53XcUfAD6BKHLWIVWYo3fQ1wJNzkkIjxTEfocpxqF2ejV4FQAQJWE3lRH/mW12lti74F7Pqb9GwGaZWfvafU0R3diYNgT4iz8PLWnlUSJ9NdNy74Mta9E5e0+cA=="; // 应用私钥
            string alipayPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnI2Ip3qFj2h7SuSpurYXLBfNRX7kQH3GNIj9+MWYM9H+QeyORha7uNEurcHOWzBJBzVJyMqgDPZUkTvAVUBuf3COG9icojj7xsqjJIGiwEcxZ+hLDXY+wapOP6nGhrpwezmsWiNJg60NREg3mvQIZzu97Y8pVLc2ZZq/FJ1tnfVU9U5oBrr//GdWf27T3oMJwjE9iGQa74faKp5S6ISaTC+sDcUEJA4pNRbzQF2WvtpkaybudfaBABsyWBQ+0LTn7QmOnA3QCd+UZdvRWbmd4i529iHLdUoludANWRugsfmbHMPM+n4j6P3FgH9MKaKaMCBOXYrd1AzPbgRWTTL3+wIDAQAB";// 支付宝公钥

            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi-sandbox.dl.alipaydev.com/gateway.do"; // 支付宝网关地址

            alipayConfig.AppId = "9021000140642698"; // 沙箱环境中的AppId

            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";// 这里是一个坑(在线调试工具上是UTF8，在调试工具上可以调试通过，但是在VS里面却走不通，必须为UTF-8)

            alipayConfig.SignType = "RSA2";

            IAopClient alipayClient = new DefaultAopClient(alipayConfig);
            AlipayTradePagePayRequest request = new AlipayTradePagePayRequest();
            AlipayTradePagePayModel model = new AlipayTradePagePayModel();
            model.OutTradeNo = pay.ProNo; // 订单流水号
            model.TotalAmount = pay.Money; // 具体金额
            model.Subject = "商品";// 所交易的内容或者说是交易的物品
            model.ProductCode = "FAST_INSTANT_TRADE_PAY";
            request.SetReturnUrl("http://localhost:5000/api/payMoney/" + pay.ProNo + "/" + pay.UserId);
            request.SetBizModel(model);
            var data = request.GetBizModel();
            AlipayTradePagePayResponse response = alipayClient.pageExecute(request);
            if (!response.IsError)
            {
                return ApiResult.Success(response.Body);
            }
            else
            {
                return ApiResult.Error(response.Body);
            }
        }
        [HttpGet("{proNo}/{userId}")]
        public void GoToPage(string proNo, int userId)
        {
            //修改状态
            if (payOrderBLL.UpdateState(proNo, userId))
            {
                Response.Redirect("https://localhost:8080/#/payOrder");
            }
            else
            {
                Response.Redirect("https://localhost:8080/home");
            }


        }
    }
}
