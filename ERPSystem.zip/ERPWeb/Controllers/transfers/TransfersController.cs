﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.transfers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class TransfersController : ControllerBase
    {
        private ITransfersBLL TransfersBLL;
        public TransfersController(ITransfersBLL TransfersBLL)
        {
            this.TransfersBLL = TransfersBLL;
        }
        /// <summary>
        /// 获取所有的订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> GetAllOrders([FromBody] TransfersOrderDTO order)
        {
            return await TransfersBLL.GetAllOrder(order);
        }
        /// <summary>
        ///查看订单包含了哪些商品
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ApiResult> LookDetail(string id)
        {
            return await TransfersBLL.LookDetail(id);
        }
        /// <summary>
        /// 更改订单的审核状态
        /// </summary>
        /// <param name="audit"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("option")]
        public async Task<ApiResult> AuditOrder([FromBody] AuditOrderDTO audit)
        {
            return await TransfersBLL.AuditOrder(audit);
        }
        /// <summary>
        /// 删除订单
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpDelete("{id}/{userId}")]
        public async Task<ApiResult> DelOrderById(int id, int userId)
        {
            return await TransfersBLL.DelOrderById(id, userId);
        }
    }
}
