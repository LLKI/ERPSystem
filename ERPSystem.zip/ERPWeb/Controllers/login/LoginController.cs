﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.login
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private ILoginBLL _loginBLL;
        public LoginController(ILoginBLL loginBLL)
        {
            this._loginBLL = loginBLL;  
        }
        // GET: api/<LoginController>
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        /// <summary>
        ///  登录
        /// </summary>
        /// <param name="sccount"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        [HttpGet("{account}/{pwd}")]
        public Task<ApiResult> Get(string account,string pwd)
        {
            return _loginBLL.LoginByAccount(account, pwd);
        }


        // DELETE api/<LoginController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
