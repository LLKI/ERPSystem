﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using Models.models;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.product
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class ProductController : ControllerBase
    {
        private IProductBLL productBLL;
        public ProductController(IProductBLL pro)
        {
            this.productBLL = pro;
        }
        
        public ApiResult Download()
        {
            return ApiResult.Success("下载成功",BaseUrl.SupplierExcelUrl + "商品表格(模板).xlsx");
        }
 

        //修改状态
        [HttpGet("{id}/{state}")]
        public async Task<ApiResult> UpdateState(int id,int state)
        {
            return await productBLL.UpdateState(id, state);
        }
        //导出
        [HttpPost]
        [Route("export")]
        public async Task<ApiResult> Export([FromBody] ProductDTO pro)
        {
            return await productBLL.ExportData(pro);
        }
        //导入
        [HttpPost]
        [Route("import")]
        public async Task<ApiResult> Import( IFormFileCollection file, [FromForm] UserDTO userId)
        {
            return await productBLL.ImportData(file,userId);
        }
        [HttpPost]
        /// <summary>
        /// 获取所有的商品信息
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResult> GetAllProducts(ProductDTO pro)
        {
            return await productBLL.GetAllProducts(pro);
        }

        /// <summary>
        ///添加商品(不带图片)
        /// </summary>
        /// <returns></returns>
       [HttpPost]
        [Route("add")]
        public async Task<ApiResult> addProduct([FromBody] Product addPro)
        {
            return await productBLL.AddProduct(addPro);
        }
        /// <summary>
        ///添加商品（带图片）
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("add/img")]
        public async Task<ApiResult> AddProduct([FromForm] Product addPro,IFormFileCollection file)
        {
            return await productBLL.AddProduct(addPro,file);
        }
        /// <summary>
        /// 修改商品带图片
        /// </summary>
        /// <param name="addPro"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("update/img")]
        public async Task<ApiResult> UpdatePro([FromForm] Temp addPro,IFormFileCollection file)
        {
            return await productBLL.UpdateProHasImg(addPro,file);
        }  

        /// <summary>
        /// 通过id获取商品信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ApiResult> GetProductById(int id)
        {
            return await productBLL.GetProductById(id);
        }

        /// <summary>
        ///  退货
        /// </summary>
        /// <param name="back"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("back")]
        public async Task<ApiResult> BackPro(BackProDTO back)
        {
            return await productBLL.BackPro(back);
        }
        /// <summary>
        /// 修改商品不带图片
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<ApiResult> UpdateProNoImg([FromBody] Product pro)
        {
            return await productBLL.UpdateProNoImg(pro);
        }
        /// <summary>
        /// 删除商品
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ApiResult> DelProById(int id)
        {
            return await productBLL.DelProById(id);
        }

        [HttpPost]
        [Route("ids")]
        public async Task<ApiResult> GetProByIds([FromBody] ProDTO ids)
        {
           return await productBLL.GetProByIds(ids);
        }
        /// <summary>
        /// 商品出库
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("outpro")]
        public async Task<ApiResult> OutPro([FromBody] OutProDTO pro)
        {
            return await productBLL.OutPro(pro);
        }
        /// <summary>
        /// 商品调拨
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("transfers")]
        public async Task<ApiResult> TransfersPro(TransfersDTO pro)
        {
            return await productBLL.TransfersPro(pro);
        }
    }
}
