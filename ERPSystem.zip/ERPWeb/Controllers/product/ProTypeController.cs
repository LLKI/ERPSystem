﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.product
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class ProTypeController : ControllerBase
    {
        private IProTypeBLL proTypeBLL;
        public ProTypeController(IProTypeBLL proTypeBLL)
        {
            this.proTypeBLL = proTypeBLL;
        }

        //获取所有的商品类型
        [HttpGet]
        public async Task<ApiResult> Get()
        {
            return await proTypeBLL.GetAllProTypes();
        }

        //通过id获取商品类型
        [HttpGet("{id}")]
        public async Task<ApiResult> Get(int id)
        {
            return await proTypeBLL.GetProTypeById(id);
        }

        // POST api/<ProTypeController>
        [HttpPost]
        public async Task<ApiResult> Post([FromBody] ProType proType)
        {
            return await proTypeBLL.AddProType(proType);
        }

        //修改类型的状态
        [HttpPut("{id}/{state}")]
        public async Task<ApiResult> UpdateState(int id,int state)
        {
            return await proTypeBLL.UpdateProTypeState(id,state);
        }
        //修改类型
        [HttpPut("{id}")]
        public async Task<ApiResult> UpdateProType(int id, [FromBody] ProType pro)
        {
            return await proTypeBLL.UpdateProType(id,pro);
        }



        // DELETE api/<ProTypeController>/5
        [HttpDelete("{id}")]
        public async Task<ApiResult> Delete(int id)
        {
            return await proTypeBLL.DelProType(id);
        }
    }
}
