﻿using BLL;
using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.product
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]    
    public class BrandController : ControllerBase
    {
        private IBrandBLL brandBLL;
        public BrandController(IBrandBLL brandBLL)
        {
            this.brandBLL = brandBLL;
        }
        [HttpGet]
        public async Task<ApiResult> GetAllBrands()
        {
            return await brandBLL.GetAllBrands();
        }
        //获取所有的商品品牌
        [HttpPost]
        public async Task<ApiResult> GetAllBrands([FromBody] BrandDTO search_brand)
        {
            return await brandBLL.GetAllBrands(search_brand);
        }

        //修改照片
        [HttpPost]
        [Route("update")]
        [EnableCors("CorsPolicy")]
        public async Task<ApiResult> Update([FromForm] Brand brand,IFormFileCollection file)
        {
            return await brandBLL.UploadBrandImg(brand, file);
        }
        //通过id获取品牌信息
        [HttpGet("{id}")]
        public async Task<ApiResult> Get(int id)
        {
            return await brandBLL.GetBrandById(id);
        }

        //// POST api/<BrandController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //修改品牌信息
        [HttpPut]
        public async Task<ApiResult> UpdateBrand([FromBody] Brand brand)
        {
            return await brandBLL.UpdateBrand(brand);
        }

        //修改品牌信息
        [HttpPut("{id}/{state}")]
        public async Task<ApiResult> UpdateBrand(int id,int state)
        {
            return await brandBLL.UpdateState(id, state);
        }

        //删除品牌
        [HttpDelete("{id}")]
        public async Task<ApiResult> Delete(int id)
        {
            return await brandBLL.DeleteBrandById(id);
        }


    }
}
