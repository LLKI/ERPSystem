﻿using Common;
using iTextSharp.text.pdf;
using iTextSharp.text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Text;
using Org.BouncyCastle.Asn1.BC;
using System;
using System.Threading.Tasks;
using System.Security.Policy;
using common;
using IBLL;

namespace ERPWeb.Controllers.log
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogFileController : ControllerBase
    {
        private IErrorBLL errorBLL;
        public LogFileController(IErrorBLL errorBLL)
        {
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 获取内容
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        [HttpGet("{name}/{sign}")]
        public async Task<ApiResult> GetErrorConent(string name,string sign)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            //要转换的文件的路径
            string path = BaseUrl.LogFilePath + sign + "\\" + name;
            //第一个参数是txt文件物理路径  Encoding.GetEncoding("utf-8")
            System.Collections.Generic.List<string> lines = new System.Collections.Generic.List<string>();
            string str;
            try
            {
                using FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using (var stream = new StreamReader(fs, Encoding.GetEncoding("GB2312")))
                {
                    while ((str=await stream.ReadLineAsync())!=null)
                    {
                        lines.Add(str);
                    }
                    //lines = System.IO.File.ReadAllLines(stream, Encoding.GetEncoding("GB2312"));
                }
                    
            }catch(Exception e) 
            {
                string err = e.Message;
                 await LogHelper.Error("转换为PDF文件时失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                //lines = new string[1];
                lines.Add("请重试");
            }
            if (lines.Count <= 0)
            {
                //lines=new string[1];
                lines.Add("无记录");
            }
            //iTextSharp.text.PageSize.A4    自定义页面大小
            Document doc = new Document(iTextSharp.text.PageSize.A4, 50, 20, 20, 20);
            string[] strings = name.Split(".");
            string logName = strings[0] + ".pdf";
            using(FileStream stream =new FileStream(BaseUrl.LogPdfPath + sign+"\\"+ logName, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                PdfWriter pdfwriter = PdfWriter.GetInstance(doc, stream);
                doc.Open();
                //创建我的基本字体
                BaseFont baseFont = BaseFont.CreateFont("C:\\WINDOWS\\FONTS\\STSONG.TTF", "Identity-H", false);// ("微软雅黑", "utf-8", false);
                                                                                                               //创建字体      字体大小，字体粗細    字体颜色
                Font font = new Font(baseFont, 12, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);

                Paragraph paragraph;

                foreach (string line in lines)
                {
                    paragraph = new Paragraph(line, font);
                    doc.Add(paragraph);
                }
                //关闭文件
                doc.Close();
            }

            return ApiResult.Success("成功",BaseUrl.LogPdfUrl+sign+"/"+logName);
        }
    }
}
