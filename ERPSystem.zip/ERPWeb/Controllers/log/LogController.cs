﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ERPWeb.Controllers.log
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogController : ControllerBase
    {
        private ILogBLL logBLL;
        public LogController(ILogBLL logBLL)
        {
            this.logBLL = logBLL;
        }
        [HttpGet]
        public ApiResult GetAllLogFiles()
        {
            return logBLL.GetAllLogFile();
        }
        /// <summary>
        /// 获取子文件夹的名称
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        [HttpGet("{name}")]
        public ApiResult GetCChildrenFile(string name)
        {
            return logBLL.GetChildernFile(name);
        }
    }
}
