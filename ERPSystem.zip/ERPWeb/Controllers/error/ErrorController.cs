﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.error
{
    [Route("api/[controller]")]
    [ApiController]
    public class ErrorController : ControllerBase
    {
        private IErrorBLL errorBLL;
        public ErrorController(IErrorBLL errorBLL)
        {
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 获取本周错误的次数
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ApiResult> GetErrorCount()
        {
            return await errorBLL.GetErrorCount();
        }
    }
}
