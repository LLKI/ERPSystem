﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using System.Threading.Tasks;

namespace ERPWeb.Controllers.feedbook
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors]
    public class FeedbackController : ControllerBase
    {

        private IFeedback feedbackBLL;
        public FeedbackController(IFeedback feedbackBLL)
        {
            this.feedbackBLL = feedbackBLL;
        }
        /// <summary>
        /// 获取所有的数据
        /// </summary>
        /// <param name="feed"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ApiResult> GetAllData([FromBody] FeedbackDTO feed)
        {
            return  await feedbackBLL.GetAllData(feed);
        }
        [HttpGet("{id}/{isSolve}")]
        public async Task<ApiResult> UpdateState(int id,int isSolve)
        {
            return await feedbackBLL.UpdateState(id, isSolve);
        }
        [HttpDelete("{id}")]
        public async Task<ApiResult> DelData(int id)
        {
            return await feedbackBLL.DelData(id);
        }
    }
}
