﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Dto;
using Models.models;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ERPWeb.Controllers.notify
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    public class NotifyController : ControllerBase
    {
        private readonly INotifyBLL notifyBLL;
        public NotifyController(INotifyBLL notifyBLL)
        {
            this.notifyBLL = notifyBLL;
        }
        // GET: api/<NotifyController>
        [HttpGet]
        [Route("all/{userId}")]
        public Task<ApiResult> GetAllContent(int userId)
        {
            return notifyBLL.GetAllContent(userId);
        }
        /// <summary>
        /// 获取所有的公告类型
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("type")]
        public ApiResult GetNoticeType()
        {
            return notifyBLL.GetAllType();
        }
        [HttpGet]
        [Route("type/{typeName}")]
        public ApiResult GetNotifyTypeByName(string typeName)
        {
            return notifyBLL.GetNotifyTypeByName(typeName);
        }
        /// <summary>
        /// 公告的详情
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET api/<NotifyController>/5
        [HttpGet("{id}")]
        public ApiResult Get(int id)
        {
            return notifyBLL.GetContentById(id);
        }
        /// <summary>
        /// 批量删除我的发布
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("self")]
        public async Task<ApiResult> DelMyNotifyBatch([FromBody] int[] ids)
        {
            return await notifyBLL.DelMyNotifyBatch(ids);
        }

        [HttpPost]
        [Route("self")]
        [EnableCors("CorsPolicy")]
        public ApiResult GetMyNotifys([FromBody] PageParams param)
        {
            return notifyBLL.GetMyNotifys(param);
        }
        // POST api/<NotifyController>
        [HttpPost]
       // [EnableCors("CorsPolicy")] //允许跨域
        public Task<ApiResult> Post([FromBody] Notice value)
        {
            return notifyBLL.AddNotify(value);
        }
        // POST api/<NotifyController>
        [HttpPost]
        [Route("upload")]
        [EnableCors("CorsPolicy")] //允许跨域
        public Task<ApiResult> Upload(IFormFileCollection files)
        {
            return notifyBLL.Upload(files);
        }
        [HttpGet]
        [Route("total/{id}")]
        public Task<ApiResult> PageCount(int id)
        {
            return notifyBLL.GetNotifyNum(id);
        }

        // PUT api/<NotifyController>/5
        [HttpPut]
        [Route("update/{id}")]
        public Task<ApiResult> Put(int id, [FromBody] Notice value)
        {
            return notifyBLL.UpdateNotifyById(id, value);
        }

        //删除公告
        [HttpDelete]
        [Route("delete/{id}")]
        public Task<ApiResult> Delete(int id)
        {
            return notifyBLL.DeleteNotifyById(id);
        }
        //获取统计的数据
        [HttpGet]
        [Route("count/{id}")]
        public async Task<ApiResult> GetCount(int id)
        {
            return await notifyBLL.GetCount(id);
        }
        /// <summary>
        /// 通过id获取公告的类型
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("notifyType/{id}")]
        public async Task<ApiResult> GetNotifyTypeById(int id)
        {
            return await notifyBLL.GetNotifyTypeById(id);
        }
        /// <summary>
        /// 修改公告类型
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("notifyType")]
        public async Task<ApiResult> UpdateNotifyType(NoticeType type)
        {
            return await notifyBLL.UpdateNotifyType(type);
        

        }
        /// <summary>
        /// 删除公告类型
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("notifyType/{id}")]
        public async Task<ApiResult> DelNotifyTypeById(int id)
        {
            return await notifyBLL.DelNotifyTypeById(id);
        }
    }
}
