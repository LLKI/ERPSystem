﻿using common;
using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using Models.returnData;
using OfficeOpenXml;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class UserInfoBLL : IUserInfoBLL
    {
        private ERPContext db;
        private IDepartmentBLL depaBLL;
        private IRolesBLL roleBLL;
        private IErrorBLL errorBLL;
        public UserInfoBLL(ERPContext db,IDepartmentBLL depaBLL, IRolesBLL roleBLL, IErrorBLL errorBLL)
        {
            this.db = db;
            this.depaBLL = depaBLL;
            this.roleBLL = roleBLL;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 通过id删除用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelUserById(int id)
        {
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == id);
            db.Entry(userInfo).State = EntityState.Modified;
            userInfo.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
        /// <summary>
        /// 导出excel
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> ExportExcel(UserSearchDTO user)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var package = new ExcelPackage();
            //表名称
            var worksheet = package.Workbook.Worksheets.Add("商品信息");
            //表头
            var headers = new string[] { "账号","姓名", "性别", "年纪", "手机号", "邮箱", "qq", "地址","部门","角色"};
            //worksheet.Cells.Style.ShrinkToFit = true;//单元格自动适应大小
            for (int i = 0; i < headers.Length; i++)
            {
                worksheet.Cells[1, i + 1].Value = headers[i];
                worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                worksheet.Row(i + 1).Height = 20;
                worksheet.Column(i + 1).Width = 26;
                //worksheet.Row(1).Height = 15;//设置行高
                //worksheet.Row(1).CustomHeight = true;//自动调整行高
                //worksheet.Column(1).Width = 15;//设置列宽
            }
            
            //获取数据
            ApiResult apiResult =await GetAllUserInfo(user);
            var products = apiResult.Data as UserInfoReturn;
            var list = products.MyList;
            // 支持各种直接获取数据的方法
            // worksheet.Cells.Load*...

            int row = 2;
            foreach (var item in list)
            {
                worksheet.Cells[row, 1].Value = item.Account;
                worksheet.Cells[row, 2].Value = item.TrueName;
                worksheet.Cells[row, 3].Value = item.Sex;
                worksheet.Cells[row, 4].Value = item.Age;
                worksheet.Cells[row, 5].Value = item.Phone;
                worksheet.Cells[row, 6].Value = item.Email;
                worksheet.Cells[row, 7].Value = item.Qq;
                worksheet.Cells[row, 8].Value = item.Address;
                worksheet.Cells[row, 9].Value = item.Department.DepaName;
                worksheet.Cells[row, 10].Value = item.Role.RoleName;
                row++;
            }
            try
            {
                string fileName = "用户信息表格.xlsx";
                // 通常做法是，将excel上传至对象存储，获取到下载链接，这里将其输出到项目根目录。
                using (FileStream stream = new FileStream(BaseUrl.SupplierExcelPath + fileName, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    await package.SaveAsAsync(stream);
                }
                package.Dispose();
                return ApiResult.Success("导出成功", BaseUrl.SupplierExcelUrl + fileName);
            }
            catch (Exception e)
            {
                await LogHelper.Error("导出用户信息表格时，发送错误，错误消息为：" + e.Message + "，在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("导出错误,请联系管理员");
            }
        }

        /// <summary>
        /// 获取所有的用户信息
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllUserInfo(UserSearchDTO user)
        {

            int count = 0;
            //没有条件
            List<UserInfo> users = new List<UserInfo>();
            if ( user.DepartmentId == 0&&user.RoleId==0)
            {
                users = await db.UserInfo.Include(u => u.Department).Include(u => u.Role).Where(u => u.Phone.Contains(user.Phone) && u.IsDelete == 0&& u.TrueName.Contains(user.UserName) && user.UserAccount.Contains(user.UserAccount)).Skip((user.PageIndex - 1) * user.PageSize).Take(user.PageSize).ToListAsync();
                count =await db.UserInfo.CountAsync(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && user.UserAccount.Contains(user.UserAccount)&&u.IsDelete==0);
            }else if(user.DepartmentId == 0 && user.RoleId != 0)
            {
                users = await db.UserInfo.Include(u => u.Department).Include(u => u.Role).Where(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && u.IsDelete == 0 && user.UserAccount.Contains(user.UserAccount)&&u.RoleId==user.RoleId).Skip((user.PageIndex - 1) * user.PageSize).Take(user.PageSize).ToListAsync();
                count = await db.UserInfo.CountAsync(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && user.UserAccount.Contains(user.UserAccount) && u.IsDelete == 0 && u.RoleId == user.RoleId);
            }else if (user.DepartmentId != 0 && user.RoleId == 0 )
            {
                users = await db.UserInfo.Include(u => u.Department).Include(u => u.Role).Where(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && u.IsDelete == 0 && user.UserAccount.Contains(user.UserAccount) && u.DepartmentId==user.DepartmentId).Skip((user.PageIndex - 1) * user.PageSize).Take(user.PageSize).ToListAsync();
                count = await db.UserInfo.CountAsync(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && user.UserAccount.Contains(user.UserAccount) && u.IsDelete == 0 && u.DepartmentId == user.DepartmentId);
            }else
            {
                users = await db.UserInfo.Include(u => u.Department).Include(u => u.Role).Where(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && u.IsDelete == 0 && user.UserAccount.Contains(user.UserAccount) && u.DepartmentId == user.DepartmentId&&u.RoleId==user.RoleId).Skip((user.PageIndex - 1) * user.PageSize).Take(user.PageSize).ToListAsync();
                count = await db.UserInfo.CountAsync(u => u.Phone.Contains(user.Phone) && u.TrueName.Contains(user.UserName) && user.UserAccount.Contains(user.UserAccount) && u.IsDelete == 0 && u.DepartmentId == user.DepartmentId && u.RoleId == user.RoleId);
            }

            return ApiResult.Success(new UserInfoReturn { Total=count,MyList=users});
        }
        /// <summary>
        /// 通过id获取用户信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetUserInfoById(int id)
        {
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == id&&u.IsDelete==0);
            if (userInfo == null)
                return ApiResult.Error("获取失败，请重试");
            return ApiResult.Success(userInfo);
        }
        /// <summary>
        /// 导入excel
        /// </summary>
        /// <param name="user"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> ImportExcel(UserDTO user, IFormFileCollection file)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var list = new List<UserInfo>();
           // decimal price = 0;
            UserInfo userInfo = await db.UserInfo.FirstOrDefaultAsync(u => u.Id == user.Id);
            using (var pack = new ExcelPackage(file[0].OpenReadStream()))
            {
                var sheet = pack.Workbook.Worksheets.First();
                int row = sheet.Dimension.Rows;
                int startRowNumber = sheet.Dimension.Start.Row + 1;
                int endRowNumber = sheet.Dimension.End.Row;
                int startColumn = sheet.Dimension.Start.Column;
                int endColumn = sheet.Dimension.End.Column;
                int i = 0;
                try
                {
                    // 循环获取整个Excel数据表数据
                    for (int currentRow = startRowNumber; currentRow <= endRowNumber; currentRow++)
                    {
                        string account = DateTime.Now.ToString("yyyyMMddHHss") + i;
                        if (i > 10)
                            i = 0;
                        if (sheet.Cells[currentRow, 1].Text == "")
                            break;
                        list.Add(new UserInfo
                        {
                            Account = account,
                            Addperson = userInfo.TrueName,
                            TrueName = sheet.Cells[currentRow, 1].Text,
                            Age = Convert.ToInt32(sheet.Cells[currentRow, 3].Text.Trim()),
                            Sex = sheet.Cells[currentRow, 2].Text,
                            Phone = sheet.Cells[currentRow, 4].Text,
                            Email = sheet.Cells[currentRow, 5].Text,
                            Qq = sheet.Cells[currentRow, 6].Text,
                            Address = sheet.Cells[currentRow, 7].Text,
                            DepartmentId = (await depaBLL.GetDepaByName(sheet.Cells[currentRow, 8].Text.Trim())).Id,
                            RoleId=(await roleBLL.GetRoleByName(sheet.Cells[currentRow,9].Text.Trim())).Id,
                            Remark = sheet.Cells[currentRow,10].Text.Trim(),
                            Pwd="111111",
                            AddTime=Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                            IsDelete=0,
                            NickName="erp"
                        });
                    }
                }
                catch (Exception e)
                {
                    await LogHelper.Error("导入用户表格时出错,错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                    await errorBLL.AddErrorData();
                    return ApiResult.Error("导入错误," + e.Message);
                }
            }
            //添加用户
            try
            {
                if (list.Count <= 0)
                    return ApiResult.Error("导入失败,请重试");
                await db.UserInfo.AddRangeAsync(list);
            }catch(Exception e)
            {
                await LogHelper.Error("导入用户表格时出错,错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("导入失败,请重试");
            }
            
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("导入成功") : ApiResult.Error("导入失败,请重试");
        }

        /// <summary>
        /// 重置密码
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> ResetPwd(int id)
        {
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == id);
            userInfo.Pwd = "111111";
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("重置密码成功") : ApiResult.Error("重置密码失败");
        }
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<ApiResult> Add(UserInfo userInfo)
        {
            string account = DateTime.Now.ToString("yyyyMMddHHss");
            db.UserInfo.Add(new UserInfo
            {
                Account = account,
                Addperson = userInfo.TrueName,
                TrueName = userInfo.TrueName,
                Age = userInfo.Age,
                Sex = userInfo.Sex,
                Phone = userInfo.Phone,
                Email = userInfo.Email,
                Qq = userInfo.Qq,
                Address = userInfo.Address,
                DepartmentId = userInfo.DepartmentId,
                RoleId = userInfo.RoleId,
                Remark = userInfo.Remark,
                Pwd = "111111",
                AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                IsDelete = 0,
                NickName = "erp"
            });
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }
    }
}
