﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using common;

namespace BLL
{
    public class BuyOrderBLL : IBuyOrderBLL
    {

        private ERPContext db;
        private IRolesBLL rolesBLL;
        private INotifyBLL notifyBLL;
        private IUserBLL userBLL;
        private IErrorBLL errorBLL;
        public BuyOrderBLL(ERPContext db, IRolesBLL rolesBLL, INotifyBLL notifyBLL, IUserBLL userBLL, IErrorBLL errorBLL)
        {
            this.db = db;
            this.rolesBLL = rolesBLL;
            this.notifyBLL = notifyBLL;
            this.userBLL = userBLL;
            this.errorBLL = errorBLL;
        }

        /// <summary>
        /// 添加订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task AddOrder(string cartId, decimal price, int userId)
        {

            BuyProductOrder order = new BuyProductOrder();
            order.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            order.AuditState = 0;
            //是否被管理员删除
            order.IsAdminDel = 0;
            //是否被用户删除
            order.IsUserDel = 0;
            //是否撤销
            order.IsBack = 0;
            order.TotalPrice = price;
            order.ProNo = Guid.NewGuid().ToString();
            order.CatId = cartId;
            order.UserId = userId;
            order.IsPay = 0;
            order.AddPerson = (await userBLL.GetUserById(userId)).TrueName;
            db.BuyProductOrder.Add(order);
            //添加公告：我的问题
            NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Sign == "MYNEWS");
            string content = $"<p>商品订单号为:<span  style='color:#E6A23C'>{order.ProNo}</span>的订单<span style='color:#E6A23C'>未审核</span></p>";
            await db.Notice.AddAsync(new Notice
            {
                AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                Content = content,
                IsDelete = 0,
                Title = "<span style='color:#E6A23C'>商品订单未审</span>",
                TypeId = noticeType.Id,
                UserId = userId
            });
        }
        /// <summary>
        /// 获取所有的订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllOrder(BuyOrderDTO order)
        {
            ApiResult apiResult = await rolesBLL.GetRoleById(order.UserId);
            Roles roles = apiResult.Data as Roles;
            //管理员可以看到所有的订单
            List<BuyProductOrder> or = null;
            int count = 0;
            if(roles.Sign != "ADMIN")
            {
                if (string.IsNullOrEmpty(order.Audio) && !string.IsNullOrEmpty(order.IsBack))
                {
                    or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo)&&b.UserId==order.UserId &&b.IsUserDel==0&&b.IsAdminDel == 0 && b.IsBack == Convert.ToInt32(order.IsBack)).OrderByDescending(p => p.AddTime).OrderByDescending(p => p.AuditTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    count =await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0 && b.IsBack == Convert.ToInt32(order.IsBack));
                }
                else if (!string.IsNullOrEmpty(order.Audio) && string.IsNullOrEmpty(order.IsBack))
                {
                    or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio)).OrderByDescending(p => p.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    if (order.Audio != "0")//未审
                    {
                        or = or.OrderByDescending(o => o.AuditTime).ToList();
                    }
                    count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio));
                }
                else if (!string.IsNullOrEmpty(order.Audio) && !string.IsNullOrEmpty(order.IsBack))
                {
                    or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio) && b.IsBack == Convert.ToInt32(order.IsBack)).OrderByDescending(p => p.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    if (order.Audio != "0")//未审
                    {
                        or = or.OrderByDescending(o => o.AuditTime).ToList();
                    }
                    count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio) && b.IsBack == Convert.ToInt32(order.IsBack));
                }
                else
                {
                    try
                    {
                        or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0).OrderByDescending(p => p.AddTime).OrderByDescending(p => p.AuditTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                        count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo) && b.UserId == order.UserId && b.IsUserDel == 0 && b.IsAdminDel == 0);
                    }
                    catch (Exception e)
                    {
                        string err = e.Message;
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(order.Audio) && !string.IsNullOrEmpty(order.IsBack))
                {
                    or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.IsAdminDel == 0 && b.IsBack == Convert.ToInt32(order.IsBack)).OrderByDescending(p => p.AddTime).OrderByDescending(p=>p.AuditTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    
                    count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo)&& b.IsAdminDel == 0 && b.IsBack == Convert.ToInt32(order.IsBack));
                }
                else if (!string.IsNullOrEmpty(order.Audio) && string.IsNullOrEmpty(order.IsBack))
                {
                    or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio)).OrderByDescending(p => p.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    if (order.Audio != "0")//未审
                    {
                        or = or.OrderByDescending(o => o.AuditTime).ToList();
                    }
                    
                    count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo) && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio));
                }
                else if (!string.IsNullOrEmpty(order.Audio) && !string.IsNullOrEmpty(order.IsBack))
                {
                    or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio) && b.IsBack == Convert.ToInt32(order.IsBack)).OrderByDescending(p => p.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    if (order.Audio != "0")//未审
                    {
                        or = or.OrderByDescending(o => o.AuditTime).ToList();
                    }
                    count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo)  && b.IsAdminDel == 0 && b.AuditState == Convert.ToInt32(order.Audio) && b.IsBack == Convert.ToInt32(order.IsBack));
                }
                else
                {
                    try
                    {
                        or = await db.BuyProductOrder.Where(b => b.ProNo.Contains(order.OrderNo) && b.IsAdminDel == 0).OrderByDescending(p => p.AddTime).OrderByDescending(p => p.AuditTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                        count = await db.BuyProductOrder.CountAsync(b => b.ProNo.Contains(order.OrderNo) && b.IsAdminDel == 0);
                    }
                    catch (Exception e)
                    {
                        string err = e.Message;
                    }
                }
            }
            return ApiResult.Success(new {myList=or,Total=count});
        }
        /// <summary>
        /// 通过购物车id查询商品信息
        /// </summary>
        /// <param name="proNo"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetProsByCatId(string catId)
        {
            string sql = "select pr.gotoAddress, pr.payTime,pr.transfersTime, pr.moveTime,pr.catId,pr.id,pr.color,pr.brandId,pr.proWeight,pr.size,pr.material,pr.proImg,pr.md5,pr.isenable,pr.isdelete,pr.takedown,pr.remark,pr.isEnough,pr.ackTime,pr.supplierId,pr.reservoirId,pr.isBackpro,pr.[proName],pr.[costPrice],pr.[price],pr.[stock],pr.[address],pr.[proType],pr.[isAudio],pr.[addPerson],pr.[addTime],pr.backNum,pr.backOrderId,pr.isBack from  product pr join procat c on pr.catid=c.id   where c.id=@cartId";
            try
            {
                List<Product> pros = await db.Product.FromSqlRaw<Product>(sql, new SqlParameter[]
               {
                new SqlParameter("@cartId",catId)
               }).ToListAsync();
                return ApiResult.Success(pros);
            }
            catch(Exception e)
            {
                string err = e.Message;
            }
            return null;
        }


        async Task<int> Option(int id, int userId, string remark, int state, string title, string content, int[] ids, string color)
        {
            List<int> userids = new List<int>();
            string orderId = "";
            //存放订单
            List<BuyProductOrder> buyProductOrder = new List<BuyProductOrder>();
            //存放商品
            List<Product> pros = new List<Product>();
            //操作的用户
            UserInfo userInfo = await userBLL.GetUserById(userId);
            int userid = 0;
            //批量操作
            if (ids != null && ids.Length > 0)
            {
                for (int i = 0; i < ids.Length; i++)
                {
                    try
                    {
                        //找出订单的信息
                        buyProductOrder.Add(await db.BuyProductOrder.FirstOrDefaultAsync(b => b.Id == ids[i]));
                    }
                    catch (Exception e)
                    {
                        //添加订单失败
                        await LogHelper.Error("添加采购订单失败,错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                        //添加错误的数量
                        await errorBLL.AddErrorData();
                        string err = e.Message;
                    }
                }
            }
            else
            {
                buyProductOrder.Add(await db.BuyProductOrder.FirstOrDefaultAsync(b => b.Id == id));
            }

            for (int i = 0; i < buyProductOrder.Count; i++)
            {
                //找出商品
                pros.AddRange(await db.Product.Where(p => p.CatId == buyProductOrder[i].CatId).ToListAsync());
                userids.Add(Convert.ToInt32(buyProductOrder[i].UserId));
                db.Entry(buyProductOrder[i]).State = EntityState.Modified;
                buyProductOrder[i].AuditState = state;
                buyProductOrder[i].AuditPersion = userInfo.TrueName;
                buyProductOrder[i].Remark = remark;
                buyProductOrder[i].AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                //if (buyProductOrder[i] == buyProductOrder[buyProductOrder.Count - 1])
                //{
                //    //最后一个数据，不加，
                //    orderId += buyProductOrder[i].ProNo;
                //}
                //else
                //{
                //    orderId += "</br>"+buyProductOrder[i].ProNo + "</br>";
                //}
            }
            //修改状态
            for (int i = 0; i < pros.Count(); i++)
            {
                pros[i].IsAudio = state;
                pros[i].AckTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            }
            userid = (await db.UserInfo.FirstOrDefaultAsync(p => p.TrueName == pros[0].AddPerson)).Id;


            //添加公告：我的问题
            //添加公告
            
            userids = userids.Distinct().ToList();
            for (int i = 0; i < userids.Count; i++)
            {
                List<string> proNos = new List<string>();
                List<BuyProductOrder> backProOrders = buyProductOrder.Where(o => o.UserId == userids[i]).ToList();
                if (backProOrders.Count <= 1)
                {
                    proNos.Add(backProOrders[0].ProNo);
                }
                else
                {
                    for (int p = 0; p < backProOrders.Count; p++)
                    {
                        proNos.Add(backProOrders[p].ProNo);
                    }
                }
                if (proNos.Count <= 1)
                {
                    orderId += proNos[0];
                }
                else
                {
                    for (int q = 0; q < proNos.Count; q++)
                    {
                        orderId+= "</br>" + proNos[i]+ "</br>";
                    }
                }
                //添加公告
                NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Sign == "MYNEWS");

                string contents = $"<p>商品订单号为:<span style='color:{color};'>{orderId}</span>的订单<span style='color:{color};'>{content}</span></p>";
                await db.Notice.AddAsync(new Notice
                {
                    AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                    Content = contents,
                    IsDelete = 0,
                    Title = title,
                    TypeId = noticeType.Id,
                    UserId = userids[i]
                });
            }


            
            //"<span style='color:#67C23A;'>商品审核通过<span>"
           

            //订单为审核通过 添加付款订单 
            //判断是否是批量操作
            if (state == 1)
            {
                
                if (ids == null || ids.Length <= 0)
                {
                    BuyProductOrder buyOrder = await db.BuyProductOrder.SingleOrDefaultAsync(b => b.Id == id);
                    //不是批量操作
                    db.PaymentOrder.Add(new PaymentOrder { BuyProductId = id, IsAdminDelete = 0, Id = 0, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), ButType = 1, IsAudit = 0, IsUserDelete = 0, ProNo = Guid.NewGuid().ToString(), TotalMoney = buyOrder.TotalPrice });
                    
                }
                else
                {
                    //批量操作
                    for (int i = 0; i < ids.Length; i++)
                    {
                        BuyProductOrder buyProductOrder1 = await db.BuyProductOrder.SingleOrDefaultAsync(p => p.Id == ids[i]);
                        await db.PaymentOrder.AddAsync(new PaymentOrder { BuyProductId = ids[i] ,IsAdminDelete = 0, Id = 0, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), ButType = 1, IsAudit = 0, IsUserDelete = 0, ProNo = Guid.NewGuid().ToString(), TotalMoney = buyProductOrder1.TotalPrice });
                    }
                }

                //修改商品状态 isAudit为4 代表：待付款
                for (int i = 0; i < pros.Count(); i++)
                {
                    pros[i].IsAudio =4;
                }
            }
            int t = 0;
            try
            {
                t=await db.SaveChangesAsync();
            }catch(Exception e)
            {
                string er = e.Message;
            }
            return t; 
        }

        /// <summary>
        /// 撤销订单
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <param name="remark"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UndoOrder(OrderStateDTO order)
        {
            string title = "<span style='color:#909399;'>商品订单已撤销<span>";
            if (order.Ids != null)
            {
                return await Option(order.Id, order.UserId, order.Remark, 3, title, "已撤销", order.Ids, "#909399") > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
            }

            return await Option(order.Id, order.UserId, order.Remark, 3, title, "已撤销", null, "#909399") > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
        }

        /// <summary>
        /// 修改订单的状态 通过
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateStateById(OrderStateDTO order)
        {
            string title = "<span style='color:#67C23A;'>商品审核通过<span>";
            //批量
            if (order.Ids != null)
            {
                return await Option(order.Id, order.UserId, null, 1, title, "审核通过", order.Ids, "#67C23A") > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
            }
            return await Option(order.Id, order.UserId, null, 1, title, "审核通过", null, "#67C23A") > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
        }
        /// <summary>
        /// 修改订单的状态 驳回
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateStateToNoById(OrderStateDTO order)
        {
            string title = "<span style='color:#F56C6C;'>商品订单被驳回<span>";
            if (order.Ids != null)
            {
                return await Option(order.Id, order.UserId, order.Remark, 2, title, $"被驳回<br/><br/>驳回消息为:{order.Remark}", order.Ids, "#F56C6C") > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
            }
            return await Option(order.Id, order.UserId, order.Remark, 2, title, $"被驳回<br/><br/>驳回消息为:{order.Remark}", null, "#F56C6C") > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");


        }
        /// <summary>
        /// 通过id删除订单
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelOrderById(OrderStateDTO order)
        {
            //是否是管理员
            UserInfo userInfo = await db.UserInfo.Include(u => u.Role).FirstOrDefaultAsync(o => o.Id == order.UserId);
            int isUserDel = 0;
            int isAdminDel = 0;
            if (userInfo.Role.Sign == "ADMIN")
            {
                //是管理员
                isAdminDel = 1;
            }
            else
            {
                isUserDel = 1;
            }
            //批量操作
            if (order.Ids != null&&order.Ids.Length>0)
            {
                List<BuyProductOrder> orders = new List<BuyProductOrder>();
                for (int i = 0; i < order.Ids.Length; i++)
                {
                    orders.Add(await db.BuyProductOrder.SingleOrDefaultAsync(o => o.Id == order.Ids[i]));
                }
                for (int i = 0; i < orders.Count; i++)
                {
                    db.Entry(orders[i]).State = EntityState.Modified;
                    orders[i].IsAdminDel = isAdminDel;
                    orders[i].IsUserDel = isUserDel;
                }
            }
            else
            {
                //不是批量删除
                BuyProductOrder buyProductOrder = await db.BuyProductOrder.SingleOrDefaultAsync(o => o.Id == order.Id);
                db.Entry(buyProductOrder).State = EntityState.Modified;
                buyProductOrder.IsAdminDel = isAdminDel;
                buyProductOrder.IsUserDel = isUserDel;
            }


            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
    }
}
