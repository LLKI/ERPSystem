﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class SonMenuBLL : ISonMenuBLL
    {
        private ERPContext db;
        public SonMenuBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 添加菜单
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddSonMenu(SonMenu menu)
        {
            db.SonMenu.Add(new SonMenu { AddTime=Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), Icon=menu.Icon, IsDelete=0, MenuName=menu.MenuName, ParentId=menu.ParentId, Remark=menu.Remark, Url=menu.Url});
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }
        /// <summary>
        /// 删除菜单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelMenuById(int id)
        {
            SonMenu sonMenu = await db.SonMenu.SingleOrDefaultAsync(s => s.IsDelete == 0 && s.Id == id);
            db.Entry(sonMenu).State = EntityState.Modified;
            sonMenu.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 通过id获取菜单信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetSonMenuById(int id)
        {
            return ApiResult.Success( await db.SonMenu.SingleOrDefaultAsync(s => s.Id == id));
        }
        /// <summary>
        /// 修改菜单
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        public async Task<ApiResult> UpdateMenu(SonMenu menu)
        {
            SonMenu sonMenu = await  db.SonMenu.SingleOrDefaultAsync(s => s.Id == menu.Id&&s.IsDelete==0);
            db.Entry(sonMenu).State = EntityState.Modified;
            sonMenu.MenuName = menu.MenuName;
            sonMenu.Remark = menu.Remark;
            sonMenu.Url = menu.Url;
            sonMenu.Icon = menu.Icon;
            sonMenu.ParentId = menu.ParentId;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }
    }
}
