﻿using common;
using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using Models.returnData;
using OfficeOpenXml;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ProductBLL : IProductBLL
    {


        private ERPContext db;
        private IBrandBLL brandBLL;
        private ISupplierBLL supplierBLL;
        private ICartBLL cartBLL;
        private IBuyOrderBLL buyOrderBLL;
        private IErrorBLL errorBLL;
        public ProductBLL(ERPContext db, IBrandBLL brandBLL, ISupplierBLL supplierBLL, ICartBLL cartBLL, IBuyOrderBLL buyOrderBLL,IErrorBLL errorBLL)
        {
            this.db = db;
            this.brandBLL = brandBLL;
            this.supplierBLL = supplierBLL;
            this.cartBLL = cartBLL;
            this.buyOrderBLL = buyOrderBLL;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 获取所有的商品信息
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllProducts(ProductDTO pro)
        {
            List<Product> products = null;
            int state = 0;
            int audio = 0;
            int total = 0;
            if (pro.IsEnable != "")
                state = pro.IsEnable == "启用" ? 0 : 1;
            if (pro.IsAudio != "")
            {
                switch (pro.IsAudio)
                {
                    case "未审核":
                        audio = 0;
                        break;
                    case "已通过":
                        audio = 1;
                        break;
                    case "待付款":
                        audio = 4;
                        break;
                    case "未通过":
                        audio = 2;
                        break;
                    case "已撤销":
                        audio = 3;
                        break;
                    case "已付款":
                        audio = 5;
                        break;
                    case "取消支付":
                        audio = 6;
                        break;
                    case "待退货":
                        audio = 7;
                        break;
                    case "已退货":
                        audio = 8;
                        break;
                }
            }
            if (pro.IsEnable == "" && pro.IsAudio == "")
            {
                try
                {
                    products = await db.Product.Include(p => p.Brand).Include(p => p.Supplier).Where(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0).OrderByDescending(p=>p.AddTime)
                   .Skip((pro.PageIndex - 1) * pro.PageSize).Take(pro.PageSize).ToListAsync();
                    total = await db.Product.CountAsync(p=>p.IsDelete==0);
                }
                catch (Exception e)
                {
                    await LogHelper.Error("获取所有的商品失败,错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                    await errorBLL.AddErrorData();
                    string error = e.Message;
                }

            }
            else if (pro.IsEnable != "" && pro.IsAudio == "")
            {

                products = await db.Product.Include(p => p.Brand).Include(p => p.Supplier).
                    Where(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0 && p.IsEnable == state).OrderByDescending(p => p.AddTime)
                    .Skip((pro.PageIndex - 1) * pro.PageSize).Take(pro.PageSize).ToListAsync();
                total =await db.Product.CountAsync(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0 && p.IsEnable == state);
            }
            else if (pro.IsAudio != "" && pro.IsEnable == "")
            {
                products = await db.Product.Include(p => p.Brand).Include(p => p.Supplier).
                    Where(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0 && p.IsAudio == audio).OrderByDescending(p => p.AddTime)
                    .Skip((pro.PageIndex - 1) * pro.PageSize).Take(pro.PageSize).ToListAsync();
                total = await db.Product.CountAsync(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0 && p.IsAudio == audio);
            }
            else
            {
                products = await db.Product.Include(p => p.Brand).Include(p => p.Supplier).
                    Where(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0 && p.IsAudio == audio && p.IsEnable == state).OrderByDescending(p => p.AddTime)
                   .Skip((pro.PageIndex - 1) * pro.PageSize).Take(pro.PageSize).ToListAsync();
                total = await db.Product.CountAsync(p => p.ProName.Contains(pro.ProName) && p.AddPerson.Contains(pro.AddPerson) && p.IsDelete == 0 && p.IsAudio == audio && p.IsEnable == state);
            }
            if (products != null)
            {
                for (int i = 0; i < products.Count; i++)
                {
                    products[i].ProImg = BaseUrl.ProductImgUrl + products[i].ProImg;
                }
            }
            return ApiResult.Success(new ProPageReturn { Total=total,Products=products});
        }
        /// <summary>
        /// 获取商品的详情
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<ApiResult> GetProductById(int id)
        {
            Product product = await db.Product.Include(p => p.Brand).Include(p => p.Supplier).Include(p => p.Reservoir).SingleOrDefaultAsync(p => p.Id == id && p.IsDelete == 0);
            product.ProImg = BaseUrl.ProductImgUrl + product.ProImg;
            BuyProductOrder buyProductOrder = await db.BuyProductOrder.Include(b => b.PaymentOrder).Where(p => p.CatId == product.CatId).FirstOrDefaultAsync();
            
            return ApiResult.Success(new {Products=product,Order=buyProductOrder});
        }
        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="isAudio"></param>
        /// <returns></returns>
        public async Task<ApiResult> GetProducts(int isAudio)
        {
            return ApiResult.Success(await db.Product.Include(p => p.Supplier).Include(p => p.Brand).Include(p => p.Reservoir).Where(p => p.IsAudio == 0).ToListAsync());
        }
        /// <summary>
        /// 添加商品带默认图片
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        public async Task<ApiResult> AddProduct(Product pro)
        {
            //购物车id
            string id = Guid.NewGuid().ToString();
            decimal price = (Convert.ToDecimal(pro.CostPrice) * Convert.ToDecimal((pro.Stock).Split("-")[0]));
            pro.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            pro.ProImg = "no.jpg";
            pro.IsEnough = 0;
            string address = pro.Address.Split(">")[0];
            Reservoir reservoir = await db.Reservoir.SingleOrDefaultAsync(p => p.ReservoirName == address);
            pro.ReservoirId = reservoir.Id;
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == pro.Id);
            pro.AddPerson = userInfo.TrueName;
            pro.Id = 0;
            pro.CatId = id;
            pro.IsAudio = 0;
            pro.Address = pro.Address;

            //添加购物车
            ProCat cart = new ProCat()
            {
                Id = id
            };
            try
            {
                //添加购物车
                cartBLL.AddCart(cart);
                //添加商品信息
                db.Product.Add(pro);
                //添加订单
                await buyOrderBLL.AddOrder(id, price, userInfo.Id);
            }
            catch (Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("添加购物车、订单、商品信息时失败,错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("导入失败");
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }
        /// <summary>
        /// /修改状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateState(int id, int state)
        {
            Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == id && p.IsDelete == 0);
            db.Entry(product).State = EntityState.Modified;
            product.IsEnable = state;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("更新成功", state) : ApiResult.Error("更新失败");
        }
        /// <summary>
        /// 导出
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> ExportData(ProductDTO pro)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var package = new ExcelPackage();
            //表名称
            var worksheet = package.Workbook.Worksheets.Add("商品信息");
            //表头
            var headers = new string[] { "商品名称", "商品类型", "颜色", "品牌名称", "成本", "售价", "重量", "大小", "材料", "库存", "供应商", "存放位置", "备注", "采购人" };
            //worksheet.Cells.Style.ShrinkToFit = true;//单元格自动适应大小
            for (int i = 0; i < headers.Length; i++)
            {
                worksheet.Cells[1, i + 1].Value = headers[i];
                worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                worksheet.Row(i + 1).Height = 20;
                worksheet.Column(i + 1).Width = 26;
                //worksheet.Row(1).Height = 15;//设置行高
                //worksheet.Row(1).CustomHeight = true;//自动调整行高
                //worksheet.Column(1).Width = 15;//设置列宽
            }

            //获取数据
            ApiResult apiResult = await GetAllProducts(pro);
            var products = apiResult.Data as ProPageReturn;
            var list = products.Products;

            // 支持各种直接获取数据的方法
            // worksheet.Cells.Load*...

            int row = 2;
            foreach (var item in list)
            {
                worksheet.Cells[row, 1].Value = item.ProName;
                worksheet.Cells[row, 2].Value = item.ProType;
                worksheet.Cells[row, 3].Value = item.Color;
                worksheet.Cells[row, 4].Value = item.Brand.BrandName;
                worksheet.Cells[row, 5].Value = item.CostPrice + "元";
                worksheet.Cells[row, 6].Value = item.Price + "元";
                worksheet.Cells[row, 7].Value = item.ProWeight + "KG";
                worksheet.Cells[row, 8].Value = item.Size;
                worksheet.Cells[row, 9].Value = item.Material;
                worksheet.Cells[row, 10].Value = item.Stock;
                worksheet.Cells[row, 11].Value = item.Supplier.SupplierName;
                worksheet.Cells[row, 12].Value = item.Address;
                worksheet.Cells[row, 13].Value = item.Remark;
                worksheet.Cells[row, 14].Value = item.AddPerson;
                row++;
            }
            try
            {
                string fileName = "商品表格.xlsx";
                // 通常做法是，将excel上传至对象存储，获取到下载链接，这里将其输出到项目根目录。
                using (FileStream stream = new FileStream(BaseUrl.SupplierExcelPath + fileName, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    await package.SaveAsAsync(stream);
                }
                package.Dispose();
                return ApiResult.Success("导出成功", BaseUrl.SupplierExcelUrl + fileName);
            }
            catch (Exception e)
            {
                await LogHelper.Error("导出商品表格时，发送错误，错误消息为：" + e.Message + "，在哪里：" + e.StackTrace);
                //添加错误的数量
                await errorBLL.AddErrorData();
                return ApiResult.Error("导出错误,请联系管理员");
            }
        }

        /// <summary>
        /// 导入
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public async Task<ApiResult> ImportData(IFormFileCollection file,UserDTO userId)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var list = new List<Product>();
            decimal price = 0;
            string id = Guid.NewGuid().ToString();
            UserInfo userInfo = await db.UserInfo.FirstOrDefaultAsync(u => u.Id == userId.Id);
            using (var pack = new ExcelPackage(file[0].OpenReadStream()))
            {
                var sheet = pack.Workbook.Worksheets.First();
                int row = sheet.Dimension.Rows;
                int startRowNumber = sheet.Dimension.Start.Row + 1;
                int endRowNumber = sheet.Dimension.End.Row;
                int startColumn = sheet.Dimension.Start.Column;
                int endColumn = sheet.Dimension.End.Column;
                try
                {
                    // 循环获取整个Excel数据表数据
                    for (int currentRow = startRowNumber; currentRow <= endRowNumber; currentRow++)
                    {
                        string reservoir = sheet.Cells[currentRow, 12].Text.Split(">")[0];
                        if (sheet.Cells[currentRow, 1].Text == "")
                            break;
                        //总价钱
                        price += (Convert.ToDecimal(sheet.Cells[currentRow, 5].Text)*Convert.ToDecimal((sheet.Cells[currentRow, 10].Text).Split("-")[0]));
                        list.Add(new Product
                        {
                            ProName = sheet.Cells[currentRow, 1].Text,
                            ProType = sheet.Cells[currentRow, 2].Text,
                            Color = sheet.Cells[currentRow, 3].Text,
                            BrandId = (await brandBLL.GetBrandIdByName(sheet.Cells[currentRow, 4].Text)),
                            CostPrice = Convert.ToDecimal(sheet.Cells[currentRow, 5].Text),
                            Price = Convert.ToDecimal(sheet.Cells[currentRow, 6].Text),
                            ProWeight = Convert.ToDecimal(sheet.Cells[currentRow, 7].Text),
                            Size = Convert.ToDecimal(sheet.Cells[currentRow, 8].Text),
                            Material = sheet.Cells[currentRow, 9].Text,
                            Stock = sheet.Cells[currentRow, 10].Text,
                            SupplierId = await supplierBLL.GetSupplierIdByName(sheet.Cells[currentRow, 11].Text),
                            Address = sheet.Cells[currentRow, 12].Text,
                            IsEnable = 0,
                            IsEnough = 0,
                            AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                            Remark = sheet.Cells[currentRow, 13].Text,
                            AddPerson = userInfo.TrueName,
                            IsAudio = 0,//0为未审
                            ReservoirId = (await db.Reservoir.SingleOrDefaultAsync(p => p.ReservoirName == reservoir)).Id,
                            CatId = id,
                            ProImg = "no.jpg",
                            IsDelete = 0,
                        });
                    }
                }
                catch (Exception e)
                {
                    await LogHelper.Error("导入商品表格时出错,错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                    await errorBLL.AddErrorData();
                    return ApiResult.Error("导入错误," + e.Message);
                }
            }
            //添加购物车
            ProCat cart = new ProCat()
            {
                Id = id
            };
            try
            {
                //添加购物车
                cartBLL.AddCart(cart);
                //添加商品信息
                await db.Product.AddRangeAsync(list);
                //添加订单
                await buyOrderBLL.AddOrder(id,price, userId.Id);
            }catch(Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("添加购物车、订单、商品信息时失败,错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("导入失败");
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("导入成功") : ApiResult.Error("导入失败");
        }
        /// <summary>
        /// 添加商品自带图片
        /// </summary>
        /// <param name="pro"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddProduct(Product pro, IFormFileCollection file)
        {

            //文件操作
            string fileName = null;
            IFormFile formFile = file[0];
            string extension = Path.GetExtension(formFile.FileName);
            //文件名称
            fileName = Guid.NewGuid().ToString() + extension;
            if (extension != ".jpg" && extension != ".png" && extension != ".jpeg" && extension != ".bmp" && extension != ".gif")
            {
                return ApiResult.Error("格式有误，请重新上传");
            }
            try
            {
                using (var stream = new FileStream(BaseUrl.ProductImgPath + fileName, FileMode.OpenOrCreate))
                {
                    await formFile.CopyToAsync(stream);
                }
            }
            catch (Exception e)
            {
                await LogHelper.Error("上传或者更换品牌图片时失败,错误消息:" + e.Message + ",在哪里:" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("上传失败，请重试");
            }
            //数据库操作
            //购物车id
            string id = Guid.NewGuid().ToString();
            //总金额
            decimal price = (Convert.ToDecimal(pro.CostPrice) * Convert.ToDecimal((pro.Stock).Split("-")[0]));
            pro.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            pro.ProImg = fileName;
            pro.IsEnough = 0;
            string address = pro.Address.Split(">")[0];
            Reservoir reservoir = await db.Reservoir.SingleOrDefaultAsync(p => p.ReservoirName == address);
            pro.ReservoirId = reservoir.Id;
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == pro.Id);
            pro.AddPerson = userInfo.TrueName;
            pro.Id = 0;
            pro.CatId = id;
            pro.IsAudio = 0;
            pro.Address = pro.Address;
            //添加购物车
            ProCat cart = new ProCat()
            {
                Id = id
            };
            try
            {
                //添加购物车
                 cartBLL.AddCart(cart);
                //添加商品信息
                db.Product.Add(pro);
                //添加订单
                await buyOrderBLL.AddOrder(id, price, userInfo.Id);
            }
            catch (Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("添加购物车、订单、商品信息时失败,错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("导入失败");
            }
            int v =0;
            try
            {
                v = await db.SaveChangesAsync();
            }catch(Exception e)
            {
                string error = e.Message;
            }


            return v > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }
      
        /// <summary>
        /// 退货
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> BackPro(BackProDTO back)
        {
            //订单号
            string proNo = Guid.NewGuid().ToString();
            decimal price = 0;
            int backNum = 0;
            //找出操作的用户
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(p => p.Id == back.UserId);
            //批量
            if (back.Ids.Length > 0&&back.Ids!= null)
            {
                
                for (int i = 0; i < back.Ids.Length; i++)
                {
                    //找出商品
                    Product product = await db.Product.FirstOrDefaultAsync(p => p.Id == back.Ids[i]);
                    if (product.Stock.Split("-")[0] == "0")
                    {
                        return ApiResult.Error("商品库存不足");
                    }
                    
                    db.Entry(product).State = EntityState.Modified;
                    if (product.IsBackPro != 0)
                        return ApiResult.Error("商品不支持退货");
                    //pros[i].IsBack = 1;
                    //pros[i].BackOrderId = proNo;
                    //退货数量 改
                    // pros[i].BackNum = back.BackNum;
                    //总数量
                    backNum += back.BackNums[i];
                    ///改
                   // pros[i].GotoAddress = back.GotoAddress;
                    //退款的总价
                    price += Convert.ToDecimal(back.BackNums[i]* product.CostPrice);
                    //减少库存
                    product.Stock = (Convert.ToInt32(product.Stock.Split("-")[0]) - back.BackNums[i]) + "-" + product.Stock.Split("-")[1];
                    
                    db.BackPro.Add(new Models.models.BackPro{ BackPerson = userInfo.TrueName, GotoAddress = back.GotoAddresses[i], Number = back.BackNums[i], ProId = back.Ids[i], ProNo = proNo });
                    if (product.Stock.Split("-")[0] == "0")
                        product.IsEnough = 1;
                    //if (back.Ids[i] == back.Ids[back.Ids.Length - 1])
                    //{
                    //    //最后一个数据，不加，
                    //    orderId += buyProductOrder[i].ProNo;
                    //}
                    //else
                    //{
                    //    orderId += "</br>" + buyProductOrder[i].ProNo + "</br>";
                    //}
                }
            }
            else
            {
                //不是批量
                //找出商品
                Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == back.Id);
                db.Entry(product).State = EntityState.Modified;
                if (product.IsBackPro != 0)
                    return ApiResult.Error("商品不支持退货");
                if (product.Stock.Split("-")[0] == "0")
                    return ApiResult.Error("商品库存不足");
                    //product.BackOrderId = proNo;
                    //product.BackNum = back.BackNum;
                    //product.GotoAddress = back.GotoAddress;
                    backNum = back.BackNum;
                //添加退货商品信息表
                db.BackPro.Add(new Models.models.BackPro { BackPerson = userInfo.TrueName, GotoAddress = back.GotoAddress, Number = back.BackNum, ProId = product.Id, ProNo = proNo });
                //退款的总价
                price = Convert.ToDecimal(backNum * product.CostPrice);
                product.Stock = (Convert.ToInt32(product.Stock.Split("-")[0]) - back.BackNum) + "-" + product.Stock.Split("-")[1];
                if (product.Stock.Split("-")[0]=="0")
                    product.IsEnough = 1;
            }
            try
            {
                //添加订单
                db.BackProOrder.Add(new BackProOrder { ProNo = proNo, AuditState = 0, BackPerson = userInfo.TrueName, Remark = back.Remark, TotalMoney = price, GotoAddress = back.GotoAddress, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), IsAdminDelete=0,IsUserDelete=0,BackNum=backNum , UserId=userInfo.Id});
                //发布公告
                //添加公告：我的问题
                string contents = $"<p>退货订单号为:<span style='color:#E6A23C;'>{proNo}</span>的订单<span style='color:#E6A23C;;'>未审核</span></p>";
                //"<span style='color:#67C23A;'>商品审核通过<span>"
                NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Sign == "MYNEWS");
                await db.Notice.AddAsync(new Notice
                {
                    AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                    Content = contents,
                    IsDelete = 0,
                    Title = "<span style='color:#E6A23C'>退货订单未审</span>",
                    TypeId = noticeType.Id,
                    UserId =userInfo.Id
                });
                return await db.SaveChangesAsync() > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
            }
            catch(Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("添加退货订单的时候失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("执行失败");
            }
            
        }
        /// <summary>
        /// 修改商品不带图片
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateProNoImg(Product pro)
        {
            Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == pro.Id);
            db.Entry(product).State = EntityState.Modified;
            string[] imgs= pro.ProImg.Split("/");
            string img = imgs[imgs.Length - 1];
            product.Color = pro.Color;
            product.CostPrice = pro.CostPrice;
            product.Price = pro.Price;
            product.Material = pro.Material;
            product.IsEnable = pro.IsEnable;
            product.ProName = pro.ProName;
            product.ProWeight = pro.ProWeight;
            product.Remark = pro.Remark;
            product.ProType = pro.ProType;
            product.Size = pro.Size;
            product.Stock = pro.Stock;
            product.SupplierId = pro.SupplierId;
            product.BrandId=pro.BrandId;
            product.IsBackPro = pro.IsBackPro;
            int i = 0;
            try
            {
                i = await db.SaveChangesAsync();
            }catch(Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("修改商品时失败,错误消息：" + e.Message + ",在哪里：" + e.StackTrace); ;
                await errorBLL.AddErrorData();
            }
            return i > 0 ? ApiResult.Success("更新成功") : ApiResult.Error("更新失败");
        }
        /// <summary>
        /// 修改商品带图片
        /// </summary>
        /// <param name="pro"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateProHasImg(Temp pro, IFormFileCollection file)
        {
            //文件操作
            string fileName = null;
            IFormFile formFile = file[0];
            string extension = Path.GetExtension(formFile.FileName);
            //文件名称
            fileName = Guid.NewGuid().ToString() + extension;
            if (extension != ".jpg" && extension != ".png" && extension != ".jpeg" && extension != ".bmp" && extension != ".gif")
            {
                return ApiResult.Error("格式有误，请重新上传");
            }
            try
            {
                using (var stream = new FileStream(BaseUrl.ProductImgPath + fileName, FileMode.OpenOrCreate))
                {
                    await formFile.CopyToAsync(stream);
                }
            }
            catch (Exception e)
            {
                await LogHelper.Error("上传或者更换品牌图片时失败,错误消息:" + e.Message + ",在哪里:" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("上传失败，请重试");
            }
            //旧图片
            string oldImg = (await db.Product.SingleOrDefaultAsync(p => pro.Id == p.Id)).ProImg;
            Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == pro.Id);
            db.Entry(product).State = EntityState.Modified;
            product.Color = pro.Color;
            product.CostPrice = pro.CostPrice;
            product.Price = pro.Price;
            product.Material = pro.Material;
            product.IsEnable = pro.IsEnable;
            product.ProName = pro.ProName;
            product.ProImg = fileName;
            product.ProWeight = pro.ProWeight;
            product.Remark = pro.Remark;
            product.ProType = pro.ProType;
            product.Size = pro.Size;
            product.Stock = pro.Stock;
            product.SupplierId = pro.SupplierId;
            product.BrandId = pro.BrandId;
            product.IsBackPro = pro.IsBackPro;
            int i = 0;
            try
            {
                if (oldImg != "no.jpg")
                {
                    //删除旧图片
                    File.Delete(BaseUrl.ProductImgPath + oldImg);
                }
            }catch(Exception e)
            {
                string err = e.Message;
            }
            try
            {
                i = await db.SaveChangesAsync();
            }
            catch (Exception e)
            {
                string err = e.Message;
            }
            return i > 0 ? ApiResult.Success("更新成功") : ApiResult.Error("更新失败");
        }
        /// <summary>
        /// 删除商品
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelProById(int id)
        {
            Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == id);
            db.Entry(product).State = EntityState.Modified;
            product.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
        /// <summary>
        /// 通过id数据获取商品
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetProByIds(ProDTO  ids)
        {
            List<Product> products = new List<Product>();
            if (ids.Ids.Length <= 0)
                return ApiResult.Error("没有数据");
            for (int i = 0; i < ids.Ids.Length; i++)
            {
                products.Add(await db.Product.Where(p => p.Id == ids.Ids[i] && p.IsDelete == 0).SingleOrDefaultAsync());
            }

            return ApiResult.Success(products);
            
        }
        /// <summary>
        /// 商品出库
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> OutPro(OutProDTO pro)
        {
            //不是批量
            //找出商品
            int backNum = 0;
            //订单号
            decimal price = 0;
            string proNo = Guid.NewGuid().ToString();
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == pro.UserId);
            Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == pro.Id);
            db.Entry(product).State = EntityState.Modified;
            if (product.Stock.Split("-")[0] == "0")
                return ApiResult.Error("商品库存不足");
            backNum = pro.BackNum;
            //添加出库商品信息表
            db.OutPro.Add(new OutPro { BackPerson = userInfo.TrueName, GotoAddress = pro.GotoAddress, Number = pro.BackNum, ProId = product.Id, ProNo = proNo });
            //出库的总价
            price = Convert.ToDecimal(backNum * product.CostPrice);
            //减少库存
            product.Stock = (Convert.ToInt32(product.Stock.Split("-")[0]) - pro.BackNum) + "-" + product.Stock.Split("-")[1];
            if (product.Stock.Split("-")[0] == "0")
                product.IsEnough = 1;

            try
            {
                //添加订单
                db.OutProOrder.Add(new OutProOrder { ProNo = proNo, AuditState = 0, OutPerson = userInfo.TrueName, Remark = pro.Remark, TotalMoney = price.ToString(), GotoAddress = pro.GotoAddress, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), IsAdminDelete = 0, IsUserDelete = 0, BackNum = backNum, UserId = userInfo.Id });
                //发布公告
                //添加公告：我的问题
                string contents = $"<p>出库订单号为:<span style='color:#E6A23C;'>{proNo}</span>的订单<span style='color:#E6A23C;;'>未审核</span></p>";
                //"<span style='color:#67C23A;'>商品审核通过<span>"
                NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Sign == "MYNEWS");
                await db.Notice.AddAsync(new Notice
                {
                    AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                    Content = contents,
                    IsDelete = 0,
                    Title = "<span style='color:#E6A23C'>出库订单未审</span>",
                    TypeId = noticeType.Id,
                    UserId = userInfo.Id
                });
                return await db.SaveChangesAsync() > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
            }
            catch (Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("添加出库订单的时候失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("执行失败");
            }
        }
    
        /// <summary>
        /// 调拨
        /// </summary>
        /// <param name="tra"></param>
        /// <returns></returns>
        public async Task<ApiResult> TransfersPro(TransfersDTO pro)
        {
            //不是批量
            //找出商品
            int backNum = 0;
            //订单号
            decimal price = 0;
            string proNo = Guid.NewGuid().ToString();
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == pro.UserId);

            Product product = await db.Product.SingleOrDefaultAsync(p => p.Id == pro.Id);
            db.Entry(product).State = EntityState.Modified;
            if (product.Stock.Split("-")[0] == "0")
                return ApiResult.Error("商品库存不足");
            backNum = pro.BackNum;
            string address = pro.OutAddress[0] + ">" + pro.OutAddress[1];
            //添加出库商品信息表
            db.TransfersPro.Add(new TransfersPro {  TransfersPerson= userInfo.TrueName, OutAddress = address, Number = pro.BackNum, ProId = product.Id, ProNo = proNo, InAddress=product.Address });
            //出库的总价
            price = Convert.ToDecimal(backNum * product.CostPrice);
            //减少库存
            product.Stock = (Convert.ToInt32(product.Stock.Split("-")[0]) - pro.BackNum) + "-" + product.Stock.Split("-")[1];
            if (product.Stock.Split("-")[0] == "0")
                product.IsEnough = 1;
            try
            {
                //添加订单
                db.TransfersOrder.Add(new TransfersOrder { ProNo = proNo, AuditState = 0, AddPerson= userInfo.TrueName, Remark = pro.Remark, TotalMoney= price, OutAddress = address, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), IsAdminDelete = 0, IsUserDelete = 0, Count = backNum, UserId= userInfo.Id });
                //发布公告
                //添加公告：我的问题
                string contents = $"<p>调拨订单号为:<span style='color:#E6A23C;'>{proNo}</span>的订单<span style='color:#E6A23C;;'>未审核</span></p>";
                //"<span style='color:#67C23A;'>商品审核通过<span>"
                NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Sign == "MYNEWS");
                await db.Notice.AddAsync(new Notice
                {
                    AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                    Content = contents,
                    IsDelete = 0,
                    Title = "<span style='color:#E6A23C'>调拨订单未审</span>",
                    TypeId = noticeType.Id,
                    UserId = userInfo.Id
                });
                return await db.SaveChangesAsync() > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
            }
            catch (Exception e)
            {
                string err = e.Message;
                await LogHelper.Error("添加调拨订单的时候失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("执行失败");
            }


        }
    }
}
