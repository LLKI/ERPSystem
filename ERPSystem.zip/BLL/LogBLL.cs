﻿using Common;
using IBLL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class LogBLL : ILogBLL
    {
        /// <summary>
        /// 获取所有的日志文件
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public ApiResult GetAllLogFile()
        {
            var list = Directory.EnumerateDirectories(BaseUrl.LogFilePath).ToList();
            List<string> li=new List<string>();
            List<string> parentList=new List<string>();
            for (int i = 0; i < list.Count; i++)
            {
                string[] strs = list[i].Split("\\");
                parentList.Add(strs[strs.Length - 1]);
            }
            foreach (var item in list)
            {
                li.AddRange(Directory.EnumerateFiles(item).ToList());
            }
            return ApiResult.Success(new {parent=parentList,children=li});
        }
        /// <summary>
        /// 获取父文件夹下的文件
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public ApiResult GetChildernFile(string name)
        {
            IEnumerable<string> enumerable;
            try
            {
                enumerable= Directory.EnumerateFiles(BaseUrl.LogFilePath + name);
            }catch(Exception e)
            {
                return ApiResult.Error("出现错了,"+e.Message);
            }
            
            List<string> names = new List<string>();
            foreach (var item in enumerable)
            {
                string[] strings = item.Split("\\");
                names.Add(strings[strings.Length - 1]);
            }
            return ApiResult.Success(names);
        }
    }
}
