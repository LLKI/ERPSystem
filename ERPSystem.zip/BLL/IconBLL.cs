﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class IconBLL : IIconBLL
    {

        public ERPContext db;
        public IconBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 获取所有的icon图标
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllIcon()
        {
            return ApiResult.Success(await db.Icon.ToListAsync());
        }
    }
}
