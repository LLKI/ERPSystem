﻿using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Redis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Models.Dto;
using Models.json;
using Models.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using common;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Models.redis;
using Microsoft.EntityFrameworkCore;

namespace BLL
{

    public class LoginBLL : ILoginBLL
    {
        private ERPContext _db;
        private IErrorBLL errorBLL;
        //private IOptions<RedisConfig> options;
        private RedisHelper rc;
        public LoginBLL(ERPContext db, RedisHelper rc, IErrorBLL errorBLL)
        {

            //this.options = options;
            _db = db;
            ////初始化redis对象的配置对象
            //RedisCacheOptions option = new RedisCacheOptions();
            ////配置连接的地址
            //option.Configuration = this.options.Value.Con;
            ////配置redis对象的别称
            //option.InstanceName = this.options.Value.Name;
            ////往redis对象传入配置对象
            //rc = new RedisCache(option);
            this.rc = rc;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 账号登录
        /// </summary>
        /// <param name="account"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> LoginByAccount(string account, string pwd)
        {
            await LogHelper.Info(account + "=====>正在登录.");
            if (string.IsNullOrEmpty(account) || string.IsNullOrEmpty(pwd))
            {
                return ApiResult.Error("用户名或密码不能为空");
            }
            byte[] bytes = await rc.GetValueAsync(account);
            if (bytes == null)
            {
                UserInfo userInfo = _db.UserInfo.Include(u => u.Department).Include(u => u.Role).SingleOrDefault(u => u.Account == account && u.Pwd == pwd && u.IsDelete == 0);
                if (userInfo == null)
                    return ApiResult.Error("登录失败,用户名或密码有误！");
                UserInfoDTO userDTO = new UserInfoDTO() { Account = userInfo.Account, Img = BaseUrl.AccountImgUrl + userInfo.AccountImg, Phone = userInfo.Phone, Id = userInfo.Id, NickName = userInfo.NickName };
                try
                {
                    userInfo.AccountImg = BaseUrl.AccountImgUrl + userInfo.AccountImg;
                    string userInfo_reids = JsonConvert.SerializeObject(userInfo);
                    await rc.SetValueAsync(userInfo.Account, userInfo_reids, TimeSpan.FromDays(1));
                }
                catch (Exception e)
                {
                    await LogHelper.Error(userInfo.TrueName + "=====>信息存入reid时失败,错误消息：" + e.Message + ",在那个地方：" + e.StackTrace);
                }
                await LogHelper.Info(userInfo.TrueName + "=====>信息存入redis成功，24小时过期");
                await LogHelper.Info(account + "=====>登录成功");
                return ApiResult.Success("登录成功", userDTO);
            }
            else
            {
                byte[] bytes1 = await rc.GetValueAsync(account);
                if (bytes1 == null)
                    return ApiResult.Error("登录失败,用户名或密码有误！");
                //获取对象
                UserInfo userInfo = JsonConvert.DeserializeObject<UserInfo>(Encoding.UTF8.GetString(bytes1));
                if (userInfo.Pwd != pwd || userInfo.Account != account)
                    return ApiResult.Error("登录失败,用户名或密码有误！");
                UserInfoDTO userDTO = new UserInfoDTO() { Account = userInfo.Account, Img = userInfo.AccountImg, Phone = userInfo.Phone, Id = userInfo.Id, NickName = userInfo.NickName };
                return ApiResult.Success("登录成功", userDTO);
                //存入redis
            }
        }
        
    }
}
