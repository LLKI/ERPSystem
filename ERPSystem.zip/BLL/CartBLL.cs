﻿using common;
using Common;
using IBLL;
using Models.models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class CartBLL : ICartBLL
    {
        private ERPContext db;
        private IErrorBLL errorBLL;
        public CartBLL(ERPContext db, IErrorBLL errorBLL)
        {
            this.db = db;
            this.errorBLL = errorBLL;
        }

        /// <summary>
        /// 添加购物车
        /// </summary>
        /// <param name="cat"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async void AddCart(ProCat cat)
        {
            try
            {
                cat.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:ss"));
                cat.IsDelete = 0;
                db.ProCat.Add(cat);
            }
            catch(Exception e)
            {
                await LogHelper.Error("添加购物车失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                //添加错误的数量
                await errorBLL.AddErrorData();
            }
        }
    }
}
