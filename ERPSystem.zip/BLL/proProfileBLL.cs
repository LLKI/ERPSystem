﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class proProfileBLL : IproProfileBLL
    {


        private ERPContext db;

        public proProfileBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 获取商品种类的数量
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetProTypeCount()
        {
            List<ProType> proTypes = await db.ProType.Where(p => p.IsDelete == 0).ToListAsync();
            Dictionary<string, int> map = new Dictionary<string, int>();
            for (int i = 0; i < proTypes.Count; i++)
            {
                int count = 0;
                List<Product> products = await db.Product.Where(p => p.ProType == proTypes[i].TypeName && p.IsDelete == 0&&p.IsAudio==5).ToListAsync();
                for (int j = 0; j < products.Count; j++)
                {
                    count +=Convert.ToInt32(products[j].Stock.Split("-")[0]);
                }
                map.Add(proTypes[i].TypeName, count);
            }

            return ApiResult.Success(map);
        }

        /// <summary>
        /// 获取所有的数据
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        //public async Task<ApiResult> GetAllData()
        //{
        //    List<Reservoir> reservoirs = await db.Reservoir.Include(r => r.Warehouse).Where(r => r.IsDelete == 0 && r.IsEnable == 0).ToListAsync();
        //    //仓库名称
        //    List<string> names = new List<string>();
        //    for (int i = 0; i < reservoirs.Count; i++)
        //    {
        //        string resName = reservoirs[i].ReservoirName;
        //        reservoirs[i].Warehouse = reservoirs[i].Warehouse.ToList();

        //        List<string> list = reservoirs[i].Warehouse.Select(w => w.HouseName).ToList();
        //        for (int j = 0; j < list.Count; j++)
        //        {
        //            names.Add(resName + ">" + list[j]);
        //        }
        //    }




        //}
    }
}
