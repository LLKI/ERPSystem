﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class OutOrderBLL : IOutOrderBLL
    {
        private ERPContext db;
        public IUserBLL userBLL;
        public OutOrderBLL(ERPContext db, IUserBLL userBLL)
        {
            this.db = db;
            this.userBLL = userBLL;
        }
        /// <summary>
        /// 获取所有的订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllOrder(OutOrderDTO order)
        {
            //当前登录的用户
            UserInfo userInfo = await userBLL.GetUserById(order.UserId);
            List<OutProOrder> orders = new List<OutProOrder>();
            int total = 0;
            if (userInfo.Role.Sign == "ADMIN")
            {
                //是管理员
                //未审
                if (order.State == 0 || order.State == 3)
                {
                    try
                    {
                        orders = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim())).OrderByDescending(u => u.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                        total = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim())).CountAsync();
                    }
                    catch (Exception e)
                    {
                        string ee = e.Message;
                    }

                }
                else
                {
                    orders = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim())).OrderByDescending(u => u.AddTime).OrderByDescending(u => u.AuditTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    total = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim())).CountAsync();
                }
            }
            else
            {
                //普通用户
                //未审
                if (order.State == 0 || order.State == 3)
                {
                    orders = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.UserId == userInfo.Id && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim()) && u.IsUserDelete == 0 && u.UserId == order.UserId).OrderByDescending(u => u.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    total = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.UserId == userInfo.Id && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim()) && u.IsUserDelete == 0).CountAsync();
                }
                else
                {

                    orders = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim()) && u.IsUserDelete == 0 && u.UserId == order.UserId).OrderByDescending(u => u.AddTime).OrderByDescending(u => u.AuditTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                    total = await db.OutProOrder.Where(u => u.IsAdminDelete == 0 && u.AuditState == order.State && u.ProNo.Contains(order.ProNo.Trim()) && u.IsUserDelete == 0).CountAsync();
                }
            }
            try
            {
                return ApiResult.Success(new { MyList = orders, Count = total });
            }
            catch (Exception e)
            {
                string er = e.Message;
            }
            return ApiResult.Error("失败");

        }
        /// <summary>
        /// 查看详情
        /// </summary>
        /// <param name="proNo"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> LookDetail(string proNo)
        {
            return ApiResult.Success(await db.OutPro.Include(b => b.Pro).Include(b => b.ProNoNavigation).Where(b => b.ProNo == proNo).ToListAsync());
            //return ApiResult.Success(await db.BackProOrder.Include(p => p.BackPro).Include(p => p.Product).SingleOrDefaultAsync(p=>p.ProNo==proNo&&p.IsUserDelete==0&&p.IsAdminDelete==0));
        }
        /// <summary>
        /// 审核订单
        /// </summary>
        /// <param name="audit"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AuditOrder(AuditOrderDTO audit)
        {

            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == audit.UserId);

            if (audit.Ids == null || audit.Ids.Length <= 0)
            {
                OutProOrder backProOrder = await db.OutProOrder.SingleOrDefaultAsync(b => b.Id == audit.Id);
                try
                {
                    db.Entry(backProOrder).State = EntityState.Modified;
                }
                catch (Exception e)
                {
                    string ewrr = e.Message;
                }
                backProOrder.AuditPerson = userInfo.TrueName;
                backProOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                backProOrder.Remark = audit.Remark;
                //state:1 通过、 2：驳回 、 3：撤销
                //未审
                if (audit.State == 1)
                {
                    //1为已审
                    backProOrder.AuditState = 1;
                    //添加公告
                    await AddNotify(new List<string> { backProOrder.ProNo }, "<span style='color:#67C23A;'>出货订单审核通过<span>", "审核通过", "#67C23A", Convert.ToInt32(backProOrder.UserId));

                }
                //驳回
                else if (audit.State == 2)
                {
                    //1为已审
                    backProOrder.AuditState = 2;
                    backProOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                    //添加公告
                    await AddNotify(new List<string> { backProOrder.ProNo }, "<span style='color:#F56C6C;'>出货订单被驳回<span>", $"出货订单被驳回<br/><br/>驳回消息为:{audit.Remark}", "#F56C6C", Convert.ToInt32(backProOrder.UserId));
                }
                else if (audit.State == 3)
                {
                    //1为已审
                    backProOrder.AuditState = 3;
                    backProOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                    //添加公告
                    await AddNotify(new List<string> { backProOrder.ProNo }, "<span style='color:#909399;'>出货订单已撤销<span>", "出货订单被撤销", "#909399", Convert.ToInt32(backProOrder.UserId));
                }
                if (audit.State == 2 || audit.State == 3)
                {
                    //回退商品的数量
                    List<OutPro> backPros = await db.OutPro.Include(b => b.Pro).Where(b => b.ProNo == backProOrder.ProNo).ToListAsync();
                    string stock = "";
                    for (int i = 0; i < backPros.Count; i++)
                    {
                        db.Entry(backPros[i].Pro).State = EntityState.Modified;
                        stock = (Convert.ToInt32(backPros[i].Pro.Stock.Split("-")[0]) + backPros[i].Number) + "-" + backPros[i].Pro.Stock.Split("-")[1];
                        backPros[i].Pro.Stock = stock;
                    }
                }
            }
            else
            {
                List<int> userid = new List<int>();
                List<OutProOrder> orders = new List<OutProOrder>();
                //批量操作
                if (audit.State == 1)
                {
                    //通过
                    for (int i = 0; i < audit.Ids.Length; i++)
                    {
                        OutProOrder backProOrder = await db.OutProOrder.SingleOrDefaultAsync(b => b.Id == audit.Ids[i]);
                        db.Entry(backProOrder).State = EntityState.Modified;
                        backProOrder.AuditPerson = userInfo.TrueName;
                        backProOrder.AuditState = 1;
                        backProOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));



                        userid.Add(Convert.ToInt32(backProOrder.UserId));
                        // proNos.Add(backProOrder.ProNo);
                        orders.Add(backProOrder);
                    }
                    userid = userid.Distinct().ToList();
                    for (int i = 0; i < userid.Count; i++)
                    {
                        List<string> proNos = new List<string>();
                        List<OutProOrder> backProOrders = orders.Where(o => o.UserId == userid[i]).ToList();
                        if (backProOrders.Count <= 1)
                        {
                            proNos.Add(backProOrders[0].ProNo);
                        }
                        else
                        {
                            for (int t = 0; t < backProOrders.Count; t++)
                            {
                                proNos.Add(backProOrders[t].ProNo);
                            }
                        }
                        //添加公告
                        await AddNotify(proNos, "<span style='color:#67C23A;'>出货订单审核通过<span>", "审核通过", "#67C23A", userid[i]);
                    }

                }
                else if (audit.State == 2)
                {
                    //批量驳回
                    for (int i = 0; i < audit.Ids.Length; i++)
                    {
                        OutProOrder backProOrder = await db.OutProOrder.SingleOrDefaultAsync(b => b.Id == audit.Ids[i]);
                        db.Entry(backProOrder).State = EntityState.Modified;
                        backProOrder.AuditPerson = userInfo.TrueName;
                        backProOrder.Remark = audit.Remark;
                        backProOrder.AuditState = 2;
                        backProOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));

                        userid.Add(Convert.ToInt32(backProOrder.UserId));
                        orders.Add(backProOrder);
                        //proNos.Add(backProOrder.ProNo);
                    }
                    userid = userid.Distinct().ToList();
                    for (int i = 0; i < userid.Count; i++)
                    {
                        List<string> proNos = new List<string>();
                        List<OutProOrder> backProOrders = orders.Where(o => o.UserId == userid[i]).ToList();
                        if (backProOrders.Count <= 1)
                        {
                            proNos.Add(backProOrders[0].ProNo);
                        }
                        else
                        {
                            for (int t = 0; t < backProOrders.Count; t++)
                            {
                                proNos.Add(backProOrders[t].ProNo);
                            }
                        }
                        //添加公告
                        await AddNotify(proNos, "<span style='color:#F56C6C;'>出货订单被驳回<span>", $"出货订单被驳回<br/><br/>驳回消息为:{audit.Remark}", "#F56C6C;", userid[i]);
                    }
                    //添加公告
                    //await AddNotify(proNos, "<span style='color:#F56C6C;'>退货订单被驳回<span>", $"退货订单被驳回<br/><br/>驳回消息为:{audit.Remark}", "#67C23A", audit.UserId);

                }
                else if (audit.State == 3)
                {
                    //批量撤销
                    //通过
                    for (int i = 0; i < audit.Ids.Length; i++)
                    {
                        OutProOrder backProOrder = await db.OutProOrder.SingleOrDefaultAsync(b => b.Id == audit.Ids[i]);
                        db.Entry(backProOrder).State = EntityState.Modified;
                        backProOrder.AuditPerson = userInfo.TrueName;
                        backProOrder.AuditState = 3;
                        backProOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                        //  proNos.Add(backProOrder.ProNo);
                        userid.Add(Convert.ToInt32(backProOrder.UserId));
                        orders.Add(backProOrder);

                    }
                    userid = userid.Distinct().ToList();
                    for (int i = 0; i < userid.Count; i++)
                    {
                        List<string> proNos = new List<string>();
                        List<OutProOrder> backProOrders = orders.Where(o => o.UserId == userid[i]).ToList();
                        if (backProOrders.Count <= 1)
                        {
                            proNos.Add(backProOrders[0].ProNo);
                        }
                        else
                        {
                            for (int t = 0; t < backProOrders.Count; t++)
                            {
                                proNos.Add(backProOrders[t].ProNo);
                            }
                        }
                        //添加公告
                        await AddNotify(proNos, "<span style='color:#909399;'>出货订单被撤销<span>", $"出货订单被撤销<br/>", "#909399", userid[i]);
                    }
                    //添加公告
                    // await AddNotify(proNos, "<span style='color:#909399;'>退货订单被撤销<span>", $"退货订单被撤销<br/>", "#909399", audit.UserId);
                }
                if (audit.State == 2 || audit.State == 3)
                {
                    //返回库存
                    //回退商品的数量
                    for (int i = 0; i < audit.Ids.Length; i++)
                    {
                        OutProOrder backProOrder = await db.OutProOrder.SingleOrDefaultAsync(b => b.Id == audit.Ids[i]);
                        List<OutPro> backPros = await db.OutPro.Include(b => b.Pro).Where(b => b.ProNo == backProOrder.ProNo).ToListAsync();
                        string stock = "";
                        for (int j = 0; j < backPros.Count; j++)
                        {
                            db.Entry(backPros[j].Pro).State = EntityState.Modified;
                            stock = (Convert.ToInt32(backPros[j].Pro.Stock.Split("-")[0]) + backPros[j].Number) + "-" + backPros[j].Pro.Stock.Split("-")[1];
                            backPros[j].Pro.Stock = stock;
                        }
                    }

                }

            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");

        }
        /// <summary>
        /// 添加公告
        /// </summary>
        /// <returns></returns>
        async Task AddNotify(List<string> proNos, string title, string content, string color, int userId)
        {
            string proNo = "";
            for (int i = 0; i < proNos.Count; i++)
            {
                if (proNos[i] == proNos[proNos.Count - 1])
                {
                    proNo += proNos[i];
                }
                else
                {
                    proNo += "</br>" + proNos[i] + "</br>";
                }
            }

            //添加公告：我的问题
            string contents = $"<p>商品订单号为:<span style='color:{color};'>{proNo}</span>的订单<span style='color:{color};'>{content}</span></p>";
            //"<span style='color:#67C23A;'>商品审核通过<span>"
            NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Sign == "MYNEWS");
            await db.Notice.AddAsync(new Notice
            {
                AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")),
                Content = contents,
                IsDelete = 0,
                Title = title,
                TypeId = noticeType.Id,
                UserId = userId
            });
        }
        /// <summary>
        /// 删除订单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelOrderById(int id, int userId)
        {
            OutProOrder backProOrder = await db.OutProOrder.SingleOrDefaultAsync(b => b.Id == id);
            db.Entry(backProOrder).State = EntityState.Modified;
            UserInfo userInfo = await userBLL.GetUserById(userId);
            if (userInfo.Role.Sign == "ADMIN")
            {
                backProOrder.IsAdminDelete = 1;
            }
            else
            {
                backProOrder.IsUserDelete = 1;
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
    }
}
