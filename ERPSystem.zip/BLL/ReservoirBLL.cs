﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ReservoirBLL : IReservoirBLL
    {
        private ERPContext db;
        public ReservoirBLL(ERPContext db)
        {
            this.db = db;   
        }
        /// <summary>
        /// 添加库区
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddReservoir(Reservoir res)
        {
            res.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            Reservoir reservoir = await db.Reservoir.SingleOrDefaultAsync(r => r.ReservoirName == res.ReservoirName);
            if (reservoir != null)
                return ApiResult.Error("添加失败，库区名不能重复");
            db.Reservoir.Add(res);
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }

        /// <summary>
        /// 获取所有的库区
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResult> GetAllReservoirs()
        {
            return ApiResult.Success(await db.Reservoir.Where(r=>r.IsDelete==0).OrderByDescending(r=>r.AddTime).ToListAsync());
        }
        /// <summary>
        /// 通过id修改状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateStateById(int id, int state)
        {
            Reservoir reservoir = db.Reservoir.SingleOrDefault(r => r.Id == id && r.IsDelete == 0);
            db.Entry(reservoir).State = EntityState.Modified;
            reservoir.IsEnable = state;
            db.Reservoir.Update(reservoir);
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }


 /// <summary>
        /// 删除库区
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<ApiResult> DeleteReservoir(int id)
        {
            Reservoir reservoir = await db.Reservoir.Where(s => s.Id == id).FirstOrDefaultAsync();
            db.Entry(reservoir).State = EntityState.Deleted;
            db.Remove(reservoir);
            return await db.SaveChangesAsync() >= 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
        /// <summary>
        /// 修改库区
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateReservoir(Reservoir res)
        {
            Reservoir reservoir = await db.Reservoir.Where(s => s.Id == res.Id).FirstOrDefaultAsync();
            reservoir.Remark = res.Remark;
            reservoir.ReservoirName = res.ReservoirName;
            reservoir.IsEnable = res.IsEnable;
            db.Entry(reservoir).State = EntityState.Modified;
            return await db.SaveChangesAsync() >= 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");

        }


        /// <summary>
        /// 通过Id获取数据
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<ApiResult> GetDataById(int id)
        {
            Reservoir reservoir = await db.Reservoir.Where(s => s.Id ==id).FirstOrDefaultAsync();
            return ApiResult.Success(reservoir);
        }
    }
}
