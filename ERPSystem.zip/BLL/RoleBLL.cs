﻿using common;
using Common;
using IBLL;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class RoleBLL : IRolesBLL
    {
        public ERPContext db;
        private IErrorBLL errorBLL;
        public RoleBLL(ERPContext db, IErrorBLL errorBLL)
        {
            this.db = db;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 添加角色
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddRole(RoleDTO role)
        {
            //首先添加角色
            try
            {
                db.Roles.Add(new Roles { AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), IsDelete = 0, IsEnable = 0, RoleName = role.RoleName, Sign = role.Sign });
                if (await db.SaveChangesAsync() < 0)
                    return ApiResult.Error("添加失败");
                int id = db.Roles.Max(p => p.Id);
                for (int i = 0; i < role.MenuIds.Length; i++)
                {
                    db.MenuRelaRoles.Add(new MenuRelaRoles { MenuId = role.MenuIds[i], RoleId = id });
                }
            }
            catch(Exception e)
            {
                await LogHelper.Error("添加角色时失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
            }
            
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");

        }
        /// <summary>
        /// 删除角色
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelRoleByid(int id)
        {
            Roles roles = await db.Roles.SingleOrDefaultAsync(r => r.Id == id);
            db.Entry(roles).State = EntityState.Modified;
            roles.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }


        /// <summary>
        /// 通过角色id获取菜单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetMenuByRoleId(int id)
        {
            return ApiResult.Success(await db.MenuRelaRoles.Include(m => m.Menu).Include(m=>m.Role).Where(m => m.RoleId == id).ToListAsync());
        }

        /// <summary>
        /// 通过用户id获取角色
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetRoleById(int userId)
        {
            string sql = "select r.[id], r.[roleName], r.[isEnable], r.[isDelete], r.[addTime], r.[sign] from roles r join userInfo u on r.id=u.roleId where u.id=@userId";
            Roles r = null;
            try
            {
                 r = await db.Roles.FromSqlRaw(sql, new SqlParameter[]
            {
                 new SqlParameter("@userId",userId)
            }).SingleOrDefaultAsync();
            }catch(Exception e)
            {
                await LogHelper.Error("通过id获取角色失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                string err = e.Message;
            }
            

            return ApiResult.Success(r);
        }
        /// <summary>
        /// 通过名称获取角色
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<Roles> GetRoleByName(string roleName)
        {
            return await db.Roles.SingleOrDefaultAsync(r => r.RoleName == roleName.Trim());
        }

        /// <summary>
        /// 获取所有的角色
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetRoles()
        {
            return ApiResult.Success(await db.Roles.Where(u => u.IsDelete == 0&&u.IsEnable==0).ToListAsync());
        }
        /// <summary>
        /// 修改角色
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateRole(RoleDTO role)
        {
            //修改
            if (role.Id != 0)
            {
                Roles roles = await db.Roles.SingleOrDefaultAsync(r => r.Id == role.Id);
                List<MenuRelaRoles> menuRelaRoles = await db.MenuRelaRoles.Where(m => m.RoleId == role.Id).ToListAsync();
                //先移除 后添加
                db.MenuRelaRoles.RemoveRange(menuRelaRoles);
                try
                {
                    roles.RoleName = role.RoleName;
                    for (int i = 0; i < role.MenuIds.Length; i++)
                    {
                        db.MenuRelaRoles.Add(new MenuRelaRoles { MenuId = role.MenuIds[i], RoleId = role.Id });
                    }
                }catch(Exception e)
                {
                    await LogHelper.Error("用户在更新角色的时候失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                   await  errorBLL.AddErrorData();
                    return ApiResult.Error("更新失败,请重试");
                }
            }
            else
            {
                //添加
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("更新成功") : ApiResult.Error("更新失败");
        }
    }
}
