﻿using AlibabaCloud.SDK.Dysmsapi20170525.Models;
using common;
using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BrandBLL : IBrandBLL
    {

        private ERPContext db;
        private IErrorBLL errorBLL;
        public BrandBLL(ERPContext db, IErrorBLL errorBLL)
        {
            this.db = db;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 通过id删除品牌
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DeleteBrandById(int id)
        {
            try
            {
                Brand brand = await db.Brand.SingleOrDefaultAsync(b => b.IsDelete == 0 && b.Id == id);
                db.Entry(brand).State = EntityState.Modified;
                brand.IsDelete = 1;
                //删除图片
                File.Delete(BaseUrl.BrandImgPath + brand.Img);
            }
            catch (Exception e)
            {
                await LogHelper.Error("删除商品品牌时出错，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                //添加错误的数量
                await errorBLL.AddErrorData();
                return ApiResult.Error("删除失败");
            }

            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 获取所有的品牌
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllBrands(BrandDTO bra)
        {
            List<Brand> brands = null;
            int state = 0;
            if (bra.IsEnable != "")
            {
                state = bra.IsEnable == "启用" ? 0 : 1;
            }

            if (bra.Type == "" && bra.IsEnable == "")
                brands = await db.Brand.Include(b => b.ProType).Where(b => b.IsDelete == 0 && b.BrandName.Contains(bra.BrandName)).Skip((bra.PageIndex - 1) * bra.PageSize).Take(bra.PageSize).OrderByDescending(b => b.AddTime).ToListAsync();
            else if (bra.Type == "" && bra.IsEnable != "")
                brands = await db.Brand.Include(b => b.ProType).Where(b => b.IsDelete == 0 && b.BrandName.Contains(bra.BrandName) && b.IsEnable == state).Skip((bra.PageIndex - 1) * bra.PageSize).Take(bra.PageSize).OrderByDescending(b => b.AddTime).ToListAsync();
            else if (bra.Type != "" && bra.IsEnable == "")
                brands = await db.Brand.Include(b => b.ProType).Where(b => b.IsDelete == 0 && b.BrandName.Contains(bra.BrandName) && b.ProType.TypeName == bra.Type).Skip((bra.PageIndex - 1) * bra.PageSize).Take(bra.PageSize).OrderByDescending(b => b.AddTime).ToListAsync();
            else
                brands = await db.Brand.Include(b => b.ProType).Where(b => b.IsDelete == 0 && b.BrandName.Contains(bra.BrandName) && b.ProType.TypeName == bra.Type && b.IsEnable == state).Skip((bra.PageIndex - 1) * bra.PageSize).Take(bra.PageSize).OrderByDescending(b => b.AddTime).ToListAsync();
            if (brands.Count > 0)
            {
                for (int i = 0; i < brands.Count; i++)
                {
                    brands[i].Img = BaseUrl.BrandImgUrl + brands[i].Img;
                }
            }
            
            return ApiResult.Success(brands);
        }
        /// <summary>
        /// 获取所有的品牌，不带参数
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllBrands()
        {
            return ApiResult.Success(await db.Brand.Where(b => b.IsDelete == 0&&b.IsEnable==0).ToListAsync());
        }

        /// <summary>
        /// 通过id获取品牌的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetBrandById(int id)
        {
            Brand brand = await db.Brand.SingleOrDefaultAsync(b => b.Id == id && b.IsDelete == 0);
            brand.Img = BaseUrl.BrandImgUrl + brand.Img;
            return ApiResult.Success(brand);
        }
        /// <summary>
        /// 通过品牌名称获取id
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<int> GetBrandIdByName(string text)
        {
            Brand brand = await db.Brand.SingleOrDefaultAsync(b => b.BrandName == text&&b.IsDelete==0&&b.IsEnable==0);

            return brand.Id;
        }

        /// <summary>
        /// 修改品牌信息
        /// </summary>
        /// <param name="brand"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateBrand(Brand brand)
        {
            Brand bra = await db.Brand.SingleOrDefaultAsync(b => b.Id == brand.Id && b.IsDelete == 0);
            db.Entry(bra).State = EntityState.Modified;
            bra.Remark = brand.Remark;
            bra.BrandName = brand.BrandName;
            bra.ProTypeId = brand.ProTypeId;
            bra.IsEnable = brand.IsEnable;
            string[] str = brand.Img.Split("/");
            bra.Img = str[str.Length - 1];
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("更新成功") : ApiResult.Error("更新失败");
        }
        /// <summary>
        /// 修改状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateState(int id, int state)
        {
            Brand brand = await db.Brand.SingleOrDefaultAsync(b => b.Id == id && b.IsDelete == 0);
            db.Entry(brand).State = EntityState.Modified;
            brand.IsEnable = state;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("更新成功") : ApiResult.Error("更新失败");
        }

        /// <summary>
        /// 添加或者修改品牌
        /// </summary>
        /// <param name="id"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UploadBrandImg(Brand brand, IFormFileCollection file)
        {
            string fileName = "";
            if (file == null)
            {
                fileName = brand.Img;
            }
            else
            {
                IFormFile formFile = file[0];
                string extension = Path.GetExtension(formFile.FileName);
                //文件名称
                fileName = Guid.NewGuid().ToString() + extension;
                if (extension != ".jpg" && extension != ".png" && extension != ".jpeg" && extension != ".bmp" && extension != ".gif")
                {
                    return ApiResult.Error("格式有误，请重新上传");
                }
                try
                {
                    using (var stream = new FileStream(BaseUrl.BrandImgPath + fileName, FileMode.OpenOrCreate))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
                catch (Exception e)
                {
                    await LogHelper.Error("上传或者更换品牌图片时失败,错误消息:" + e.Message + ",在哪里:" + e.StackTrace);
                    //添加错误的数量
                    await errorBLL.AddErrorData();
                    return ApiResult.Error("上传失败，请重试");
                }
            }
            //格式无误
            //首先上传到服务器
            try
            {
                //更新数据库
                if (brand.Id == -1)
                {
                    brand.Id = 0;
                    brand.Img = fileName;
                    brand.AddTime = Convert.ToDateTime(Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")));
                    //添加
                    await db.Brand.AddAsync(brand);
                    return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
                }
                else
                {

                    Brand bra = await db.Brand.SingleOrDefaultAsync(b => b.Id == brand.Id && b.IsDelete == 0);
                    string imgName = bra.Img;
                    db.Entry(bra).State = EntityState.Modified;
                    bra.Remark = brand.Remark;
                    bra.BrandName = brand.BrandName;
                    bra.ProTypeId = brand.ProTypeId;
                    bra.IsEnable = brand.IsEnable;
                    bra.Img = fileName;
                    if (await db.SaveChangesAsync() > 0)
                    {
                        //删除之前的图片
                        try
                        {
                            File.Delete(BaseUrl.BrandImgPath + imgName);
                        }catch(Exception e)
                        {
                            return ApiResult.Error(e.Message);
                        }
                        return ApiResult.Success("更新成功");
                    }
                    else
                    {
                        return ApiResult.Error("更新失败");
                    }
                }
            }
            catch (Exception e)
            {
                await LogHelper.Error("上传或者更换品牌图片时失败,错误消息:" + e.Message + ",在哪里:" + e.StackTrace);
                //添加错误的数量
                await errorBLL.AddErrorData();
                return ApiResult.Error("上传失败，请重试");
            }
        }
    }
}
