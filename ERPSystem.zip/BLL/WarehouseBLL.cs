﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class WarehouseBLL : IWarehouseBLL
    {

        private ERPContext db;
        public WarehouseBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 添加库房
        /// </summary>
        /// <param name="warehouse"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddWarehouse(Warehouse warehouse)
        {
            await db.Warehouse.AddAsync(warehouse);
            warehouse.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            return await db.SaveChangesAsync()>0?ApiResult.Success("添加成功"):ApiResult.Error("添加失败");
        }
        /// <summary>
        /// 通过id删除库房
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelWarehouseById(int id)
        {
            Warehouse warehouse = await db.Warehouse.FirstOrDefaultAsync(w => w.Id == id && w.IsDelete == 0);
            db.Entry(warehouse).State = EntityState.Modified;
            warehouse.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 获取所有的库区名称
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllReservorys(int state)
        {
            return ApiResult.Success(await db.Reservoir.Where(w=>w.IsDelete==0&&w.IsEnable==state).OrderByDescending(r=>r.AddTime).ToListAsync());
        }
        /// <summary>
        /// 获取所有的库区信息
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResult> GetAllReservorys()
        {
            List<Reservoir> reservoirs = await db.Reservoir.Include(w => w.Warehouse).Where(w => w.IsDelete == 0 && w.IsEnable == 0).ToListAsync();
            for (int i = 0; i < reservoirs.Count; i++)
            {
                reservoirs[i].Warehouse=reservoirs[i].Warehouse.Where(w => w.IsEnable == 0).ToList();
            }
            return ApiResult.Success(reservoirs);
        }
        /// <summary>
        /// 获取所有的库房信息
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllWareHouse()
        {
             return ApiResult.Success(await db.Warehouse.Include(w=>w.Reservoir).OrderByDescending(w=>w.AddTime).Where(w => w.IsDelete == 0).ToListAsync());
        }
        /// <summary>
        /// 获取库房通过库区的id
        /// </summary>
        /// <param name="resId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetReservoirsById(int resId)
        {
            return ApiResult.Success(await db.Warehouse.Where(w => w.ReservoirId == resId).ToListAsync());
        }

        /// <summary>
        /// 通过id获取库房的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetWarehouseById(int id)
        {
            return ApiResult.Success(await db.Warehouse.Include(w=>w.Reservoir).FirstOrDefaultAsync(w => w.Id == id&&w.IsDelete==0));
        }

        /// <summary>
        /// 根据id修改库房的状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateStateById(int id, int state)
        {
            Warehouse wareHouse =await db.Warehouse.SingleOrDefaultAsync(w => w.Id == id && w.IsDelete == 0);
            wareHouse.IsEnable = state;
            db.Entry(wareHouse).State = EntityState.Modified;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }
        /// <summary>
        /// 修改库房信息
        /// </summary>
        /// <param name="warehouse"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateWarehouse(Warehouse warehouse)
        {
            Warehouse house = await db.Warehouse.FirstOrDefaultAsync(w => w.Id == warehouse.Id&&w.IsDelete==0);
            db.Entry(house).State = EntityState.Modified;
            house.Remark = warehouse.Remark;
            house.IsEnable = warehouse.IsEnable;
            house.ReservoirId = warehouse.ReservoirId;
            house.HouseName = warehouse.HouseName;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }
    }
}
