﻿using common;
using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using OfficeOpenXml.Style;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class PayOrderBLL : IPayOrderBLL
    {

        private ERPContext db;
        private IRolesBLL rolesBLL;
        private IErrorBLL errorBLL;
        public PayOrderBLL(ERPContext db, IRolesBLL rolesBLL, IErrorBLL errorBLL)
        {
            this.db = db;
            this.rolesBLL = rolesBLL;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 撤销订单
        /// </summary>
        /// <param name="pay"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> CancelOrder(PayOrderParamDTO pay)
        {
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == pay.UserId);
            //单个操作
            if (pay.Ids == null || pay.Ids.Length <= 0)
            {
                //找出付款订单
                PaymentOrder paymentOrder = await db.PaymentOrder.Include(p => p.BuyProduct).SingleOrDefaultAsync(p => p.Id == pay.Id);
                paymentOrder.IsAudit = 2;
                paymentOrder.Remark = pay.Remark;
                paymentOrder.BuyProduct.Remark= pay.Remark;
                //取消订单的人
                paymentOrder.CancelPerson = userInfo.TrueName;
                //操作时间
                paymentOrder.AuditTime =Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                //找出所有商品
                List<Product> products = await db.Product.Where(p => p.CatId == paymentOrder.BuyProduct.CatId).ToListAsync();
                if (products.Count <= 0)
                    return ApiResult.Error("请重试");
                for (int i = 0; i < products.Count; i++)
                {
                    products[i].IsAudio = 6;
                }
            }
            else
            {
                //找出所有商品
                List<Product> products = new List<Product>();
                for (int i = 0; i <pay.Ids.Length; i++)
                {
                    //找出付款订单
                    PaymentOrder paymentOrder = await db.PaymentOrder.Include(p => p.BuyProduct).SingleOrDefaultAsync(p => p.Id == pay.Ids[i]);
                    paymentOrder.IsAudit = 2;
                    paymentOrder.Remark = pay.Remark;
                    paymentOrder.BuyProduct.Remark = pay.Remark;
                    //取消订单的人
                    paymentOrder.CancelPerson = userInfo.TrueName;
                    //操作时间
                    paymentOrder.AuditTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                    //找出所有商品
                    products.AddRange(await db.Product.Where(p => p.CatId == paymentOrder.BuyProduct.CatId).ToListAsync());
                }
                if (products.Count <= 0)
                    return ApiResult.Error("请重试");
                for (int i = 0; i < products.Count; i++)
                {
                    products[i].IsAudio = 6;
                }
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("撤销成功") : ApiResult.Error("撤销失败");
            
        }
        /// <summary>
        /// 删除订单
        /// </summary>
        /// <param name="pay"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelOrderById(PayOrderParamDTO pay)
        {
            //是否是管理员
            UserInfo userInfo = await db.UserInfo.Include(u => u.Role).FirstOrDefaultAsync(o => o.Id == pay.UserId);
            int isUserDel = 0;
            int isAdminDel = 0;
            if (userInfo.Role.Sign == "ADMIN")
            {
                //是管理员
                isAdminDel = 1;
            }
            else
            {
                isUserDel = 1;
            }
            //批量操作
            if (pay.Ids != null&&pay.Ids.Length>0)
            {
                List<PaymentOrder> orders = new List<PaymentOrder>();
                for (int i = 0; i < pay.Ids.Length; i++)
                {
                    orders.Add(await db.PaymentOrder.SingleOrDefaultAsync(o => o.Id == pay.Ids[i]));
                }
                for (int i = 0; i < orders.Count; i++)
                {
                    db.Entry(orders[i]).State = EntityState.Modified;
                    orders[i].IsAdminDelete = isAdminDel;
                    orders[i].IsUserDelete = isUserDel;
                }
            }
            else
            {
                //不是批量删除
                try
                {
                    PaymentOrder buyProductOrder = await db.PaymentOrder.SingleOrDefaultAsync(o => o.Id == pay.Id);
                    db.Entry(buyProductOrder).State = EntityState.Modified;
                    buyProductOrder.IsAdminDelete = isAdminDel;
                    buyProductOrder.IsUserDelete = isUserDel;
                }
                catch(Exception e)
                {
                    await LogHelper.Error("批量删除付款订单失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                    //添加错误次数
                    await errorBLL.AddErrorData();

                }
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 获取所有的订单信息
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllOrder(PayOrderDTO order)
        {
            ApiResult apiResult = await rolesBLL.GetRoleById(order.UserId);
            Roles roles = apiResult.Data as Roles;
            //管理员可以看到所有的订单
            List<PaymentOrder> or = new List<PaymentOrder>();
            int count = 0;
            if (roles.Sign != "ADMIN")
            {
                or = await db.PaymentOrder.Where(p => p.ProNo.Contains(order.ProNo.Trim()) && order.State == p.IsAudit && p.UserId == order.UserId && p.IsUserDelete == 0 && p.IsAdminDelete == 0).OrderByDescending(p => p.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                 count =await db.PaymentOrder.CountAsync(p => p.ProNo.Contains(order.ProNo) && order.State == p.IsAudit && p.UserId == order.UserId && p.IsUserDelete == 0 && p.IsAdminDelete == 0);
            }
            else
            {
                or = await db.PaymentOrder.Where(p => p.ProNo.Contains(order.ProNo.Trim()) && order.State == p.IsAudit &&  p.IsAdminDelete == 0).OrderByDescending(p => p.AddTime).Skip((order.PageIndex - 1) * order.PageSize).Take(order.PageSize).ToListAsync();
                count = await db.PaymentOrder.CountAsync(p => p.ProNo.Contains(order.ProNo) && order.State == p.IsAudit && p.IsAdminDelete == 0);
            }
            return ApiResult.Success(new {MyList=or,Total=count});
        }
        /// <summary>
        /// 获取订单下面的商品
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetProById(int orderId)
        {
            PaymentOrder paymentOrder = await db.PaymentOrder.Include(p => p.BuyProduct).SingleOrDefaultAsync(p => p.BuyProductId == orderId);
            //商品
            List<Product> products = await db.Product.Where(p => p.CatId == paymentOrder.BuyProduct.CatId).ToListAsync();
            
            return ApiResult.Success(products);
        }

        /// <summary>
        /// 修改订单的状态 支付成功
        /// </summary>
        /// <param name="proNo"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public  bool UpdateState(string proNo, int userId)
        {
            //找出订单
            PaymentOrder paymentOrder =  db.PaymentOrder.Include(p => p.BuyProduct).SingleOrDefault(p => p.ProNo == proNo);
            
            //找出订单中的商品 修改商品状态 修改订单
            db.Entry(paymentOrder).State = EntityState.Modified;

            paymentOrder.PayPerson = ( db.UserInfo.SingleOrDefault(p => p.Id == userId)).TrueName;
            paymentOrder.PayTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            paymentOrder.ButType = 1;
            //已付款
            paymentOrder.IsAudit = 1;
            paymentOrder.AuditTime= Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            paymentOrder.BuyProduct.IsPay = 1;//已完成支付
           // paymentOrder.BuyProduct.AuditState = 5;//已完成支付
            //该订单中的所有商品 修改状态
            List<Product> products =  db.Product.Where(p => p.CatId == paymentOrder.BuyProduct.CatId && p.IsDelete == 0).ToList();

            for (int i = 0; i < products.Count; i++)
            {
                db.Entry(products[i]).State = EntityState.Modified;
                products[i].IsAudio = 5;//已付款
                products[i].PayTime = DateTime.Now.Date;
            }
            return  db.SaveChanges() > 0;

        }
    }
}
