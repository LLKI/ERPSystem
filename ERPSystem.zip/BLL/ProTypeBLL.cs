﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ProTypeBLL : IProTypeBLL
    {
        private ERPContext db;
        public ProTypeBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 添加商品类型
        /// </summary>
        /// <param name="pro"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddProType(ProType pro)
        {
            pro.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            await db.ProType.AddAsync(pro);
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }
        /// <summary>
        /// 删除商品类型
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelProType(int id)
        {
            ProType proType = await db.ProType.SingleOrDefaultAsync(t => t.Id == id);
            db.Entry(proType).State = EntityState.Modified;
            proType.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 获取所有的商品类型
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllProTypes()
        {
            return ApiResult.Success(await db.ProType.Where(p => p.IsDelete == 0).ToListAsync());
        }
        /// <summary>
        /// 通过id获取商品类型详情
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetProTypeById(int id)
        {
            return ApiResult.Success( await db.ProType.SingleOrDefaultAsync(p => p.Id == id&&p.IsDelete==0));
        }
        /// <summary>
        /// 修改商品的类型
        /// </summary>
        /// <param name="id"></param>
        /// <param name="pro"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateProType(int id, ProType pro)
        {
            ProType proType= await db.ProType.SingleOrDefaultAsync(p => p.Id == id && p.IsDelete == 0);
            db.Entry(proType).State = EntityState.Modified;
            proType.Remark = pro.Remark;
            proType.TypeName = pro.TypeName;
            proType.IsEnable=pro.IsEnable;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }

        /// <summary>
        /// 更改状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateProTypeState(int id, int state)
        {
            ProType proType = await db.ProType.SingleOrDefaultAsync(t => t.Id == id&&t.IsDelete==0);
            db.Entry(proType).State = EntityState.Modified;
            proType.IsEnable = state;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("更改成功") : ApiResult.Error("更改失败");
        }
    }
}
