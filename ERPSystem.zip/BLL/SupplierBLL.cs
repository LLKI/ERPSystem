﻿using common;
using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using OfficeOpenXml;
using OfficeOpenXml.ConditionalFormatting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class SupplierBLL : ISupplierBLL
    {
        private ERPContext db;
        private IErrorBLL errorBLL;
        public SupplierBLL(ERPContext db, IErrorBLL errorBLL)
        {
            this.db = db;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// 添加供应商
        /// </summary>
        /// <param name="sup"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddSupplier(Supplier sup)
        {
            if(await db.Supplier.SingleOrDefaultAsync(s => s.SupplierName == sup.SupplierName) != null)
            {
                return ApiResult.Error("添加失败，名称不能重复");
            }
            sup.AddTime =Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            db.Supplier.Add(sup);
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");
        }

        /// <summary>
        /// 通过id删除供应商
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DeleteSupplierById(int id)
        {
            Supplier supplier = await db.Supplier.SingleOrDefaultAsync(s=>s.Id==id&&s.IsDelete==0);
            db.Entry(supplier).State = EntityState.Modified;
            supplier.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        ///导出供应商信息
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> ExportSupplier(SupplierDTO sup)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var package = new ExcelPackage();
            //表名称
            var worksheet = package.Workbook.Worksheets.Add("供应商信息");
            //表头
            var headers = new string[] { "供应商名称", "地址", "邮政编码", "邮政地址", "联系人", "手机号","邮箱地址" };
            //worksheet.Cells.Style.ShrinkToFit = true;//单元格自动适应大小
            for (int i = 0; i < headers.Length; i++)
            {
                worksheet.Cells[1, i + 1].Value = headers[i];
                worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                worksheet.Row(i + 1).Height = 20;
                worksheet.Column(i + 1).Width =26;
                //worksheet.Row(1).Height = 15;//设置行高
                //worksheet.Row(1).CustomHeight = true;//自动调整行高
                //worksheet.Column(1).Width = 15;//设置列宽
            }
            //获取数据
            ApiResult apiResult = await GetAllSuppliers(sup);
            var list = apiResult.Data as List<Supplier>;

            // 支持各种直接获取数据的方法
            // worksheet.Cells.Load*...

            int row = 2;
            foreach (var item in list)
            {
                worksheet.Cells[row, 1].Value = item.SupplierName;
                worksheet.Cells[row, 2].Value = item.Address;
                worksheet.Cells[row, 3].Value = item.PostalCode;
                worksheet.Cells[row, 4].Value = item.MailingAddress;
                worksheet.Cells[row, 5].Value = item.Contactperson;
                worksheet.Cells[row, 6].Value = item.Phone;
                worksheet.Cells[row, 7].Value = item.Email;
                row++;
            }
            try
            {
                string fileName = "供应商表格.xlsx";
                // 通常做法是，将excel上传至对象存储，获取到下载链接，这里将其输出到项目根目录。
                using (FileStream stream = new FileStream(BaseUrl.SupplierExcelPath + fileName, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    await package.SaveAsAsync(stream);
                }
                package.Dispose();
                return ApiResult.Success("导出成功",BaseUrl.SupplierExcelUrl + fileName);
            }
            catch(Exception e)
            {
                await LogHelper.Error("导出供应商表格时，发送错误，错误消息为：" + e.Message + "，在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("导出错误,请联系管理员");
            }
        }

        //获取所有的供应商
        public async Task<ApiResult> GetAllSuppliers(SupplierDTO sup)
        {
            int state = 0;
            if (sup.IsEnable != "")
            {
                state = sup.IsEnable == "启用" ? 0 : 1;
            }
            List<Supplier> supList = null;
            if (sup.IsEnable == "")
            {
                supList = await db.Supplier.Where(s=>s.SupplierName.Contains(sup.SupplierName)&&s.Phone.Contains(sup.Phone)&&s.IsDelete==0).Skip((sup.PageIndex - 1) * sup.PageSize).Take(sup.PageSize).OrderByDescending(s => s.AddTime).ToListAsync();
            }
            else
            {
                supList = await db.Supplier.Where(s => s.SupplierName.Contains(sup.SupplierName) && s.Phone.Contains(sup.Phone)&&s.IsEnable==state && s.IsDelete == 0).Skip((sup.PageIndex - 1) * sup.PageSize).Take(sup.PageSize).OrderByDescending(s => s.AddTime).ToListAsync();
            }
            return ApiResult.Success(supList);
        }
        /// <summary>
        /// 获取所有的供应商，不带参数
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllSuppliers()
        {
            return ApiResult.Success(await db.Supplier.Where(s => s.IsDelete == 0 && s.IsEnable == 0).ToListAsync());
        }

        /// <summary>
        /// 通过id获取供应商
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetSupplierById(int id)
        {
            return ApiResult.Success(await db.Supplier.SingleOrDefaultAsync(s => s.Id == id));
        }
        /// <summary>
        /// 通过名称获取供应商id
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<int> GetSupplierIdByName(string name)
        {
            Supplier supplier = await db.Supplier.SingleOrDefaultAsync(s => s.SupplierName == name && s.IsDelete == 0 && s.IsEnable == 0);
            return supplier.Id;
        }

        /// <summary>
        /// 修改状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateState(int id, int state)
        {
            Supplier supplier = await db.Supplier.SingleOrDefaultAsync(s => s.Id == id);
            db.Entry(supplier).State = EntityState.Modified;
            supplier.IsEnable = state;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("更改成功") : ApiResult.Error("更改失败");
        }

        /// <summary>
        /// 修改供应商信息
        /// </summary>
        /// <param name="sup"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateSupplier(Supplier sup)
        {
            Supplier supplier = await db.Supplier.SingleOrDefaultAsync(s => s.Id == sup.Id);
            db.Entry(supplier).State = EntityState.Modified;
            supplier.SupplierName = sup.SupplierName;
            supplier.Address = sup.Address;
            supplier.Phone = sup.Phone;
            supplier.Email = sup.Email;
            supplier.Remark = sup.Remark;
            supplier.Contactperson = sup.Contactperson;
            supplier.MailingAddress = sup.MailingAddress;
            supplier.PostalCode = sup.PostalCode;
            supplier.Website = sup.Website;
            db.Supplier.Update(supplier);
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }
    }
}
