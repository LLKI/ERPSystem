﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class FeedbackBLL : IFeedback
    {


        private ERPContext db;


        public FeedbackBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelData(int id)
        {
            Feedback feedback = await db.Feedback.SingleOrDefaultAsync(f => f.Id == id);
            db.Entry(feedback).State = EntityState.Modified;
            feedback.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 获取所有的数据
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllData(FeedbackDTO feed)
        {
            int count = 0;
            List<Models.models.Feedback> feedbacks = new List<Models.models.Feedback>();
            if (feed.AddTime==null)
            {
                feedbacks= await db.Feedback.Where(f => f.Content.Contains(feed.Content) && f.IsDelete == 0).OrderByDescending(o=>o.AddTime).Skip((feed.PageIndex-1)*feed.PageSize).Take(feed.PageSize).ToListAsync();
                count =await db.Feedback.Where(f => f.Content.Contains(feed.Content) && f.IsDelete == 0).CountAsync();
            }
            else
            {
               feedbacks = await db.Feedback.Where(f => f.Content.Contains(feed.Content)&&f.AddTime.Value.Date==Convert.ToDateTime(feed.AddTime).Date&& f.IsDelete == 0).OrderByDescending(o => o.AddTime).Skip((feed.PageIndex - 1) * feed.PageSize).Take(feed.PageSize).ToListAsync();
                count = await db.Feedback.Where(f => f.Content.Contains(feed.Content) && f.AddTime.Value.Date ==Convert.ToDateTime(feed.AddTime).Date && f.IsDelete == 0).CountAsync();
            }

            return ApiResult.Success(new { myList=feedbacks,Count=count});
        }
        /// <summary>
        /// 更改状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="isSolve"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateState(int id, int isSolve)
        {
            Feedback feedback = await db.Feedback.SingleOrDefaultAsync(f => f.Id == id);
            db.Entry(feedback).State = EntityState.Modified;
            if (isSolve == 0)
            {
                feedback.IsSolve =1;
            }
            else
            {
                feedback.IsSolve = 0;
            }

            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("执行成功") : ApiResult.Error("执行失败");
        }
    }
}
