﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class DepartmentBLL : IDepartmentBLL
    {

        private ERPContext db;
        public DepartmentBLL(ERPContext db)
        {
            this.db = db;
        }

        /// <summary>
        /// 获取所有的部门
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllDepartmetns()
        {
            return ApiResult.Success(await db.Department.Where(d => d.IsDelete == 0).ToListAsync());    
        }
        /// <summary>
        /// 通过名称获取部门
        /// </summary>
        /// <param name="depaName"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<Department> GetDepaByName(string depaName)
        {
            return await db.Department.SingleOrDefaultAsync(d => d.DepaName == depaName.Trim());
        }
    }
}
