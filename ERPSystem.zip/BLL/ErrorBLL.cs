﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ErrorBLL : IErrorBLL
    {
        //rivate ERPContext db;
        private ERPContext db;
        public ErrorBLL()
        {
            db = new ERPContext();
        }

        /// <summary>
        /// 添加错误的次数
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<bool> AddErrorData()
        {
            //int count = await db.ErrorData.MaxAsync(m => m.Count);
            //int result = count++;
            try
            {
                await db.ErrorData.AddAsync(new ErrorData { Count = 1, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd")) });
                
                //db.ErrorData.Attach(new ErrorData { Count = 1, AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd")) });
               // return db.SaveChanges()>0?true:false;
                return await db.SaveChangesAsync() > 0 ? true : false;
            }
            catch(Exception e)
            {
                string er = e.Message;
                return false;
            }
            
        }
        /// <summary>
        /// 获取所有的错误数量
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<int> GetAllCount()
        {
            return await db.ErrorData.CountAsync();
        }

        /// <summary>
        /// 通过时间获取错误的数量
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetErrorCount()
        {
            DateTime now=DateTime.Now.Date;
            //当天错误的数量
            int nowCount=await db.ErrorData.Where(e => e.AddTime.Value.Date == now).CountAsync();
            //星期一
            //存放本周的日期
            List<DateTime> date = new List<DateTime>();
            //存放周一至周日错误的次数
            int[] count = new int[9];
            for (int i = 1; i <8; i++)
            {
                date.Add(GetWeek.WeekStartTime(i));
            }
            for (int i = 0; i < date.Count-1; i++)
            {
                count[i]=(await db.ErrorData.Where(p => p.AddTime == date[i]).CountAsync());
            }
            count[7]=nowCount;
            count[8] =await GetAllCount();
            return ApiResult.Success(new {count=count});
        }
    }
}
