﻿using common;
using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using Models.redis;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BLL
{
    public class UserBLL : IUserBLL
    {
        private RedisHelper rc;
        private ERPContext db;
        private IErrorBLL errorBLL;
        public UserBLL(RedisHelper rc, ERPContext db, IErrorBLL errorBLL)
        {
            this.rc = rc;
            this.db = db;
            this.errorBLL = errorBLL;
        }
        /// <summary>
        /// /通过id获取用户的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<UserInfo> GetUserById(int id)
        {
            return db.UserInfo.Include(u=>u.Role).SingleOrDefaultAsync(u => u.Id == id&&u.IsDelete==0);
        }
        /// <summary>
        /// 通过键获取用户信息
        /// </summary>
        /// <param name="key">key 用户的账号</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetUserByKey(string key)
        {
            byte[] bytes = await rc.GetValueAsync(key);
            if (bytes == null)
            {
                UserInfo userInfo=await db.UserInfo.Include(u => u.Department).Include(u => u.Role).FirstOrDefaultAsync(u => u.IsDelete == 0 && u.Account == key);
                //string sql = "SELECT * FROM userInfo u JOIN department d on u.departmentId=d.id JOIN roles r on r.id=u.roleId WHERE u.isDelete=0 AND u.account=@account";
                //UserInfo userInfo = await db.UserInfo.FromSqlRaw<UserInfo>(sql, new SqlParameter[]
                //{
                //    new SqlParameter("@account",key)
                //}).FirstOrDefaultAsync();
                if (userInfo == null)
                    return ApiResult.Error("没有该用户");
                //存入redis
                userInfo.AccountImg = BaseUrl.AccountImgUrl + userInfo.AccountImg;
                try
                {
                    string v = JsonConvert.SerializeObject(userInfo);
                    await rc.SetValueAsync(key, v, TimeSpan.FromHours(24));
                }catch(Exception e)
                {
                    string error = e.Message;
                }
                
                return ApiResult.Success(userInfo);
            }
            //redis中有数据，直接读取并且返回
            UserInfo user = JsonConvert.DeserializeObject<UserInfo>(Encoding.UTF8.GetString(bytes));
            return ApiResult.Success(user);
        }
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="oldPwd">旧密码</param>
        /// <param name="newPwd">新密码</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdatePwd(int id, string oldPwd, string newPwd)
        {
            UserInfo user = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == id);
            if (user == null)
                return ApiResult.Error("修改密码失败，系统错误");
            if (oldPwd != user.Pwd)
                return ApiResult.Error("原密码不正确");
            if (newPwd == oldPwd)
                return ApiResult.Error("新密码跟旧密码不能相似");
            try
            {
                await LogHelper.Info(user.TrueName + "=====>正在修改密码");
                db.Entry(user).State = EntityState.Modified;
                user.Pwd = newPwd;
                //密码修改成功 删除redis中的数据
                await db.SaveChangesAsync();
                byte[] bytes = await rc.GetValueAsync(user.Account);
                if (bytes != null)
                {
                    //移除
                    await rc.RemoveAsync(user.Account);
                }
                return ApiResult.Success("修改成功");
            }
            catch (Exception e)
            {
                await LogHelper.Error(user.Account + "=====>修改密码失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("修改密码失败");
            }

        }

        /// <summary>
        /// 修改用户的头像
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateUserAccountImgById(string account, IFormFileCollection file)
        {
            ApiResult result = await GetUserByKey(account);
            UserInfo user = result.Data as UserInfo;
            await LogHelper.Info(user.TrueName + "=====>正在上传个人头像");
            IFormFile formFile = file[0];
            string extension = Path.GetExtension(formFile.FileName);
            //文件名称
            string fileName = Guid.NewGuid().ToString() + extension;
            if (extension != ".jpg" && extension != ".png" && extension != ".jpeg" && extension != ".bmp" && extension != "gif")
            {
                await LogHelper.Info(account + "=====>格式有误.");
                return ApiResult.Error("格式有误，请重新上传");
            }
            else
            {
                //格式无误
                //首先上传到服务器
                try
                {
                    using (var stream = new FileStream(BaseUrl.AccountImgPath + fileName, FileMode.OpenOrCreate))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
                catch (Exception e)
                {

                    await LogHelper.Error(user.TrueName + "=====>上传个人头像时失败,错误消息：" + e.Message + ",在那个地方：" + e.StackTrace);
                    await errorBLL.AddErrorData();
                    return ApiResult.Error("上传失败，请重试");
                }
                //更新数据库
                UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == user.Id);
                db.Entry(userInfo).State = EntityState.Modified;
                userInfo.AccountImg = fileName;
                //更新redis
                byte[] bytes = await rc.GetValueAsync(user.Account);
                UserInfo u = null;
                if (bytes != null)
                {
                    try
                    {
                        u = JsonConvert.DeserializeObject<UserInfo>(Encoding.UTF8.GetString(bytes));
                        await rc.RemoveAsync(user.Account);
                        //重新存入
                        u.AccountImg = BaseUrl.AccountImgUrl + fileName;
                        await rc.SetValueAsync(u.Account, JsonConvert.SerializeObject(u), TimeSpan.FromDays(1));
                        await db.SaveChangesAsync();
                        return ApiResult.Success("修改成功", BaseUrl.AccountImgUrl + fileName);
                    }
                    catch (Exception t)
                    {

                        await LogHelper.Error(userInfo.TrueName + "=====>在更新个人头像时，同步redis出错，错误消息：" + t.Message + ",在那个地方：" + t.StackTrace);
                        await errorBLL.AddErrorData();
                        return ApiResult.Error("更新失败:" + t.Message);
                    }
                }
                else
                {
                    UserInfo u2 = result.Data as UserInfo;
                    u2.AccountImg = BaseUrl.AccountImgUrl + fileName;
                    await rc.SetValueAsync(u2.Account, JsonConvert.SerializeObject(u), TimeSpan.FromDays(1));
                    await db.SaveChangesAsync();
                    return ApiResult.Success("修改成功", BaseUrl.AccountImgUrl + fileName);
                }
            }
        }

        /// <summary>
        /// 修改用户信息
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateUserById(UserInfo user)
        {
            await LogHelper.Info(user.TrueName + "=====>正在修改个人信息");
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == user.Id);
            db.Entry(userInfo).State = EntityState.Modified;
            userInfo.Birthday = Convert.ToDateTime(Convert.ToDateTime(user.Birthday).ToString("yyyy-MM-dd HH:ss"));
            userInfo.Qq = user.Qq;
            userInfo.TrueName = user.TrueName;
            userInfo.NickName = user.NickName;
            userInfo.Address = user.Address;
            userInfo.Sex = user.Sex;
            userInfo.Age = user.Age;
            userInfo.Email = user.Email;
            userInfo.RoleId = user.RoleId;
            userInfo.DepartmentId = user.DepartmentId;
            userInfo.Remark = user.Remark;
            //userInfo.Id = 0;
            //db.UserInfo.Update(userInfo);
            
            if (await db.SaveChangesAsync() > 0)
            {
                await LogHelper.Info(user.TrueName + "=====>修改个人信息成功");
                //更改redis中的数据
                if (await rc.GetValueAsync(userInfo.Account) != null)
                {
                    try
                    {
                        //取之前的数据
                        byte[] bytes = await rc.GetValueAsync(user.Account);
                        UserInfo beforeUser = JsonConvert.DeserializeObject<UserInfo>(Encoding.UTF8.GetString(bytes));
                        //赋值
                        user.Department = beforeUser.Department;
                        user.Role = beforeUser.Role;
                        //移除
                        await rc.RemoveAsync(user.Account);
                        //添加
                        await rc.SetValueAsync(user.Account, JsonConvert.SerializeObject(user), TimeSpan.FromDays(1));
                        await LogHelper.Info(user.TrueName + "=====>同步redis中成功");
                    }
                    catch (Exception e)
                    {
                        await LogHelper.Error(user.TrueName + "=====>在修改redis中的数据时，失败，错误消息：" + e.Message + ",在那个地方：" + e.StackTrace);
                        await errorBLL.AddErrorData();
                    }
                }
                return ApiResult.Success("修改成功");
            }
            else
            {
                await LogHelper.Error(user.TrueName + "=====>修改信息失败");
                await errorBLL.AddErrorData();
                return ApiResult.Error("修改失败");
            }
        }

        /// <summary>
        /// 发送验证码（修改手机）
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public async Task<ApiResult> SendCodeByUpdatePhone(string phone, string oldPhone)
        {
            byte[] bytes = await rc.GetValueAsync(phone);
            byte[] oldPhones = await rc.GetValueAsync(oldPhone);
            //如果redis里已经有了该手机号，就不允许再次发送
            if (bytes != null)
                return ApiResult.Error("验证码已经发送，请勿重复发送");
            Regex rule = new Regex(@"^1[345789]\d{9}$");
            Match match = rule.Match(phone);
            if (!match.Success)
                return ApiResult.Error("手机号格式不正确");
            if (oldPhones == null)
                return ApiResult.Error("验证码已过期，请重新发送");
            UserInfo_redis user = null;
            //获得验证码
            string validateCode = GetCode.GetValidateCode(4);
            //开始发送
            ApiResult result = await Common.SendCode.SendCodeNum(phone, validateCode);
            if (result.Code == 200)
            {
                //取出需要修改的用户
                byte[] bytes1 = await rc.GetValueAsync(oldPhone);
                user = JsonConvert.DeserializeObject<UserInfo_redis>(Encoding.UTF8.GetString(bytes1));
                await LogHelper.Info(user.TrueName + "=====>正在修改手机号");
                try
                {
                    //删除之前存入的用户信息
                    await rc.RemoveAsync(oldPhone);
                    await LogHelper.Info(user.TrueName + "=====>成功从redis中删除旧信息");
                    //存入新手机号 
                    user.Phone = phone;
                    user.CodeNum = validateCode;
                    await rc.SetValueAsync(phone, JsonConvert.SerializeObject(user), TimeSpan.FromHours(1));
                    await LogHelper.Info(user.TrueName + "=====>成功将新消息存入redis,1小时后过期");
                }
                catch (Exception e)
                {
                    await LogHelper.Error(user.TrueName + "=====>修改手机号出错，错误消息：" + e.Message + "，在哪里：" + e.StackTrace);
                    await errorBLL.AddErrorData();
                    return ApiResult.Error("发送失败,请重新尝试");
                }
            }
            else
            {
                return result;
            }
            return result;
        }

        /// <summary>
        /// 修改手机号
        /// </summary>
        /// <param name="newPhone"></param>
        /// <returns></returns>
        public async Task<ApiResult> UpdatePhone(int id, string newPhone, string codeNum)
        {
            byte[] bytes = await rc.GetValueAsync(newPhone);
            if (bytes == null)
                return ApiResult.Error("验证码已过期，请重新发送!");
            UserInfo_redis userInfo_redis = JsonConvert.DeserializeObject<UserInfo_redis>(Encoding.UTF8.GetString(bytes));
            if (userInfo_redis.CodeNum != codeNum)
                return ApiResult.Error("验证码有误！");

            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == id);
            db.Entry(userInfo).State = EntityState.Modified;
            userInfo.Phone = newPhone;
            try
            {
                //从redis中移除
                await rc.RemoveAsync(newPhone);
                //修改redis中的数据
                byte[] bytes1 = await rc.GetValueAsync(userInfo.Account);
                //之前的数据
                UserInfo user = JsonConvert.DeserializeObject<UserInfo>(Encoding.UTF8.GetString(bytes1));
                //移除原来 修改
                await rc.RemoveAsync(userInfo.Account);
                userInfo.Phone = newPhone;
                await rc.SetValueAsync(userInfo.Account, JsonConvert.SerializeObject(user), TimeSpan.FromDays(1));
                await LogHelper.Info(userInfo.TrueName + "=====>已成功修改手机号");
                return db.SaveChanges() > 0 ? ApiResult.Success("修改成功", newPhone) : ApiResult.Error("修改失败");
            }
            catch (Exception e)
            {
                await LogHelper.Error(userInfo.TrueName + "=====>修改手机号时失败，错误消息：" + e.Message + ",在哪里：" + e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("修改失败");
            }

        }
        /// <summary>
        /// 上传个人照片
        /// </summary>
        /// <param name="id"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UplaodUserImg(int id, IFormFileCollection file)
        {
            UserInfo user = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == id);
            await LogHelper.Info(user.TrueName + "=====>正在上传人脸");
            IFormFile formFile = file[0];
            string extension = Path.GetExtension(formFile.FileName);
            if (extension != ".jpg" && extension != ".png" && extension != ".jpeg" && extension != ".bmp" && extension != "gif")
            {
                return ApiResult.Error("格式有误，请重新认证");
            }
            //文件的名称
            string fileName = Guid.NewGuid().ToString() + extension;
            try
            {
                using (var fileStream = new FileStream(Common.BaseUrl.FaceImgUrl + fileName, FileMode.Create))
                {
                    //将传入的人脸图片保存到文件夹中
                    await formFile.CopyToAsync(fileStream);
                }
            }catch(Exception e)
            {
                await LogHelper.Error(user.TrueName + "=====>上传人脸失败,错误消息："+e.Message+",在哪里："+e.StackTrace);
                await errorBLL.AddErrorData();
                return ApiResult.Error("上传失败");
            }
            
            db.Entry(user).State = EntityState.Modified;
            user.UserImg = fileName;
            byte[] bytes = await rc.GetValueAsync(user.Account);
            if (bytes != null)
            {
                try
                {
                    UserInfo userInfo = JsonConvert.DeserializeObject<UserInfo>(Encoding.UTF8.GetString(bytes));
                    userInfo.UserImg = fileName;
                    //移除
                    await rc.RemoveAsync(user.Account);
                    //更新
                    await rc.SetValueAsync(user.Account, JsonConvert.SerializeObject(userInfo), TimeSpan.FromDays(1));
                    await LogHelper.Info(user.Account + "=====>上传个人照片时，更新redis信息成功");
                }catch(Exception e)
                {
                    await errorBLL.AddErrorData();
                    await LogHelper.Error(user.Account + "=====>上传个人照片时，更新redis信息失败,错误消息："+e.Message+",在哪里："+e.StackTrace);
                }
            }
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("上传成功") : ApiResult.Error("上传失败");
        }
    }
}
