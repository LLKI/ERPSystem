﻿using Common;
using IBLL;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class MenuBLL : IMenuBLL
    {
        private ERPContext db;
        public MenuBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 添加菜单
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddMenu(MenuDTO menu)
        {
            db.Menu.Add(new Menu { AddTime=Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm")), Icon=menu.Icon, IsDelete=0,IsEnable=0, MenuName=menu.MenuName, Remark=menu.Remark});
            await db.SaveChangesAsync();
            //menu id为 role id
            int menuId = await db.Menu.MaxAsync(m => m.Id);
            for (int i = 0; i < menu.Ids.Length; i++)
            {
                db.MenuRelaRoles.Add(new MenuRelaRoles { MenuId = menuId, RoleId = menu.Ids[i] });
            }

            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("添加成功") : ApiResult.Error("添加失败");

        }

        /// <summary>
        /// 获取菜单
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetMenu(int userId)
        {
            UserInfo userInfo = await db.UserInfo.SingleOrDefaultAsync(u => u.Id == userId&&u.IsDelete==0);
            if (userInfo == null)
                return ApiResult.Error("错误");
            List<Menu> menus= await db.Menu.Include(m => m.SonMenu).Include(m=>m.MenuRelaRoles).Where(m=>m.IsDelete==0&&m.IsEnable==0).ToListAsync();
            List<Menu> list = new List<Menu>();
            //莫名其妙就写出来了。
            for (int i = 0; i < menus.Count; i++)
            {
                menus[i].SonMenu= menus[i].SonMenu.Where(s => s.IsDelete == 0).ToList();
                List<MenuRelaRoles> menuRelaRoles = menus[i].MenuRelaRoles.ToList();
                for (int j = 0; j < menuRelaRoles.Count; j++)
                {
                    if(menuRelaRoles[j].RoleId == userInfo.RoleId)
                    {
                        list.Add(menus[i]);
                    }
                }
            }
            return ApiResult.Success(list);

        }
        /// <summary>
        /// 通过id获取菜单的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetMenuById(int id)
        {
            return ApiResult.Success(await db.Menu.Include(m=>m.SonMenu).SingleOrDefaultAsync(m => m.Id == id&&m.IsDelete==0));
        }
        /// <summary>
        /// 获取所有的菜单
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetMenus()
        {
            return ApiResult.Success(await db.Menu.Include(m => m.SonMenu).Where(m => m.IsDelete == 0).ToListAsync());
        }
        /// <summary>
        /// 通过id获取子菜单的信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetSonMenuById(int id)
        {
            return ApiResult.Success(await db.SonMenu.Where(m => m.ParentId == id && m.IsDelete == 0).ToListAsync());
        }

        /// <summary>
        /// 修改菜单信息
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateMenu(Menu menu)
        {
            Menu m = await db.Menu.SingleOrDefaultAsync(m => m.Id == menu.Id && m.IsDelete == 0);
            db.Entry(m).State = EntityState.Modified;
            m.MenuName = menu.MenuName;
            m.Remark = menu.Remark;
            m.Icon = menu.Icon;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }

	/// <summary>
        /// 删除菜单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<ApiResult> DeleteMenu(int id)
        {
            int count = await db.SonMenu.Where(s => s.ParentId == id && s.IsDelete == 0).CountAsync();
            if (count > 0)
            {
                return ApiResult.Error("删除失败：请先删除子菜单!");
            }
            else
            {
                Menu menu = await db.Menu.Where(s => s.Id == id).FirstOrDefaultAsync();
                db.Entry(menu).State = EntityState.Deleted;
                db.Remove(menu);
                return await db.SaveChangesAsync() >= 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
            }
        }

    }
}
