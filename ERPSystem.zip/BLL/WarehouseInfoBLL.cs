﻿using Common;
using IBLL;
using Microsoft.EntityFrameworkCore;
using Models.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using static OfficeOpenXml.ExcelErrorValue;

namespace BLL
{
    public class WarehouseInfoBLL : IWarehouseInfoBLL
    {
        private ERPContext db;

        public WarehouseInfoBLL(ERPContext db)
        {
            this.db = db;
        }
        /// <summary>
        /// 获取今日 数量
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetCount()
        {
            //今天入库的数量
            int nowDayImport = 0;
            DateTime nowDay = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));



            List<BuyProductOrder> buyProductOrders = await db.BuyProductOrder.Where(b => (b.AuditState == 1 && b.AuditTime.Value.Date == nowDay ) || b.AuditState == 5).ToListAsync();
            for (int t = 0; t < buyProductOrders.Count; t++)
            {
                List<Product> productList = await db.Product.Where(p => p.CatId == buyProductOrders[t].CatId&&p.IsDelete==0).ToListAsync();
                for (int p = 0; p < productList.Count; p++)
                {
                    nowDayImport += Convert.ToInt32(productList[p].Stock.Split("-")[0]);
                }
            }
            //List<Product> products = await db.Product.Where(p =>p.PayTime.Value.Date ==nowDay&& p.IsDelete == 0&&p.IsEnable==0 || p.IsAudio == 5 || p.IsAudio == 1).ToListAsync();

            //for (int i = 0; i < products.Count; i++)
            //{
            //    nowDayImport += Convert.ToInt32(products[i].Stock.Split("-")[0]);
            //    DateTime addTime =Convert.ToDateTime(products[i].AddTime.Date);

            //}

            //今天出库的数量
            // List<Product> movePros = await db.Product.Where(p => p.MoveTime.Value.Date==nowDay && p.IsDelete == 0 && p.IsEnable == 0 && p.IsAudio == 9).ToListAsync();
            List<OutProOrder> nowDayExportList = await db.OutProOrder.Where(b => b.AuditState == 1 && b.AuditTime.Value.Date == nowDay).ToListAsync();
            int nowDayExport = 0;
            for (int i = 0; i < nowDayExportList.Count; i++)
            {
                nowDayExport += Convert.ToInt32(nowDayExportList[i].BackNum);
            }
            //今天调拨数量
            int transfersCount = 0;
            List<Product> transfersPros = await db.Product.Where(p => p.TransfersTime.Value.Date == nowDay && p.IsEnable == 0 && p.IsDelete == 0 && p.IsAudio == 10).ToListAsync();
            foreach (var item in transfersPros)
            {
                transfersCount += Convert.ToInt32(item.Stock.Split("-")[0]);
            }
            //商品的总数量
            int reservoirsCount = 0;
            List<Product> products = await db.Product.Where(p => p.IsDelete == 0 && (p.IsAudio == 5 || p.IsAudio == 4)).ToListAsync();
            for (int i = 0; i < products.Count; i++)
            {
                reservoirsCount +=Convert.ToInt32(products[i].Stock.Split("-")[0]);
            }

            ////退货数量今日
            ///
            List<BackProOrder> backProOrders = await db.BackProOrder.Where(b => b.AuditState == 1 && b.AuditTime.Value.Date == nowDay).ToListAsync();
            int backProCount = 0;
            for (int i = 0; i < backProOrders.Count; i++)
            {
                backProCount += Convert.ToInt32(backProOrders[i].BackNum);
            }
            int[] strs = { nowDayImport, nowDayExport, transfersCount, reservoirsCount, backProCount };
            return ApiResult.Success(strs);
        }

        /// <summary>
        /// 获取仓库的信息
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetInfo()
        {
            List<Reservoir> reservoirs = await db.Reservoir.Include(r => r.Warehouse).Where(r => r.IsDelete == 0 && r.IsEnable == 0).ToListAsync();

            List<string> names = new List<string>();
            for (int i = 0; i < reservoirs.Count; i++)
            {
                string resName = reservoirs[i].ReservoirName;
                reservoirs[i].Warehouse = reservoirs[i].Warehouse.ToList();

                List<string> list = reservoirs[i].Warehouse.Select(w => w.HouseName).ToList();
                for (int j = 0; j < list.Count; j++)
                {
                    names.Add(resName + ">" + list[j]);

                }
            }
            Dictionary<string, int> map = new Dictionary<string, int>();
            for (int i = 0; i < names.Count; i++)
            {
                try
                {
                    List<Product> products = await db.Product.Where(p => p.Address == names[i] && p.IsDelete == 0 && (p.IsAudio == 5 || p.IsAudio == 4)).ToListAsync();
                    int sum = 0;
                    for (int j = 0; j < products.Count; j++)
                    {
                        sum += Convert.ToInt32(products[j].Stock.Split("-")[0]);
                    }
                    map.Add(names[i], sum);
                }
                catch (Exception e)
                {
                    string err = e.Message;
                }
            }
            return ApiResult.Success(map);
        }
        /// <summary>
        /// 获取每一个仓库一周的进货数量
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResult> GetWeekInfo()
        {
            //所有的仓库
            List<Reservoir> reservoirs = await db.Reservoir.Include(r => r.Warehouse).Where(r => r.IsDelete == 0 & r.IsEnable == 0).ToListAsync();
            //仓库名称(库房加库区)
            List<string> names = new List<string>();
            for (int i = 0; i < reservoirs.Count; i++)
            {
                string resName = reservoirs[i].ReservoirName;
                reservoirs[i].Warehouse = reservoirs[i].Warehouse.ToList();

                List<string> list = reservoirs[i].Warehouse.Select(w => w.HouseName).ToList();
                for (int j = 0; j < list.Count; j++)
                {
                    names.Add(resName + ">" + list[j]);

                }
            }
            //每周的数量
            Dictionary<string, object> value = new Dictionary<string, object>();

            //for (int i = 1; i < 8; i++)
            //{
            //DateTime time= GetWeek.WeekStartTime(1);
            List<string> text = new List<string>() { "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日" };
            Dictionary<string, object> values = new Dictionary<string, object>();
            for (int i = 0; i < names.Count; i++)
            {
                List<int> counts = new List<int>();
                for (int j = 1; j < 8; j++)
                {
                    //每一天的日期
                    DateTime time = GetWeek.WeekStartTime(j);

                    // List<Product> products = await db.Product.Where(p => p.IsDelete == 0 && p.Address == names[i].Trim() || p.IsAudio == 5 || p.IsAudio == 1).ToListAsync();
                    int count = 0;
                    List<BuyProductOrder> buyProductOrders = await db.BuyProductOrder.Where(b => (b.AuditState == 1 && b.AuditTime.Value.Date == time) || b.AuditState == 5 ).ToListAsync();
                    for (int t = 0; t < buyProductOrders.Count; t++)
                    {
                        List<Product> products = await db.Product.Where(p => p.CatId == buyProductOrders[t].CatId && p.Address == names[i].Trim()).ToListAsync();
                        for (int p = 0; p < products.Count; p++)
                        {
                            count += Convert.ToInt32(products[p].Stock.Split("-")[0]);
                        }
                    }

                    //for (int p = 0; p < products.Count; p++)
                    //{
                    //    BuyProductOrder buyProductOrder = await db.BuyProductOrder.Where(b => b.CatId == products[i].CatId).SingleOrDefaultAsync();
                    //    count += Convert.ToInt32(products[p].Stock.Split("-")[0]);
                    //}
                    counts.Add(count);
                }
                values.Add(names[i], counts);
            }

            //for (int i = 1; i <text.Count+1; i++)
            //{
            //    Dictionary<string, object> values = new Dictionary<string, object>();
            //    //每一天的日期
            //    DateTime time = GetWeek.WeekStartTime(i);
            //    for (int j = 0; j < names.Count; j++)
            //    {
            //        List<Product> products = await db.Product.Where(p => p.IsDelete == 0 && p.Address == names[j].Trim() && p.IsAudio == 5 && p.PayTime.Value.Date == time).ToListAsync();
            //        int count = 0;

            //        for (int p = 0; p < products.Count; p++)
            //        {
            //            count += Convert.ToInt32(products[p].Stock.Split("-")[0]);
            //        }
            //        values.Add(names[j], count);
            //    }
            //    value.Add(text[i-1] ,values);
            //}


            //for (int j = 0; j < names.Count; j++)
            //{
            //    for (int t = 1; t < 8; t++)
            //    {
            //        DateTime time = GetWeek.WeekStartTime(t);
            //        //与当周的每一天匹配
            //        List<Product> products = await db.Product.Where(p => p.IsDelete == 0 && p.Address == names[j].Trim() && p.IsAudio == 5 && p.PayTime.Value.Date == time).ToListAsync();
            //        int count = 0;
            //        for (int p = 0; p < products.Count; p++)
            //        {
            //            count += Convert.ToInt32(products[p].Stock.Split("-")[0]);
            //        }
            //        counts.Add(count);
            //    }
            //    map.Add(new { Name = names[j], Count=new int[7] {  } });
            //   //value.Add(j,map);
            //}
            //}
            return ApiResult.Success(values);

        }
    }
}
