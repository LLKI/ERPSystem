﻿using common;
using Common;
using IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{


    public class NotifyBLL : INotifyBLL
    {
        private readonly ERPContext db;
        public NotifyBLL(ERPContext context)
        {
            db = context;
        }
        /// <summary>
        /// 添加公告
        /// </summary>
        /// <param name="notice"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> AddNotify(Notice notice)
        {
            UserInfo account =await db.UserInfo.FirstOrDefaultAsync(u => u.Id== notice.UserId);
            await LogHelper.Info(account.TrueName  + "=====>正在发送公告");
            notice.IsDelete = 0;
            notice.AddTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
            await db.Notice.AddAsync(notice);
            await LogHelper.Info(account.TrueName + "=====>发送公告完成");
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success() : ApiResult.Error();
        }
        /// <summary>
        /// 通过id删除公告
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DeleteNotifyById(int id)
        {
            Notice user= db.Notice.Include(n => n.User).SingleOrDefault(n => n.Id == id && n.IsDelete == 0 && n.User.IsDelete == 0);
            await LogHelper.Info(user.User.TrueName + "=====>正在删除公告");
            db.Entry(user).State = EntityState.Deleted;
            user.IsDelete = 1;
            await LogHelper.Info(user.User.TrueName + "=====>删除公告成功");
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }

        /// <summary>
        /// 获取所有的公告内容
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetAllContent(int userId)
        {
            

            List<NoticeType> noticeTypes = await db.NoticeType.Include(n => n.Notice).Where(n => n.IsDelete == 0).OrderByDescending(n =>n.AddTime).ToListAsync();

            for (int i = 0; i < noticeTypes.Count; i++)
            {
                if (noticeTypes[i].Sign == "MYNEWS")
                {
                    noticeTypes[i].Notice = noticeTypes[i].Notice.Where(n => n.IsDelete == 0&&n.UserId==userId).OrderByDescending(n => n.AddTime).ToList();
                }
                else
                {
                    noticeTypes[i].Notice = noticeTypes[i].Notice.Where(n => n.IsDelete == 0).OrderByDescending(n => n.AddTime).ToList();
                }
                
            }


            return ApiResult.Success(noticeTypes);
        }

        /// <summary>
        /// 获取所有的公告类型
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public ApiResult GetAllType()
        {
            return ApiResult.Success(db.NoticeType.Where(n => n.IsDelete == 0).ToList());
        }
        /// <summary>
        /// 通过id获取通知的内容
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ApiResult GetContentById(int id)
        {
            var value = db.Notice.Include(n => n.User).Where(n => n.IsDelete == 0).Select(u => new { u.User.TrueName, u.Id, u.Content, u.Title, u.AddTime }).SingleOrDefault(n => n.Id == id);
            if (value == null)
                return ApiResult.Error("该公告没有详情");
            return ApiResult.Success(value);
        }
        /// <summary>
        /// 查询指定用户发表的公告
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public ApiResult GetMyNotifys(PageParams param)
        {

            List<Notice> notilis = db.Notice.Include(n => n.Type).Where(n => n.UserId == param.Id && n.IsDelete == 0 && n.Type.TypeName.Contains(param.TypeName) && n.Title.Contains(param.Title)).ToList();
            string count = notilis.Count.ToString();
            notilis = notilis.OrderByDescending(p=>p.AddTime).Skip((param.PageIndex - 1) * param.PageSize).Take(param.PageSize).ToList();
            return ApiResult.Success(count, notilis);
        }
        /// <summary>
        /// 通过id查询用户发送公告的总次数
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetNotifyNum(int id)
        {
            int count = await db.Notice.Where(n => n.UserId == id && n.IsDelete == 0).CountAsync();
            return count > 0 ? ApiResult.Success(count) : ApiResult.Error();
        }
        /// <summary>
        /// 通过id获取公告类型
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public ApiResult GetNotifyTypeByid(int id)
        {
            var result = db.Notice.Include(n => n.Type).Where(n => n.IsDelete == 0).Select(n => new { typeNama = n.Type.TypeName, typeId = n.Type.Id, id = n.Id }).SingleOrDefault(n => n.id == id);
            return ApiResult.Success(result);
        }

        /// <summary>
        /// 通过类型名称查找类型
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public ApiResult GetNotifyTypeByName(string typeName)
        {
            return ApiResult.Success(db.NoticeType.Where(n => n.TypeName.Contains(typeName) && n.IsDelete == 0).ToList());
        }
        /// <summary>
        /// 通过id修改公告类型
        /// </summary>
        /// <param name="id"></param>
        /// <param name="notice"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateNotifyById(int id, Notice notice)
        {
            Notice notify = db.Notice.SingleOrDefault(n => n.Id == id && n.IsDelete == 0);
            db.Entry(notify).State = EntityState.Modified;
            notify.Title = notice.Title;
            notify.Content = notice.Content;
            notify.TypeId = notice.TypeId;
            db.Notice.Update(notify);
            int i = await db.SaveChangesAsync();
            return i > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("修改失败");
        }

        /// <summary>
        /// 上传图片
        /// </summary>
        /// <param name="files"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> Upload(IFormFileCollection files)
        {
            IFormFile formFile = files[0];
            string fileName = "";
            //文件扩展名
            string extension = Path.GetExtension(formFile.FileName);
            if (formFile.Length <= 0)
                return ApiResult.Error("请先选中图片");
            if (".jpg".Equals(extension) || ".png".Equals(extension) || ".jpeg".Equals(extension) || ".bmp".Equals(extension))
            {
                //文件名称
                fileName = Guid.NewGuid().ToString() + extension;
                await formFile.CopyToAsync(new FileStream(Common.BaseUrl.NotifyImgUrl + fileName, FileMode.OpenOrCreate, FileAccess.Write));
            }
            else
            {
                return ApiResult.Error("图片格式不正确");
            }
            var obj = new { url = "http:\\\\localhost:5000\\files\\notify\\" + fileName };
            return ApiResult.Success(obj);
        }
        
        /// <summary>
        /// 获取所有的菜单
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResult> Menu()
        {
            return ApiResult.Success(await db.Menu.Include(m => m.SonMenu).ToListAsync());
        }
        /// <summary>
        /// 获取统计的数据
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetCount(int id)
        {
            int sum =await db.Notice.Where(n=>n.IsDelete==0).CountAsync();
            List<Notice> notices = await db.Notice.Include(n=>n.Type).Where(n => n.UserId == id&&n.IsDelete==0&&n.Type.Sign!="MYNEWS").ToListAsync();
            int now = 0;
            int week = 0;
            //用户总共发送的数量
            
            //今天的日期
            DateTime nowDay = Convert.ToDateTime(DateTime.Now.Date.ToString("yyyy-MM-dd"));
            for (int i = 0; i < notices.Count; i++)
            {
                //发送的日期
                DateTime dateTime = Convert.ToDateTime(notices[i].AddTime.ToString("yyyy-MM-dd"));
                //说明是当天
                if (dateTime ==nowDay)
                {
                    now++;
                }else if (dateTime.Year==nowDay.Year&&dateTime.Month==nowDay.Month&&nowDay.Day-dateTime.Day<=7)
                {
                    //一周
                    week++;
                }
            }
            week += now;
            return ApiResult.Success(new NotifyCountDTO { DayCount = now,userCount=notices.Count , TotalCount = sum, WeekCount = week });
        }
        /// <summary>
        /// 通过id获取公告的类型
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> GetNotifyTypeById(int id)
        {
            NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Id == id);
            return ApiResult.Success(noticeType);
        }
        /// <summary>
        /// 修改类型
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> UpdateNotifyType(NoticeType type)
        {
            NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(t => t.Id == type.Id);
            db.Entry(noticeType).State = EntityState.Modified;
            noticeType.TypeName=type.TypeName;
            noticeType.Icon = type.Icon;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("修改成功") : ApiResult.Error("更新失败");
        }
        /// <summary>
        /// 删除公告类型
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelNotifyTypeById(int id)
        {
            NoticeType noticeType = await db.NoticeType.SingleOrDefaultAsync(n => n.Id == id);
            db.Entry(noticeType).State = EntityState.Modified;
            noticeType.IsDelete = 1;
            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
        /// <summary>
        /// 批量删除我的发布
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<ApiResult> DelMyNotifyBatch(int[] ids)
        {
            for (int i = 0; i < ids.Length; i++)
            {
                Notice notice = await db.Notice.SingleOrDefaultAsync(n => n.Id == ids[i]);
                db.Entry(notice).State = EntityState.Modified;
                notice.IsDelete = 1;
            }

            return await db.SaveChangesAsync() > 0 ? ApiResult.Success("删除成功") : ApiResult.Error("删除失败");
        }
    }
}
